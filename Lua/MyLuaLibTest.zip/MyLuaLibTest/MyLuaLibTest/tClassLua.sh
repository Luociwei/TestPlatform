

tolua=/usr/local/bin/tolua++

$tolua -o tClassLua.mm tClassLua.pkg
