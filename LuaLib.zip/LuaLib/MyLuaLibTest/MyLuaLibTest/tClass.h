//
//  tClass.hpp
//  MyLuaLibTest
//
//  Created by ciwei luo on 2021/1/31.
//  Copyright © 2021 Louis.Luo. All rights reserved.
//

#ifndef tClass_hpp
#define tClass_hpp

#include <stdio.h>


class Aclass
{
public:
    int a;
    Aclass(int nTemp);
    int Get();
};


#endif /* tClass_hpp */
