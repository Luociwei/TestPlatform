//
//  tClass.cpp
//  MyLuaLibTest
//
//  Created by ciwei luo on 2021/1/31.
//  Copyright © 2021 Louis.Luo. All rights reserved.
//

#include "tClass.h"


Aclass::Aclass( int nTemp )
{
    a = nTemp;
}

int Aclass::Get()
{
    return a;
}




