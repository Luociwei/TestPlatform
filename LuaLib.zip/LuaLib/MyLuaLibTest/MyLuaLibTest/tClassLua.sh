

tolua=/usr/local/bin/tolua++

$tolua -o tClassLua.mm tClass.pkg
