//
//  AlertPanel.h
//  UI
//
//  Created by ZL-Pro on 2017/7/13.
//
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
NSInteger NSRunAlertPanelEx(NSString *title, NSString *msgFormat, NSString *defaultButton, NSString *alternateButton, NSString *otherButton, ...);
