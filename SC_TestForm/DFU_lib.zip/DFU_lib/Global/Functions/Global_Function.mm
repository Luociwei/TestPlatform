//
//  Global_Function.cpp
//  Global
//
//  Created by Ryan on 12-11-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#include <iostream>
#include "Global_Function.h"
#include "USB.h"
#include <stdio.h>
#include "NSAlert+Popover.h"
#include <pthread.h>
#include "RegexKitLite.h"

#define kDistributedNotificationCenterEnableDisableStop      @"On_NotificationCenter_EnableDisableStopButton"
#define kDistributedNotificationCenterOnMsgBox               @"On_NotificationCenterOnMsgBox"
#define kDistributedNotificationCenterOnMobileRestoreMsgBox  @"On_NotificationCenterOnMobileRestoreMsgBox"

//#include <TMLibrary/MessageInterface.h>

NSLock * g_global = [[NSLock alloc]init];
MessageBoxView * box = [[MessageBoxView alloc]init];
NSMutableString * strBin = [[NSMutableString alloc] init];

struct parametersCmd
{
    NSString *cmd;
    NSArray *cmdsArray;
    const char *filePath;
};


//Time
double Now()
{
    return [[NSDate date] timeIntervalSince1970];
}

//Delay
#pragma mark Delay
void Delay(int ms)
{
    [NSThread sleepForTimeInterval:(double)ms/1000.0];
}

#pragma mark bit operation
int BitSelect(int data,int bit)
{
    int x = 0x01<<bit;
    int value = data &x;
    return value?1:0;
}

void set_bit(unsigned long * pdata,unsigned char index)
{
    setbit(pdata, index);
}
void clr_bit(unsigned long * pdata,unsigned char index)
{
    clrbit(pdata, index);
}

unsigned char get_bit(unsigned long data,unsigned char index)
{
    unsigned v = unsigned(data);
    return !isclr(&v, index);
}

unsigned long bit_and(unsigned long x,unsigned long y)     //and
{
    return x&y;
}
unsigned long bit_or(unsigned long x,unsigned long y)      //or
{
    return x|y;
}
unsigned long bit_not(unsigned long x)                     //not
{
    return ~x;
}
unsigned long bit_xor(unsigned long x,unsigned long y)     //xor
{
    return x^y;
}
unsigned long bit_nor(unsigned long x,unsigned long y)     //nor
{
    return ~(x^y);
}

#pragma mark system

//Execute
//Run a application in background
//int Execute(const char * szcmd,int waituntilreturn,int itimeout)
static int Execute_withTask(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
{
    //   return system(szcmd);
    if (!szcmd) return -1;
    NSArray * arg;
    NSArray * arguments;
    NSString * strRex = @"[^\"\\s]*\"([^\"]*)\"[^\\s]*|(>?[^\"\\s]*)";
    
    NSString * str =[NSString stringWithUTF8String:szcmd];
    NSArray * arrArguments=[str arrayOfCaptureComponentsMatchedByRegex:strRex];
    NSMutableArray * argus = [NSMutableArray array];
    for (NSArray * o in arrArguments)
    {
        if (![[o objectAtIndex:1] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:1]];
        }
        if (![[o objectAtIndex:2] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:2]];
        }
    }
    //NSLog(@"arguments : %@",[argus description]);
    arguments=nil;
    if ([argus count]>1)
    {
        arguments = [argus subarrayWithRange:NSMakeRange(1, [argus count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    arg = argus;
    
    NSLog(@"Excuteable : %@",[[arg objectAtIndex:0] description]);
    NSLog(@"arguments : %@",[arguments description]);
    
    NSTask * task = [[NSTask alloc] init];
    id handle = nil;
    if (poutput)
    {
        NSString * str = [NSString stringWithUTF8String:poutput];
        str = [str stringByResolvingSymlinksInPath];
        [[NSFileManager defaultManager] createFileAtPath:str contents:nil attributes:nil];
        handle =[NSFileHandle fileHandleForWritingAtPath:str];
        [task setStandardOutput:handle];
        [task setStandardError:handle];
    }
    
    [task setLaunchPath:[arg objectAtIndex:0]];
    
    [task setArguments:arguments];
    
    [task launch];
    
    if (waituntilreturn)
    {
        NSLog(@"Executing... %s",szcmd);
        NSTimeInterval start = [[NSDate date] timeIntervalSince1970];
        while (1) {
            NSTimeInterval now =[[NSDate date]timeIntervalSince1970];
            //if ((now-start)>itimeout/1000)
            if ((now-start)>50)
            {
                [task terminate];
                [task release];
                NSString * str = [NSString stringWithFormat:@"%s\r\nTask time out in %d millionseconds.",szcmd,itimeout];
                NSLog(@"%@", str);
                [task release];
                if (handle) {
                    [handle closeFile];
                }
                return -1;
                @throw [NSException exceptionWithName:@"NSTask" reason:str userInfo:nil];
            }
            
            if ([[NSThread currentThread] isCancelled])
            {
                NSLog(@"Thread cancelled!");
                [task release];
                if (handle) {
                    [handle closeFile];
                }
                return -2;  //cancel
            }
            
            if (![task isRunning]) break;
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
            [NSThread sleepForTimeInterval:0.001];
        }
        int ret = [task terminationStatus];
        [task release];
        if (handle) {
            [handle closeFile];
        }
        NSLog(@"process normal finish! @ %s",szcmd);
        return ret;
    }
    //return [task processIdentifier];
    NSLog(@"process normal finish11! %s",szcmd);
    return 0;
}


void* threadFun(void* arg)
{
    //pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
    //pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
    NSMutableString *m_strBuffer = [[NSMutableString alloc] initWithCapacity:2048*4];
    parametersCmd *mypara=(struct parametersCmd *)arg;
    
    NSString *arg_1=(*mypara).cmd;
    NSArray * arguments=(*mypara).cmdsArray;
    const char * poutput=(*mypara).filePath;
   // NSString *arg_1=@"/usr/local/bin/usbfs-2.4.8";
    //NSArray * arguments=@[@"--name",@"0x1d112300",@"-f",@"/Users/gdlocal/RestorePackage/71B/RamDisk"]; //(*mypara).cmdsArray;
    //const char * poutput="/Users/gdlocal/Desktop/1.txt";//(*mypara).filePath;
    
    NSLog(@"------->threadFun:%@,%@, %s",arg_1,arguments,poutput);
    
    NSTask *task = [[NSTask alloc] init] ;
    NSPipe* outputPipe = [NSPipe pipe];
    task.standardOutput = outputPipe;
    task.launchPath = arg_1;
    // [task setLaunchPath:arg_1];
    [task setArguments:arguments];
    [task launch];
    
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:[NSString stringWithUTF8String:poutput]];
    
    while ([task isRunning])
    {
        
        NSData *currentOutput = [outputPipe.fileHandleForReading availableData];
        NSString *str = [[NSString alloc] initWithData:currentOutput encoding:NSUTF8StringEncoding];
        
        NSLog(@"==>>   %@",str);
        [m_strBuffer appendString:str];
        [str release];
    }
    
    [fh writeData:[[NSString stringWithFormat:@"%@",m_strBuffer]  dataUsingEncoding:NSUTF8StringEncoding]];
    [task release];
    [m_strBuffer release];
    [fh closeFile];
    return nil;
}

int test_pthread(pthread_t tid) /*pthread_kill的返回值：成功（0） 线程不存在（ESRCH） 信号不合法（EINVAL）*/
{
    int pthread_kill_err;
    pthread_kill_err = pthread_kill(tid,0);
    
    if(pthread_kill_err == ESRCH)
    {
       // printf("ID:0x%x的线程不存在或者已经退出。\n",(unsigned int)tid);
        return 1;
    }
    else if(pthread_kill_err == EINVAL)
    {
        //printf("发送信号非法。/n");
        return 2;
    }
    else
    {
        // printf("ID为0x%x的线程目前仍然存活。\n",(unsigned int)tid);
        return 3;
    }
}
int Execute(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
{
   // return Execute_withTask(szcmd,poutput, waituntilreturn, itimeout);
   /*  if (!szcmd) return -1;
    NSArray * arg;
    NSArray * arguments;
    NSString * strRex = @"[^\"\\s]*\"([^\"]*)\"[^\\s]*|(>?[^\"\\s]*)";
    NSString * str =[NSString stringWithUTF8String:szcmd];
    NSArray * arrArguments=[str arrayOfCaptureComponentsMatchedByRegex:strRex];
    NSMutableArray * argus = [NSMutableArray array];
    for (NSArray * o in arrArguments)
    {
        if (![[o objectAtIndex:1] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:1]];
        }
        if (![[o objectAtIndex:2] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:2]];
        }
    }
    arguments=nil;
    if ([argus count]>1)
    {
        arguments = [argus subarrayWithRange:NSMakeRange(1, [argus count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    arg = argus;
    
    NSLog(@"Excuteable : %@",[[arg objectAtIndex:0] description]);
    NSLog(@"arguments : %@",[arguments description]);
    */
    
   NSArray *array_cmd = [[NSString stringWithUTF8String:szcmd] componentsSeparatedByString:@" "];
    
    struct parametersCmd mypara;
    mypara.cmd=[array_cmd objectAtIndex:0];
    mypara.cmdsArray= [NSArray arrayWithObjects:array_cmd[1],array_cmd[2],array_cmd[3],array_cmd[4],nil];
    mypara.filePath=poutput;
    
    pthread_t pid;
    pthread_create(&pid,NULL, threadFun,&(mypara));
    int result = -1;
    sleep(1);
    if ( waituntilreturn >1 )
    {
        NSTimeInterval start = [[NSDate date] timeIntervalSince1970];
        while (1)
        {
            sleep(1);
            NSTimeInterval now =[[NSDate date]timeIntervalSince1970];
            if ((now-start)>itimeout/1000)
            {
                NSLog(@"----time out---");
                //pthread_cancel(pid);
                //pthread_exit(pid);
                // pthread_kill(pid, 1);
               // lua_pushstring(L,"time out");
                result = 1;
                break;
            }
            if (test_pthread(pid)==1)
            {
                //char* retStr;
                //pthread_join(pid, (void**)&retStr);
               // lua_pushstring(L,"OK");
                result = 2;
                break;
            }
            
        }
    }
    
    return result;
    
}






#pragma mark data convert
//NSLog(@"codec: %s", getAlertCal(1, 0.93768596858663));// 0x00000001 0x3F700C30
const char *  floatConversion(float value)
{
    Float32 val = value;
    Byte * p = (Byte *)&val;
    NSMutableString * str = [NSMutableString stringWithString:@"0x"];
    for(int i=3;i>=0;i--)
        [str appendFormat:@"%02X",p[i]];
    return [str UTF8String];
}

float floatToNumber(char * dataStr)
{
    NSString * str= [NSString stringWithFormat:@"%s",dataStr];
    unsigned int fix_data;
    NSScanner * nsscan = [[NSScanner alloc]initWithString: str];
    [nsscan scanHexInt:&fix_data];
    Float32 val;
    memcpy(&val, &fix_data, 4);
    return val;
}

const char* floatToFixed(double num)
{
    if (num>32767.9999847412109375) num=32767.9999847412109375;
    else if(num< -32768) num=-32768;
    //   unsigned int fix_data = (int)(num * (Float32)((int)1 << 16));
    unsigned int fix_data = FloatToFixed(num);
    return [[NSString stringWithFormat:@"0x%08X", fix_data]UTF8String];
}

double fixedToNumber(char * dataStr)
{
    NSString * str= [NSString stringWithFormat:@"%s",dataStr];
    unsigned int fix_data;
    NSScanner * nsscan = [[NSScanner alloc]initWithString: str];
    [nsscan scanHexInt:&fix_data];
    [nsscan release];
    if (fix_data > pow(2, 31)-1) {
        fix_data = fix_data - pow(2,32);
    }
    int temp = [[NSString stringWithFormat:@"%d",fix_data]intValue];
    return FixedToFloat(temp);
}


#pragma mark USB Location
#define VID     0x9011
#define PID     0x2514

NSString * InitialUsb(int uut)//uut start from 0
{
    NSLog(@"Get usb location from default VID(0x9011)/PID(0x2514)");
    unsigned int locationID = GetUsbLocation(VID, PID);
//        if (!locationID) return -1; //could not find the specail usb hub.

    int offset = 0x0000000F;
    int i=0;
    for (i=0; i<8; i++) {
        if ((locationID&(offset<<(4*i)))==0) continue;
        else {
            break;
        }
    }
    
    offset = pow(0x10, i-1);
    NSLog(@"Hub Address : 0x%08x",locationID);

    NSString * usbId = [NSString stringWithFormat:@"0x%08x",locationID+offset*(uut+1) ];
    
    NSLog(@"%@%d = %@",@"usb",uut,usbId);
    return usbId;
}

#define kHub    @"UsbHub"
#define kVID    @"VID"
#define kPID    @"PID"
#define kMAP    @"MAP"
#define kCH    @"ch"

int InitialUsbwithDictionary(int uut, NSMutableString * usbId, const char * file)
{
    NSString * str = @"/vault/Config/UsbLocation.plist";
    if(file)
        str = [NSString stringWithUTF8String:file];
    NSLog(@"get usb location form file : %@", str);
    NSDictionary * dic = [NSDictionary dictionaryWithContentsOfFile:str];
    if(dic)
    {
        NSArray * arr = [dic valueForKey:kHub];
        if (!arr) return -1;
        for (NSDictionary * dic in arr)
        {
            int vid = (int)strtol([[dic valueForKey:kVID] UTF8String], NULL, 16);
            int pid = (int)strtol([[dic valueForKey:kPID] UTF8String], NULL, 16);
        
            NSDictionary * map = [dic valueForKey:kMAP];
        
            if ((!map)||[[map allKeys] count]==0) continue; //all channel of this hub no use
        
            UInt32 locationID = GetUsbLocation(vid,pid);
        
            int offset = 0x0000000F;
            int i=0;
            for (i=0; i<8; i++) {
                if ((locationID&(offset<<(4*i)))==0) continue;
                else {
                    break;
                }
            }
        
            offset = pow(0x10, i-1);
            NSLog(@"Hub Address : 0x%08x",locationID);
        
            for (int i=0; i<=7; i++) {
                NSString * chn = [NSString stringWithFormat:@"%@%d",kCH,i];
                if ([map valueForKey:chn])
                {
//                    NSString * chn = [NSString stringWithFormat:@"%@%d",kCH,uut];
                        int slot = [[map valueForKey:chn] intValue];
                        if(slot == uut)
                        {
                            [usbId setString:[NSString stringWithFormat:@"0x%08x",locationID+offset*(i+1)]];    //set usblocation value
                            NSLog(@"Chn%d Usb Location : %@",slot,usbId);
                            return 0;
                        }
                }
            }
        
        }
    }
    return -1;
}

const char * getUsbLocation(int uut, const char * file)
{
    NSMutableString * usbId = [[NSMutableString alloc] init];
    if (InitialUsbwithDictionary(uut, usbId, file)<0)
        [usbId setString:InitialUsb(uut)];//no special usb chip id, use default
    NSString * str = [NSString stringWithString:usbId];
    [usbId release];
    return [str UTF8String];
}

#pragma mark Instrument Synchronization

#define kLockState     @"lockState"
#define kLockHandle    @"lockHandle"
NSMutableDictionary * InstrumentKeyChain = [[[NSMutableDictionary alloc]init]retain];
FILE * fp;
FILE * fp_group1;
FILE * fp_group2;
FILE * fp_sync;

int LockInstrument(const char * szLockName)
{
    NSLog(@"LockInstrument : %s", szLockName);
    NSString * lockName = [NSString stringWithUTF8String:szLockName];
    if([lockName length]<=0)
    {
        NSLog(@"LockInstrument : %s Invalide Lock Name", szLockName);
        return -999;
    }
    NSString * path = [NSString stringWithFormat:@"/vault/.%@.lock", lockName];
    if(![[NSFileManager defaultManager]fileExistsAtPath:path])
        [[NSFileManager defaultManager]createFileAtPath:path contents:nil attributes:nil];
    if((fp=fopen([path UTF8String], "r+w")) == NULL)
    {
        NSLog(@"File Open error");
        return -1;
    }
    if(flock(fp->_file, LOCK_EX) != 0)
    {
        NSLog(@"File Locked error");
        return -2;
    }
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:[NSNumber numberWithBool:YES] forKey:kLockState];
    
   // [dic setObject:fp forKey:kLockHandle];
   // NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES],kLockState,(__bridge id _Nullable)fp,kLockHandle, nil];
    [InstrumentKeyChain setObject:dic forKey:lockName];
    NSLog(@"All key in chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
    NSLog(@"LockInstrument : %s Success", szLockName);
    return 0;
}

int LockInstrumentByGroup(const char * szLockName,int slot)
{
     NSLog(@"LockInstrument group: %s, slot: %d", szLockName,slot);
     
   
     NSString * lockName = [NSString stringWithFormat:@"%@_%d",[NSString stringWithUTF8String:szLockName],slot%2];
     if([lockName length]<=0)
     {
         NSLog(@"LockInstrument group : %s Invalide Lock Name", szLockName);
         return -999;
     }
     NSString * path = [NSString stringWithFormat:@"/vault/.%@.lock", lockName];
     if(![[NSFileManager defaultManager]fileExistsAtPath:path])
         [[NSFileManager defaultManager]createFileAtPath:path contents:nil attributes:nil];
    
     if (slot%2 == 0)
     {
         NSLog(@"LockInstrument ->group : %s Invalide Lock Name", szLockName);
         if((fp_group1=fopen([path UTF8String], "r+w")) == NULL)
         {
             NSLog(@"File Open error");
             return -1;
         }
         NSLog(@"LockInstrument -->group : %s Invalide Lock Name", szLockName);
         if(flock(fp_group1->_file, LOCK_EX) != 0)
         {
             NSLog(@"File Locked error");
             return -2;
         }
     }
    else
    {
        NSLog(@"LockInstrument ->group : %s Invalide Lock Name", szLockName);
        if((fp_group2=fopen([path UTF8String], "r+w")) == NULL)
        {
            NSLog(@"File Open error");
            return -1;
        }
        NSLog(@"LockInstrument -->group : %s Invalide Lock Name", szLockName);
        if(flock(fp_group2->_file, LOCK_EX) != 0)
        {
            NSLog(@"File Locked error");
            return -2;
        }
    }
    
     NSMutableDictionary * dic = [NSMutableDictionary dictionary];
     [dic setObject:[NSNumber numberWithBool:YES] forKey:kLockState];
     [InstrumentKeyChain setObject:dic forKey:lockName];
     NSLog(@"All key in chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
     NSLog(@"LockInstrument group : %s , slot: %d ,Success", szLockName,slot);
    
     return 0;
    
}

int UnlockInstrument(const char * szLockName)
{
    NSLog(@"unLockInstrument : %s", szLockName);
    NSString * lockName = [NSString stringWithUTF8String:szLockName];
    if([lockName length]<=0) return -999;
    NSLog(@"All key in chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
    NSDictionary * dic = [InstrumentKeyChain objectForKey:lockName];
    if(dic)
    {
        //FILE * fp = (__bridge FILE *)[dic objectForKey:kLockHandle];
        if (fp) {
            NSLog(@"===has===");
        }
        BOOL lockState = [[dic objectForKey:kLockState]boolValue];
        if(fp && lockState)
        {
            fclose(fp);
            flock(fp->_file, LOCK_UN);
            fp = NULL;
            [InstrumentKeyChain removeObjectForKey:lockName];
        }
        NSLog(@"unLockInstrument : %s Success", szLockName);
        return 0;
    }
    else
        NSLog(@"unLockInstrument : %s has no this lock", szLockName);
        return 0;
    return 0;
}

int UnlockInstrumentByGroup(const char * szLockName,int slot)
{
    NSLog(@"unLockInstrument : %s ,slot: %d", szLockName,slot);
    NSString * lockName = [NSString stringWithFormat:@"%@_%d", [NSString stringWithUTF8String:szLockName],slot%2];
    if([lockName length]<=0) return -999;
    NSLog(@"All key in chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
    NSDictionary * dic = [InstrumentKeyChain objectForKey:lockName];
    if(dic)
    {
        if (slot%2 == 0)
        {
            if (fp_group1)
            {
                NSLog(@"===fp_group1 has===");
            }
            BOOL lockState = [[dic objectForKey:kLockState]boolValue];
            if(fp_group1 && lockState)
            {
                fclose(fp_group1);
                flock(fp_group1->_file, LOCK_UN);
                fp_group1 = NULL;
                [InstrumentKeyChain removeObjectForKey:lockName];
            }
            
        }
        else
        {
            if (fp_group2)
            {
                NSLog(@"===fp_group2 has===");
            }
            BOOL lockState = [[dic objectForKey:kLockState]boolValue];
            if(fp_group2 && lockState)
            {
                fclose(fp_group2);
                flock(fp_group2->_file, LOCK_UN);
                fp_group2 = NULL;
                [InstrumentKeyChain removeObjectForKey:lockName];
            }
        }

        NSLog(@"unLockInstrument group: %s , slot:%d, Success", szLockName,slot);
        return 0;
    }
    else
        NSLog(@"unLockInstrument group: %s ,slot :%d,has no this lock", szLockName,slot);
        return 0;
    return 0;
    
}

int SyncInstrumentInit(int slot)
{
//    NSLog(@"sync Instrument init");
//    NSString * lockName = [NSString stringWithFormat:@"SyncInstrument_%d",slot];
//
//    NSString * path = [NSString stringWithFormat:@"/vault/.%@.lock", lockName];
//    if(![[NSFileManager defaultManager]fileExistsAtPath:path])
//    {
//        [[NSFileManager defaultManager]createFileAtPath:path contents:nil attributes:nil];
//    }
//
//        if((fp_sync=fopen([path UTF8String], "r+w")) == NULL)
//        {
//           NSLog(@"File Open error");
//        }
//        if(flock(fp_sync->_file, LOCK_EX) != 0)
//        {
//           NSLog(@"File Locked error");
//        }
//    
//    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
//    [dic setObject:[NSNumber numberWithBool:YES] forKey:kLockState];
//
//    [InstrumentKeyChain setObject:dic forKey:lockName];
//    NSLog(@"All key in sync init chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
//    NSLog(@"Lock sync Instrument init: %@ Success", lockName);
    return 0;
}
int SyncInstrument(int slot)
{
//    NSLog(@"sync Instrument");
//    NSString * lockName = [NSString stringWithFormat:@"SyncInstrument_%d",slot];
//    NSString * path = [NSString stringWithFormat:@"/vault/.%@.lock", lockName];
//    NSDictionary * dic = [InstrumentKeyChain objectForKey:lockName];
//
//    if(dic)
//    {
//        if (fp_sync)
//        {
//            NSLog(@"===slot: %d,has===",slot);
//        }
//        BOOL lockState = [[dic objectForKey:kLockState]boolValue];
//        if(fp_sync && lockState)
//        {
//           // fclose(fp_sync1);
//            flock(fp_sync->_file, LOCK_UN);
//            //fp_sync1 = NULL;
//            //[InstrumentKeyChain removeObjectForKey:lockName];
//        }
//        NSLog(@"unLock SyncInstrument : %@ ,slot %d, Success", lockName,slot);
//
//    }
//    else
//    {
//        NSLog(@"unLock SyncInstrument : %@ ,slot : %d, has no this lock", lockName,slot);
//    }
//
//    if (fp_sync)
//    {
//        NSLog(@"====fp_sync ==");
//        if(flock(fp_sync->_file, LOCK_EX) != 0)
//        {
//            NSLog(@"File SyncInstrument 1 Locked error");
//        }
//    }
//
//
////
////    BOOL lockState = [[dic objectForKey:kLockState]boolValue];
////    if(slot ==0 && fp_sync1 && lockState)
////    {
////        fclose(fp_sync1);
////        //flock(fp_sync1->_file, LOCK_UN);
////        fp_sync1 = NULL;
////        [InstrumentKeyChain removeObjectForKey:lockName];
////    }
////    if(slot ==1 && fp_sync2 && lockState)
////    {
////        fclose(fp_sync2);
////        //flock(fp_sync2->_file, LOCK_UN);
////        fp_sync2 = NULL;
////        [InstrumentKeyChain removeObjectForKey:lockName];
////    }
////    if(slot ==2 && fp_sync3 && lockState)
////    {
////        fclose(fp_sync3);
////        //flock(fp_sync3->_file, LOCK_UN);
////        fp_sync3 = NULL;
////        [InstrumentKeyChain removeObjectForKey:lockName];
////    }
////    if(slot ==3 && fp_sync4 && lockState)
////    {
////        fclose(fp_sync4);
////        //flock(fp_sync4->_file, LOCK_UN);
////        fp_sync4 = NULL;
////        [InstrumentKeyChain removeObjectForKey:lockName];
////    }
     return 0;
}

int UnlockAllInstrument()
{
    NSArray * keyArr = [InstrumentKeyChain allKeys];
    for(NSString * key in keyArr)
    {
        NSDictionary * dic = [InstrumentKeyChain objectForKey:key];
        if(dic)
        {
            FILE * fp = (__bridge FILE *)[dic objectForKey:kLockHandle];
            BOOL lockState = [[dic objectForKey:kLockState]boolValue];
            if( fp && lockState)
            {
                fclose(fp);
                flock(fp->_file, LOCK_UN);
                fp = NULL;
            }
        }
        
    }
    [InstrumentKeyChain removeAllObjects];
    return 0;
}


int launchApp(const char * appPath)
{
    NSString *appName = [[NSString stringWithUTF8String:appPath] lastPathComponent];
    NSString *cmd = [NSString stringWithFormat:@"ps -ef |grep -i %@ |grep -v grep|awk '{print $2}' |xargs kill -9",appName];
    NSLog(@"[cmd]: %@",cmd);
    system([cmd UTF8String]);
    [[NSWorkspace sharedWorkspace] launchApplication:[NSString stringWithUTF8String:appPath]];
    return 0;
}

void postDistributedNotification(const char * name, const char * msg)
{
    LockInstrument("postNotification");
    [NSThread sleepForTimeInterval:0.2];
    if(msg)
    {
        NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithUTF8String: msg],@"mesg", nil];
        [[NSDistributedNotificationCenter defaultCenter] postNotificationName:[NSString stringWithUTF8String:name] object:nil userInfo:dic];
    }
    else
        [[NSDistributedNotificationCenter defaultCenter]postNotificationName:[NSString stringWithUTF8String:name] object:nil];
    UnlockInstrument("postNotification");
    return;
}

const char* putSFC(char* szHttp)
{
    NSString* strHttp = [NSString stringWithUTF8String:szHttp];
    NSURL *SFC=[NSURL URLWithString:strHttp];
    NSString *ret = [NSString stringWithContentsOfURL:SFC encoding: NSASCIIStringEncoding error:NULL ];
    if (ret==nil)
        return NULL;
    else
        return [ret UTF8String];
}


int msgbox(const char * title,const char * msg,const char * button1,const char * button2,const char * button3)
{
   // NSAlert *alert = [[[NSAlert alloc] init] autorelease];
   /* NSAlert *alert = [[NSAlert alloc] init];

    if (title)
    {
        [alert setMessageText:[NSString stringWithUTF8String:title]];
    }
    if (msg)
    {
        [alert setInformativeText:[NSString stringWithUTF8String:msg]];
    }
    if (button1)
    {
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button1]];
    }
    if (button2)
    {
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button2]];
    }
    if (button3)
    {
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button3]];
    }
    [alert setAlertStyle:NSWarningAlertStyle];
    
    int ret = (int)[alert runModal];
    
    
//   [alert dealloc];
    [alert release];
    NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@!!!!!!!!====11");
//    [alert close];
   
    
//    [alert release];
    
    return ret;
    //return int([alert runModal]);*/
    
    NSAlert * alert = [[[NSAlert alloc] init] autorelease];
    [alert setAlertStyle:NSInformationalAlertStyle];
    [alert setMessageText:[NSString stringWithFormat:@"%@\r\n%@",[NSString stringWithUTF8String:title],[NSString stringWithUTF8String:msg]]];
    if (button1)
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button1]];
    if (button2)
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button2]];
    if (button3)
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button3]];
    [alert layout];

    NSInteger result = [alert runModal];
    if(result == NSAlertSecondButtonReturn){
        return 1000;
    }
    return 1001;
    
//    NSTextView *accessory = [[NSTextView alloc] initWithFrame:NSMakeRect(0,0,200,15)];
//    NSFont *font = [NSFont systemFontOfSize:[NSFont systemFontSize]];
//    NSDictionary *textAttributes = [NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName];
//    [accessory insertText:[[NSAttributedString alloc] initWithString:@"Text in accessory view."
//                                                          attributes:textAttributes]];
//    [accessory setEditable:NO];
//    [accessory setDrawsBackground:NO];
//    NSAlert *alert = [[NSAlert alloc] init];
//    alert.messageText = @"Message text.";
//    [alert setInformativeText:@"Informative text."];
//    alert.accessoryView = accessory;
//    [alert runModal];
//    [alert release];
//    return 0;
//    int ret = NSRunAlertPanel([NSString stringWithCString:title encoding:NSUTF8StringEncoding], [NSString stringWithCString:msg encoding:NSUTF8StringEncoding], [NSString stringWithCString:button1 encoding:NSUTF8StringEncoding], [NSString stringWithCString:button2 encoding:NSUTF8StringEncoding], nil);
//    return ret;
}

int MessageBox(const char*msg)
{
    //        [NSString stringWithFormat:@"%s",msg]
    // int ret =(int) NSRunAlertPanel(@"Prompt", @"%@", @"OK", nil, nil, [NSString stringWithCString:msg encoding:NSUTF8StringEncoding]) ;
    //    NSRunAlertPanel(@"Prompt", @"%@", @"OK", nil, nil, [NSString stringWithCString:msg encoding:NSUTF8StringEncoding]) ;
    //    return 0 ;
    //
    //NSRunAlertPanel(@"Prompt", [NSString stringWithUTF8String:msg], @"OK", nil, nil);
    
    //    NSRunAlertPanel(@"Prompt", @"%@", @"OK", nil, nil, [NSString stringWithCString:msg encoding:NSUTF8StringEncoding]) ;
    //return 0;
    //     NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@!!!!!!!!====5");
    //   // int ret = msgbox("Info",msg,nil,nil,nil);
    //
    //    int ret = [box ShowMessageBox:[NSString stringWithUTF8String:msg]];
    //    return ret;
    // return 0 ;

    const char*header = "Prompt";
    CFStringRef header_ref = CFStringCreateWithCString(NULL,header,strlen(header));
    CFStringRef message_ref = CFStringCreateWithCString(NULL,msg,strlen(msg));
    
    CFOptionFlags result;
    
    CFUserNotificationDisplayAlert(0,
                                   kCFUserNotificationNoteAlertLevel,
                                   NULL,
                                   NULL,
                                   NULL,
                                   header_ref,
                                   message_ref,
                                   NULL,
                                   CFSTR("NO"),
                                   NULL,
                                   &result
                                   );
    
    CFRelease(header_ref);
    CFRelease(message_ref);
    if (result==kCFUserNotificationDefaultResponse)
        return 1001;
    else
        return 1002;

}

int StopTest()
{
    NSMutableDictionary* dic = [NSMutableDictionary dictionary];
    [dic setValue:[NSNumber numberWithInt:-1] forKey:@"slot"];
    [[NSDistributedNotificationCenter defaultCenter] postNotificationName:@"On_NotificationCenterOnStop" object:nil userInfo:dic deliverImmediately:YES];
    //[NSThread sleepForTimeInterval:4.0];
    return 0;
}

int StopTestSlot(int slot)
{
    NSMutableDictionary* dic = [NSMutableDictionary dictionary];
    [dic setValue:[NSNumber numberWithInt:slot] forKey:@"slot"];
    [[NSDistributedNotificationCenter defaultCenter] postNotificationName:@"On_NotificationCenterOnStop" object:nil userInfo:dic deliverImmediately:YES];
    return 0;
}

int AppMessageBox(const char*msg)
{
    NSString *messgs = [NSString stringWithUTF8String:msg];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                               messgs,@"Message_Box",nil];
    [[NSDistributedNotificationCenter defaultCenter] postNotificationName:@"On_NotificationCenterOnMsgBox" object:nil userInfo:dic deliverImmediately:YES];
    return 0;
}

int RestoreMessageBox(int slot)
{
    NSString *fileFath = [NSString stringWithFormat:@"/Users/gdlocal/Config/.RestoreSettingFlag%d.txt",slot];
    [@"start" writeToFile:fileFath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:fileFath,@"filePath",nil];
    [[NSDistributedNotificationCenter defaultCenter] postNotificationName:kDistributedNotificationCenterOnMobileRestoreMsgBox object:nil userInfo:dic deliverImmediately:YES];
    
    while (1)
    {
        NSString *logfile = [NSString stringWithContentsOfFile:fileFath encoding:NSUTF8StringEncoding error:nil];
        if ([logfile containsString:@"done"])
        {
            return 0;
        }
        //[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        [NSThread sleepForTimeInterval:1.0];
    }
    
    return -1;
}

int SetStopButton(const char*msg)
{
    NSString *messgs = [NSString stringWithUTF8String:msg];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                               messgs,@"state",nil];
    [[NSDistributedNotificationCenter defaultCenter] postNotificationName:kDistributedNotificationCenterEnableDisableStop object:nil userInfo:dic deliverImmediately:YES];
    
    return 0;
}

const char* ShowFileName(char* path)
{
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    NSMutableString *fileName = [NSMutableString string];
    NSString *filePath = [NSString stringWithUTF8String:path];
    [fm fileExistsAtPath: filePath isDirectory: &isDir];
    if (isDir)
    {
        NSString *curPath;
        NSDirectoryEnumerator *dirEnum = [fm enumeratorAtPath: filePath];
        while ((curPath = [dirEnum nextObject]) != nil)
        {
            [fileName appendString:[NSString stringWithFormat:@"%@;",[curPath lastPathComponent]]];
        }

    }
    else
    {
        [fileName setString:@""];
    }
    return [fileName UTF8String];
}

int listFolderFile(char* path,char* filename,int timeout)
{
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSLog(@"starting to wait : %s",filename);
    
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    NSString *filePath = [NSString stringWithFormat:@"%s",path];
    [fm fileExistsAtPath:filePath isDirectory: &isDir];
    if (!isDir)
    {
        NSLog(@"not dir");
        return -1;
    }
    int ret = -100;
    NSString *file_name = [NSString stringWithUTF8String:filename];
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            ret = -2;
            break;
        }
        
        NSString *curPath =nil;
        NSDirectoryEnumerator *dirEnum = [fm enumeratorAtPath: filePath];
        while ((curPath = [dirEnum nextObject]) != nil)
        {
            if ([[curPath lastPathComponent] isEqualTo:file_name])
            {
                [dirEnum release];
                dirEnum = nil;
                ret = 0;
                return 0;
            }

        }
   
        [dirEnum release];
        dirEnum = nil;
        
        //[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:1.0];
    }
    return ret;
}



int listFolderContentFile2(char* path,char* filename,int timeout,int null_timeout)
{
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSLog(@"listfFolderContentFile ,starting to wait : %s",filename);
    
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    NSString *filePath = [NSString stringWithFormat:@"%s",path];
    [fm fileExistsAtPath:filePath isDirectory: &isDir];
    if (!isDir)
    {
        NSLog(@"not dir");
        return -1;
    }
    int ret = -100;
    NSString *file_name = [NSString stringWithUTF8String:filename];
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            ret = -2;
            break;
        }
        
        NSString *curPath = nil;
        NSDirectoryEnumerator *dirEnum = [fm enumeratorAtPath: filePath];
        while ((curPath = [dirEnum nextObject]) != nil)
        {
            if ([[curPath lastPathComponent] containsString:file_name])
            {
                [dirEnum release];
                dirEnum = nil;
                return 0;
            }
            if ([file_name isNotEqualTo:@"FAIL"])
            {
                if ([[curPath lastPathComponent] containsString:@"FAIL"])
                {
                    [dirEnum release];
                    dirEnum = nil;
                    return -3;
                }
                
            }
        }
        
        [dirEnum release];
        dirEnum = nil;
        
        //[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:1.0];
    }
    return ret;
}


int listFolderContentFile(char* path,char* filename,int timeout)
{
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSLog(@"listfFolderContentFile ,starting to wait : %s",filename);
    
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    NSString *filePath = [NSString stringWithFormat:@"%s",path];
    [fm fileExistsAtPath:filePath isDirectory: &isDir];
    if (!isDir)
    {
        NSLog(@"not dir");
        return -1;
    }
    int ret = -100;
    NSString *file_name = [NSString stringWithUTF8String:filename];
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            ret = -2;
            break;
        }
        
        NSString *curPath = nil;
        NSDirectoryEnumerator *dirEnum = [fm enumeratorAtPath: filePath];
        while ((curPath = [dirEnum nextObject]) != nil)
        {
            if ([[curPath lastPathComponent] containsString:file_name])
            {
                [dirEnum release];
                dirEnum = nil;
                return 0;
            }
            if ([file_name isNotEqualTo:@"FAIL"])
            {
                if ([[curPath lastPathComponent] containsString:@"FAIL"])
                {
                    [dirEnum release];
                    dirEnum = nil;
                    return -3;
                }
                
            }
        }

        [dirEnum release];
        dirEnum = nil;
        
        //[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:1.0];
    }
    return ret;
}

const char* getDeviceAddr(const char* path,int slot,int timeout)
{
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSString *idSlot = [NSString stringWithFormat:@"%d",slot];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    NSString *filePath = [NSString stringWithFormat:@"%s",path];
    [fm fileExistsAtPath:filePath isDirectory: &isDir];
    if (!isDir)
    {
        NSLog(@"not dir");
        return "error,not directory";
    }
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            return "error,timeout";
        }
        
        NSString *curPath = nil;
        NSDirectoryEnumerator *dirEnum = [fm enumeratorAtPath: filePath];
        while ((curPath = [dirEnum nextObject]) != nil)
        {
            NSString *tmpName = [curPath lastPathComponent];
            
            if ([tmpName hasPrefix:@"0x"])
            {
                
                NSString *tmpCurFolder = [tmpName stringByReplacingOccurrencesOfString:@"0x" withString:@""];
                NSArray *tmpArr = [tmpCurFolder componentsSeparatedByString:@"0"];
                NSInteger length = [tmpArr[0] length];
                if (length>0)
                {
                    if ([[tmpArr[0] substringWithRange:NSMakeRange(length-1, 1)] isEqual:idSlot])
                    {
                        [dirEnum release];
                        dirEnum = nil;
                        return [tmpName UTF8String];
                    }
                }
                
            }
        }
        
        [dirEnum release];
        dirEnum = nil;
        
        //[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:1.0];
    }
    return "error";
}

int listFileContent(const char* path,const char* keyWord,int timeout)
{
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSString *filePath = [NSString stringWithUTF8String:path];
    NSString *matchStr = [NSString stringWithUTF8String:keyWord];
    NSLog(@"find file: %@,keyword : %@",filePath,matchStr);
    NSFileManager *fm = [NSFileManager defaultManager];
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            break;
        }
        NSData *data = [fm contentsAtPath:filePath];
        //NSString *str1 = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];  case lua memory huge??????
        NSString *str1 = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if ([str1 containsString:matchStr])
        {
            [str1 release];
            str1 = nil;
            data = nil;
            return 0;
        }
        [str1 release];
        str1 = nil;
        data = nil;
        
        //[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:1.5];
    }
    
    return -1;
}


const char* ReadFileContent(char* path)
{
    NSData* reader = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:path]];
    Byte bytes[1] = {0x00};
    NSData *data00 = [[NSData alloc] initWithBytes:bytes length:1];
    NSData *data01 = [@"\n" dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableData *data = [NSMutableData data];
    [data setData:reader];
    for (NSUInteger i=reader.length-1; i>0; i--)
    {
        NSData * tmpData = [reader subdataWithRange:NSMakeRange(i,1)];
        NSData * tmpData2 = [reader subdataWithRange:NSMakeRange(i-1,1)];
        if ([tmpData isEqualTo:data00] && [tmpData2 isEqualTo:data01])
        {
            [data replaceBytesInRange:NSMakeRange(i, 1) withBytes:NULL length:0];
        }
        if (i==1 && [tmpData2 isEqualTo:data00])
        {
            [data replaceBytesInRange:NSMakeRange(0, 1) withBytes:NULL length:0];
        }
    }
    NSString *str1 = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSString *result = [NSString stringWithString:str1];
    [str1 release];
    return [result UTF8String];
}

int deleteLogFiles(const char* logpath,const char* prefixName)
{
    NSFileManager * fileManger = [NSFileManager defaultManager];
    NSString *path = [NSString stringWithUTF8String:logpath];
    BOOL isDir = NO;
    BOOL isExist = [fileManger fileExistsAtPath:path isDirectory:&isDir];
    if (isExist)
    {
        if (isDir)
        {
            NSArray * dirArray = [fileManger contentsOfDirectoryAtPath:path error:nil];
            NSString * subPath = nil;
            for (NSString * str in dirArray)
            {
                subPath  = [path stringByAppendingPathComponent:str];
                BOOL issubDir = NO;
                [fileManger fileExistsAtPath:subPath isDirectory:&issubDir];
                if (!issubDir)
                {
                    deleteLogFiles([subPath UTF8String],prefixName);
                }
                else
                {
                    NSString *fileName = [subPath lastPathComponent];
                    if ([fileName hasPrefix:[NSString stringWithUTF8String:prefixName]])
                    {
                        NSError *error = nil;
                        [fileManger removeItemAtPath:subPath error:&error];
                        NSLog(@">delete folder: %@ ,error: %@",subPath,error);
                    }
                    
                }
            }
        }
        else
        {
            NSString *fileName = [path lastPathComponent];
            if ([fileName hasPrefix:[NSString stringWithUTF8String:prefixName]])
            {
                NSError *error = nil;
                [fileManger removeItemAtPath:path error:&error];
                NSLog(@">delete file: %@error: %@",path,error);
            }
            
        }
    }
    else
    {
        return -1;
    }
    return 0;
}

int zipLogFiles(const char* logpath,const char* prefixName)
{
    NSFileManager * fileManger = [NSFileManager defaultManager];
    NSString *path = [NSString stringWithUTF8String:logpath];
    BOOL isDir = NO;
    BOOL isExist = [fileManger fileExistsAtPath:path isDirectory:&isDir];
    if (isExist)
    {
        if (isDir)
        {
            NSArray * dirArray = [fileManger contentsOfDirectoryAtPath:path error:nil];
            NSString * subPath = nil;
            for (NSString * str in dirArray)
            {
                subPath  = [path stringByAppendingPathComponent:str];
                BOOL issubDir = NO;
                [fileManger fileExistsAtPath:subPath isDirectory:&issubDir];
                if (!issubDir)
                {
                    zipLogFiles([subPath UTF8String],prefixName);
                }
                else
                {
                    NSString *fileName = [subPath lastPathComponent];
                    if ([fileName hasPrefix:[NSString stringWithUTF8String:prefixName]])
                    {
                        NSString *cmd = [NSString stringWithFormat:@"cd %@;zip -r -q %@.zip %@",path,fileName,fileName];
                        system([cmd UTF8String]);
                        NSLog(@"[zip]: %@",cmd);
                    }
                    
                }
            }
        }
    }
    else
    {
        return -1;
    }
    return 0;
    
}


const char* getBinFileContent(const char * path)
{
    NSData* reader = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:path]];
    NSString* ttemp = [NSString stringWithFormat:@"%@",reader];
    ttemp = [ttemp substringToIndex:([ttemp length]-1)];
    ttemp = [ttemp substringFromIndex:1];
    return [ttemp UTF8String];
    
}
const char* getBinFileHex(const char * path,int fromIndex,int length)
{
    NSUInteger start = fromIndex;
    NSInteger iLength = length;
    NSData* reader = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:path]];
    if (fromIndex <0)
    {
        iLength = 1;
    }
    if (fromIndex <0)
    {
        start = 0;
    }
    if (start>[reader length])
    {
        start = [reader length];
    }
    if ((iLength +start)>[reader length])
    {
        iLength = [reader length] - start;
    }
    
    if(strBin)
    {
        [strBin setString:@""];
    }
    else
    {
        strBin = [[NSMutableString alloc] init];
    }
    
    
     for (int x = 0; x< iLength; x++)
     {
         NSData *data = [reader subdataWithRange:NSMakeRange(start+x, 1)];
         NSString* ttemp = [NSString stringWithFormat:@"%@",data];
         ttemp = [ttemp substringToIndex:([ttemp length]-1)];
         ttemp = [ttemp substringFromIndex:1];
         ttemp = [ttemp stringByReplacingOccurrencesOfString:@" " withString:@""];
         if (x == iLength-1)
             [strBin appendFormat:@"0x%@",ttemp];
         else
             [strBin appendFormat:@"0x%@,",ttemp];
        
     }
    return [strBin UTF8String];
}

int MsgButton(const char *msg, const char *DefaultReturn , const char *AlternateReturn , const char *OtherReturn)
{
       NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@MsgButton des");
    
    NSAlert *alert = [NSAlert alertWithMessageText:[NSString stringWithUTF8String:msg]
                                     defaultButton:[NSString stringWithUTF8String:DefaultReturn]
                                   alternateButton:[NSString stringWithUTF8String:AlternateReturn]
                                       otherButton:[NSString stringWithUTF8String:OtherReturn]
                         informativeTextWithFormat:@"informativeText"];
    
    NSUInteger action = [alert runModal];
    //响应window的按钮事件
    if(action == NSAlertDefaultReturn)
    {
        NSLog(@"defaultButton clicked!");
    }
    else if(action == NSAlertAlternateReturn )
    {
        NSLog(@"alternateButton clicked!");
    }
    else if(action == NSAlertOtherReturn)
    {
        NSLog(@"otherButton clicked!");
    }
    
//     [alert release];
//   [alert dealloc];
   
    

     NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@MsgButton des2");
    
    
    
    return int(action);
}

// For pipe task function

unsigned long popen(const char * szcmd)
{
    PipeTask * ptask = [[PipeTask alloc]init];
    [ptask pStart:szcmd];
    return (unsigned long)ptask;
}

const char * pread(unsigned long obj)
{
    PipeTask *ptask = (PipeTask *)obj;
    return [ptask pRead];
}


const char * preadbuf(unsigned long obj)
{
    PipeTask *ptask = (PipeTask *)obj;
    return [ptask pReadBuf];
}

int pwrite(unsigned long obj,char * szbuffer)
{
    PipeTask *ptask = (PipeTask *)obj;
    return [ptask pWrite:szbuffer];
}

int pavlive(unsigned long obj)
{
    PipeTask *ptask = (PipeTask *)obj;
    return (int)[ptask isAlive];
}

int pwaitdetect(unsigned long obj, char * str, int timeout)
{
    PipeTask *ptask = (PipeTask *)obj;
    return [ptask waitdetect:str timeout:timeout];
}

int pclose(unsigned long obj)
{
    PipeTask *ptask = (PipeTask *)obj;
    return [ptask pClose];
}




