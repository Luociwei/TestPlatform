//#include "StdAfx.h"
#include "HEX2DEC.h"
#include "math.h"


CHEX2DEC::CHEX2DEC(void)
{
}


CHEX2DEC::~CHEX2DEC(void)
{
}

bool CHEX2DEC::seperateData( char* data,char* flag,vector<string>& dest )
{
	string str( data );
	string separator( flag );

	string substring;
	int  index;
	int start = 0;
	bool result = false;

	while( 1 )
	{
		int index = str.find_first_of(separator,start);
		if ( -1==index )
		{
			break;
		}
		result = true;

		substring = str.substr(start,index-start);

		dest.push_back(substring);

		start = str.find_first_not_of(separator,index);
		if ( -1==start)
		{
			break;
		}

	}
	//the last token
	if ( result )
	{

		substring = str.substr(start);

		dest.push_back(substring);
	}

	return result;
}


double CHEX2DEC::hex2dec( string data )
{
	
	int i;
	char ch;
	int n;
	long temp = 0;
	bool sight = false;
	for ( i=2;i<data.length();i++ )
	{
		ch = data.at(i);
		if ( ch=='0')
		{
		}
		if(ch>='A'&&ch<='F')//ʮ�����ƻ�Ҫ�ж����ǲ�����A-F����a-f֮��a=10����
			n=ch-'A'+10;
		else if(ch>='a'&&ch<='f')
			n=ch-'a'+10;
		else n=ch-'0';
		temp=temp*16+n;
	}
	if ( temp>8388608 )
	{
		temp = temp - pow( 2.0,24 );
	}

	double d = temp*5 / pow( 2.0,23 );

	return d;
}

void CHEX2DEC::normolize( double* data,int len,double* result )
{
	double maxData = -100;
	double minData = 100;

	for ( int i=0;i<len;i++ )
	{
		if ( maxData<data[i] )
		{
			maxData = data[i];
		}
		if ( minData>data[i] )
		{
			minData = data[i];
		}
	}

	double rate = 2/(maxData-minData);
	for( int i=0;i<len;i++ )
	{
		result[i] = data[i]*rate - 1;
	}
}