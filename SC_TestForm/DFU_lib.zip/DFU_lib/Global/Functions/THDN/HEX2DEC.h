#pragma once

#include <string>
#include<vector>


using namespace std;
class CHEX2DEC
{
public:
	CHEX2DEC(void);
	~CHEX2DEC(void);

public:
	double hex2dec( string data );
	void normolize( double* data,int len,double* result );
	bool seperateData( char* data,char* flag,vector<string>& dest );
};

