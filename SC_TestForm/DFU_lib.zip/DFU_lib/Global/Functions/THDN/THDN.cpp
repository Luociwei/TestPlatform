//#include "StdAfx.h"
#include "THDN.h"
#include "math.h"
#include "FFT.h"
#include "HEX2DEC.h"
#include "stdlib.h"

CTHDN::CTHDN(void)
{
	// fft window coef
	m_b[0] = 0.338946;
	m_b[1] = 0.481973;
	m_b[2] = 0.161054;
	m_b[3] = 0.018027;

	// sample rate
	m_Fs = 192000;

	// fft window size,should be pow 2
	m_windowSize = 8192;

	//interpolation coef
	m_aphaCoef[0] = 2.95494514;
	m_aphaCoef[1] = 0.17671943;
	m_aphaCoef[2] = 0.09230694;

	// A coef 
	m_ACoef[0] = 3.20976143;
	m_ACoef[1] = 0.9187393;
	m_ACoef[2] = 0.14734229;

	// A coef 
	m_ACoef[0] = 3.20976143;
	m_ACoef[1] = 0.9187393;
	m_ACoef[2] = 0.14734229;

	m_THDCoef = 20;

	m_THD_ORD = 7;

	m_limitUp = 20000;
	m_limitDown = 20;

}


CTHDN::~CTHDN(void)
{
}

//calculate THDN,THD
bool CTHDN::THDN( double* data,int len,double* thd,double* thdn )
{
	* thd =0;
	* thdn = 0;

	if ( (len&(len-1))!=0)
	{
		return false;
	}
	
	//generate new signal with window
	double* SignalWithWindow = (double*)malloc(sizeof(double)*len);
	//double SignalWithWindow[8192];
	signalWithNutgallWindow( data, len,SignalWithWindow );

	//signal with fft 
	double* result = (double*)malloc(sizeof(double)*len);
	//double result[8192];
	signalWithFFT( SignalWithWindow,result, len );

	//calculate THDN
	
	generateResult( result, len,thd,thdn );


	free( SignalWithWindow );
	free( result );


	return true;
}

void CTHDN::signalWithHanningWindow( double* data,int len,double* result )
{
	int i;
	for ( i=0;i<len;i++ )
	{
		result[i] = HanningWindow( i )*data[i];
	}

}
double CTHDN::HanningWindow( int n )
{
	double hanning = 0.54 - 0.46*cos( 2*PI*n/(m_windowSize-1) );
	return hanning;
}

void CTHDN::signalWithNutgallWindow( double* data,int len,double* result )
{
	int i;
	for ( i=0;i<len;i++ )
	{
		result[i] = NuttallWindow( i )*data[i];
	}
}

double  CTHDN::calculateTHD( double  A1,double  A2,double  A3,double  A4,double  A5 )
{
	double  thd;

	thd = 20 * log( sqrt(A2*A2+A3*A3+A4*A4+A5*A5)/A1) / log(10.0);

	return thd;
}

double  CTHDN::NuttallWindow( int n )
{
	double  wn = 0;

	for ( int i=0;i<=3;i++ )
	{
		wn += pow(-1.0,i) * m_b[i] * cos( 2*PI*n*i/m_windowSize );
	}

	return wn;
}

void CTHDN::generateResult( double* data,int len,double* thd,double* thdn )
{
	
	int N = len;
	int i;
	//1.find maximum amplitude and second largest point
	int ka,kb;
	double  ya,yb;

	//2.calculate fundatmental amplitude and position
	int k1,k2;
	double  y1,y2;

	ya = 0;
	for ( i=0;i<len;i++ )
	{
		if ( data[i]>ya )
		{
			ya = data[i];
			ka =  i;
		}

	}

	if ( ka+1<len && ka-1>=0 )
	{
		if ( data[ka+1] > data[ka-1] )
		{
			yb = data[ka+1];
			kb =  ka+1;
		} 
		else
		{
			yb = data[ka-1];
			kb =  ka-1;
		}
	}
	else if( ka+1>=len  )
	{
		yb = data[ka-1];
		kb =  ka-1;
	}
	else if ( ka-1<0)
	{
		yb = data[ka+1];
		kb =  ka+1;
	}
	
	
	k1 = ( ka<kb )?ka:kb;
	k2 = ( ka<kb )?kb:ka;

	y1 = ( ka<kb )?ya:yb;
	y2 = ( ka<kb )?yb:ya;

	double  bata = ( y2-y1 )/( y1+y2 );
	double  apha = m_aphaCoef[0]*bata + m_aphaCoef[1]*pow( bata,3 ) + m_aphaCoef[2]*pow( bata,5 );

	//the frequency of dundamental is
	//A1
	double  fb = ( k1+0.5+apha ) * ((double )m_Fs)/N;
	double  A1 = ( y1+y2 ) * ( m_ACoef[0]+m_ACoef[1]*pow(apha,2)+m_ACoef[2]*pow(apha,4) )/N;

	//A2
	int k21 = 0;
	double  A2 = calculateA(  data,N, fb,2,&k21 );

	//A3
	int k31 = 0;
	double  A3 = calculateA(  data, N, fb,3,&k31 );

	//A4
	int k41 = 0;
	double  A4 = calculateA(  data, N, fb,4,&k41 );

	//A5
	int k51;
	double  A5 = calculateA(  data, N, fb,5,&k51 );

	//THD
	*thd = calculateTHD(  A1, A2, A3, A4, A5 );

	//THDN
	*thdn = calculateTHDN( data, A1, A2, A3, A4, A5, k1, k2, k21, k31, k41, k51, fb, N );
	*thdn -= 4.4787;
}

double  CTHDN::calculateA( double* data,int N,double  fb,int n,int *k )
{
	double  y1,y2;
	double  A;

	if ( n>1 && n<6 )
	{
		double  f2 = n * fb;
		double  kn = f2*N / m_Fs;
		int kn1 = floor( kn );
		int kn2 = kn1 + 1;
		double  apha = kn - kn1 - 0.5;
		*k = kn1;
		//find y1,y2???
		y1 = data[kn1];
		y2 = data[kn2];
		
		A = ( y1+y2 ) * ( m_ACoef[0]+m_ACoef[1]*pow(apha,2)+m_ACoef[2]*pow(apha,4) )/N;
	}
	else
	{
		y1 = data[n];
		//y2 = data[n+1];
		A = ( y1 ) * m_ACoef[0] / N;
	}

	return A;
}

double  CTHDN::calculateTHDN( double* data,double  A1,double  A2,double  A3,double  A4,double  A5,int k1,int k2,int k21,int k31,int k41,int k51,int fb,int N )
{
	int n;
	double  A;
	int k;
	double  Nn = 0;

	for ( n=2;n<=k1-3;n++ )
	{
		A = calculateA(  data, N, fb, n,&k );
		Nn += pow( A,2 );
	}

	for ( n=k2+3;n<=k21-3;n++ )
	{
		A = calculateA(  data, N, fb, n,&k );
		Nn += pow( A,2 );
	}

	for ( n=k21+1-3;n<=k31-3;n++ )
	{
		A = calculateA(  data, N, fb, n,&k );
		Nn += pow( A,2 );
	}

	for ( n=k31+1-3;n<=k41-3;n++ )
	{
		A = calculateA(  data, N, fb, n,&k );
		Nn += pow( A,2 );
	}

	for ( n=k41+1-3;n<=k51-3;n++ )
	{
		A = calculateA(  data, N, fb, n,&k );
		Nn += pow( A,2 );
	}

	for ( n=k51+1-3;n<=N/2;n++ )
	{
		A = calculateA(  data, N, fb, n,&k );
		Nn += pow( A,2 );
	}

	double  thdn;

	thdn = 20 * log( sqrt(A2*A2+A3*A3+A4*A4+A5*A5+Nn)/A1) / log(10.0);

	return thdn;
}

void  CTHDN::signalWithFFT( double* data,double* result,int len )
{
	int i,j;
	
	CFFT FFT;
	complex* x = (complex*)malloc(sizeof(complex)*len);
	for ( i=0;i<len;i++ )
	{
		x[i].imag = 0;
		x[i].real = data[i];
	}
	FFT.fft( len,x );
	for ( i=0;i<len;i++ )
	{
		result[i] = sqrt( x[i].imag*x[i].imag+x[i].real*x[i].real );
	}

	free( x );
}


void CTHDN::harrisWindow( double* data,int len,double* result )
{
	double window;
	double harrisCoef[4];

	harrisCoef[0] = 0.35875;
	harrisCoef[1] = 0.48829;
	harrisCoef[2] = 0.14128;
	harrisCoef[3] = 0.01168;

	for ( int i=0;i<len;i++ )
	{
		window = harrisCoef[0]-harrisCoef[1]*cos(2*PI*i/(len-1))+harrisCoef[2]*cos(4*PI*i/(len-1))-harrisCoef[3]*cos(6*PI*i/(len-1));
		result[i] = data[i] * window;
	}
	
}

bool CTHDN::THDN_OneLine( char* data,double* thd,double* thdn )
{
	int i;
	CHEX2DEC hex2dec;
	vector<string> data1_hex;
	char flag[5] = ",";

	bool flg1 = hex2dec.seperateData( data,flag,data1_hex );
	int length = data1_hex.size();
	if ( length<m_windowSize )
	{
		return false;
	}

	double*  data_double = (double*)malloc(sizeof(double)*m_windowSize );
	for ( i =1;i<=m_windowSize;i++ )
	{
		if ( data1_hex[i]!="")
		{
			data_double[i-1] = hex2dec.hex2dec( data1_hex[i] );
		}
		else
		{
			break;
		}
	}

	THDN( data_double,m_windowSize,thd, thdn );

	free( data_double );
	data1_hex.clear();
	vector<string>().swap(data1_hex);

	return true;
}

bool CTHDN::THDN_TwoLine( char* right,char* left,double* thd,double* thdn )
{
	int i;
	CHEX2DEC hex2dec;
	vector<string> data1_hex;
	char flag[5] = ",";

	bool flg1 = hex2dec.seperateData( right,flag,data1_hex );
	int length = data1_hex.size();
	if ( length<m_windowSize )
	{
		return false;
	}

	double*  data1_double = (double*)malloc(sizeof(double)*m_windowSize );
	for ( i =1;i<=m_windowSize;i++ )
	{
		if ( data1_hex[i]!="")
		{
			data1_double[i-1] = hex2dec.hex2dec( data1_hex[i] );
		}
		else
		{
			break;
		}
	}

	vector<string> data2_hex;
	bool flg2 = hex2dec.seperateData( left,flag,data2_hex );
	int length2 = data2_hex.size();
	if ( length2<m_windowSize )
	{
		return false;
	}

	double*  data2_double = (double*)malloc(sizeof(double)*m_windowSize );
	for ( i =1;i<=m_windowSize;i++ )
	{
		if ( data2_hex[i]!="")
		{
			data2_double[i-1] = hex2dec.hex2dec( data2_hex[i] );
		}
		else
		{
			break;
		}
	}

	for ( i=0;i<m_windowSize;i++ )
	{
		data1_double[i] -= data2_double[i];
	}

	THDN( data1_double,m_windowSize,thd, thdn );

	free( data1_double );
	data1_hex.clear();
	vector<string>().swap(data1_hex);

	free( data2_double );
	data2_hex.clear();
	vector<string>().swap(data2_hex);

	return true;
}

void CTHDN::linspace( double start,double end ,int N,double* result )
{
	 double d = ((double)(end - start)) / (N-1);
	 int k = 0;
	 for ( double i = start;i<=end;i+=d )
	 {
		 result[k++] = i;
	 }
}

bool CTHDN::THDN_Matlab( char* right,char* left,double *thdn )
{
	int i,k;
	CHEX2DEC hex2dec;
	vector<string> data1_hex;
	char flag[5] = ",";

	bool flg1 = hex2dec.seperateData( right,flag,data1_hex );
	int length = data1_hex.size();
	if ( length<m_windowSize )
	{
		return false;
	}

	double*  data1_double = (double*)malloc(sizeof(double)*m_windowSize );
	for ( i =1;i<=m_windowSize;i++ )
	{
		if ( data1_hex[i]!="")
		{
			data1_double[i-1] = hex2dec.hex2dec( data1_hex[i] );
		}
		else
		{
			break;
		}
	}

	vector<string> data2_hex;
	bool flg2 = hex2dec.seperateData( left,flag,data2_hex );
	int length2 = data2_hex.size();
	if ( length2<m_windowSize )
	{
		return false;
	}

	double*  data2_double = (double*)malloc(sizeof(double)*m_windowSize );
	for ( i =1;i<=m_windowSize;i++ )
	{
		if ( data2_hex[i]!="")
		{
			data2_double[i-1] = hex2dec.hex2dec( data2_hex[i] );
		}
		else
		{
			break;
		}
	}

	for ( i=0;i<m_windowSize;i++ )
	{
		data1_double[i] -= data2_double[i];
	}

	//signal with window
	double *signalWidthWindow = (double *)malloc(sizeof(double)*m_windowSize );
	harrisWindow( data1_double,m_windowSize,signalWidthWindow );

	//signal with fft 
	double* Y = (double*)malloc(sizeof(double)*m_windowSize);
	//double result[8192];
	signalWithFFT( signalWidthWindow,Y,m_windowSize );
	
	//20H - 20KH
	int Num = 0;
	
	for ( i=0;i<m_windowSize;i++ )
	{
		if ( (double(i*m_Fs))/m_windowSize>=m_limitDown && (double(i*m_Fs))/m_windowSize<=m_limitUp )
		{
			Num++;
		}
	}
	double* HAR = (double*)malloc(sizeof(double)*Num);
	k = 0;
	for ( i=0;i<m_windowSize;i++ )
	{
		if ( (double(i*m_Fs))/m_windowSize>=m_limitDown && (double(i*m_Fs))/m_windowSize<=m_limitUp )
		{
			HAR[k++] = Y[i];
		}
	}
	/*
	//f
	double start = 0;
	double end = 1;
	double *f = (double *)malloc(sizeof(double)*Num );
	linspace( start,end ,Num,f );
	for ( i=0;i<Num/2;i++ )
	{
		f[i] = f[i]*m_Fs/2;
	}
	*/


	//Vrmsx
	double *Vrmsx = (double *)malloc(sizeof(double)*( Num-1) );
	int K = 0;
	double maxValue = 0;
	for ( i=0;i<Num;i++ )
	{
		Vrmsx[i] = fabs(HAR[i])*sqrt(2.0)/(m_windowSize*0.35875); 
		if ( maxValue<Vrmsx[i] )
		{
			 maxValue = Vrmsx[i];
			 K = i;
		}
	}

	//funda
//	double funda = f[K];

	//Vrms1
	double sumVrmsx = 0;
	for ( i=K-5;i<=K+5;i++ )
	{
		sumVrmsx += pow( Vrmsx[i],2 );
	}
	double Vrms1 = sqrt( sumVrmsx );

	//har_rms
	double sumKVrmsx = 0;
	int index;
	for ( i=2;i<=m_THD_ORD;i++ )
	{
		index = i*K;
		sumKVrmsx += pow( Vrmsx[index],2 );
	}
	double har_rms = sqrt( sumKVrmsx );
	 
	//HAR_plus_Noise
	sumVrmsx = 0;
	for ( i=0;i<Num;i++ )
	{
		sumVrmsx += pow( Vrmsx[i],2 );
	}
	double HAR_plus_Noise = sqrt( sumVrmsx-pow(Vrms1,2) );

	*thdn = 20 * log( HAR_plus_Noise/Vrms1) / log(10.0);

	free( signalWidthWindow );
	//free( f );
	free( Y );
	free( data1_double );
	data1_hex.clear();
	vector<string>().swap(data1_hex);

	free( data2_double );
	data2_hex.clear();
	vector<string>().swap(data2_hex);

	return true;

}

