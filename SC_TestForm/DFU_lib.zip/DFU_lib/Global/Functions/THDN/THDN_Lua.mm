/*
** Lua binding: THDN
** Generated automatically by tolua++-1.0.92 on Sun Sep  6 01:41:48 2015.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_THDN_open (lua_State* tolua_S);

#include "ThdnInter.h"

/* function to release collected object via destructor */
#ifdef __cplusplus

static int tolua_collect_CInterface (lua_State* tolua_S)
{
 CInterface* self = (CInterface*) tolua_tousertype(tolua_S,1,0);
	Mtolua_delete(self);
	return 0;
}
#endif


/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"CInterface");
}

/* method: new of class  CInterface */
#ifndef TOLUA_DISABLE_tolua_THDN_CInterface_new00
static int tolua_THDN_CInterface_new00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CInterface",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CInterface* tolua_ret = (CInterface*)  Mtolua_new((CInterface)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CInterface");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: new_local of class  CInterface */
#ifndef TOLUA_DISABLE_tolua_THDN_CInterface_new00_local
static int tolua_THDN_CInterface_new00_local(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CInterface",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CInterface* tolua_ret = (CInterface*)  Mtolua_new((CInterface)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CInterface");
    tolua_register_gc(tolua_S,lua_gettop(tolua_S));
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: delete of class  CInterface */
#ifndef TOLUA_DISABLE_tolua_THDN_CInterface_delete00
static int tolua_THDN_CInterface_delete00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CInterface",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CInterface* self = (CInterface*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'delete'", NULL);
#endif
  Mtolua_delete(self);
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'delete'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: THDN_Matlab of class  CInterface */
#ifndef TOLUA_DISABLE_tolua_THDN_CInterface_THDN_Matlab00
static int tolua_THDN_CInterface_THDN_Matlab00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CInterface",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CInterface* self = (CInterface*)  tolua_tousertype(tolua_S,1,0);
  char* right = ((char*)  tolua_tostring(tolua_S,2,0));
  char* left = ((char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'THDN_Matlab'", NULL);
#endif
  {
   double tolua_ret = (double)  self->THDN_Matlab(right,left);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'THDN_Matlab'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: THDN_OneLine of class  CInterface */
#ifndef TOLUA_DISABLE_tolua_THDN_CInterface_THDN_OneLine00
static int tolua_THDN_CInterface_THDN_OneLine00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CInterface",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CInterface* self = (CInterface*)  tolua_tousertype(tolua_S,1,0);
  char* data = ((char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'THDN_OneLine'", NULL);
#endif
  {
   double tolua_ret = (double)  self->THDN_OneLine(data);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'THDN_OneLine'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: THDN_TwoLine of class  CInterface */
#ifndef TOLUA_DISABLE_tolua_THDN_CInterface_THDN_TwoLine00
static int tolua_THDN_CInterface_THDN_TwoLine00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CInterface",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CInterface* self = (CInterface*)  tolua_tousertype(tolua_S,1,0);
  char* right = ((char*)  tolua_tostring(tolua_S,2,0));
  char* left = ((char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'THDN_TwoLine'", NULL);
#endif
  {
   double tolua_ret = (double)  self->THDN_TwoLine(right,left);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'THDN_TwoLine'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_THDN_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  #ifdef __cplusplus
  tolua_cclass(tolua_S,"CInterface","CInterface","",tolua_collect_CInterface);
  #else
  tolua_cclass(tolua_S,"CInterface","CInterface","",NULL);
  #endif
  tolua_beginmodule(tolua_S,"CInterface");
   tolua_function(tolua_S,"new",tolua_THDN_CInterface_new00);
   tolua_function(tolua_S,"new_local",tolua_THDN_CInterface_new00_local);
   tolua_function(tolua_S,".call",tolua_THDN_CInterface_new00_local);
   tolua_function(tolua_S,"delete",tolua_THDN_CInterface_delete00);
   tolua_function(tolua_S,"THDN_Matlab",tolua_THDN_CInterface_THDN_Matlab00);
   tolua_function(tolua_S,"THDN_OneLine",tolua_THDN_CInterface_THDN_OneLine00);
   tolua_function(tolua_S,"THDN_TwoLine",tolua_THDN_CInterface_THDN_TwoLine00);
  tolua_endmodule(tolua_S);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_THDN (lua_State* tolua_S) {
 return tolua_THDN_open(tolua_S);
};
#endif

