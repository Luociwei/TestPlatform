//
//  ThdnInter.h
//  Global
//
//  Created by IvanGan on 15/9/6.
//  Copyright (c) 2015年 ___sc Automation___. All rights reserved.
//

#ifndef __Global__ThdnInter__
#define __Global__ThdnInter__

#include <stdio.h>
#include "THDN.h"

class CInterface
{
private:
    CTHDN * mThdn;
public:
    CInterface();
    ~CInterface();
    
    
    double THDN_Matlab( char* right,char* left);
    double THDN_OneLine( char* data);
    double THDN_TwoLine( char* right,char* left);
};



#endif /* defined(__Global__ThdnInter__) */
