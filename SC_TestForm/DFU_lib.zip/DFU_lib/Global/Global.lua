--Global
local modname=...;
local M={};
_G[modname]=M;
package.loaded[modname]=M;


local mid = 0
if(ID) then mid = ID end
print("< "..mid.." > Load Global lua...\r\n")
if(tc and tc.AppDir()) then
package.cpath = package.cpath..";"..tostring(tc.AppDir()).."/?.dylib"
else
package.cpath = package.cpath..";".."./?.dylib"
end
require "libGlobal"
print("\r\n< "..mid.." > Load Global lua Success...\r\n")


local __CMD_LIST={
	{"now",	"Now",		"Fucntion: Get uut id"},
    {"delay",   "Delay",      "Fucntion: Get uut id"},
	{"bitsel",	         "BitSelect",		                 "Function: set a02 output voltage e.g. a02output -w 2.5"},
	{"setbit",	         "set_bit",		             "Function: set battery voltage,   e.g. setbattvolt -w 2.5"},
	{"clrbit",	         "clr_bit",		             "Function: read battery voltage,   e.g. readbattvolt"},
	{"getbit",	     "get_bit",		         "Function: set battery voltage,   e.g. battpoweroff"},
	{"bit_and",	         "bit_and",		             "Function: set battery voltage,   e.g. battpoweron"},
	{"bitor",	 "bit_or",	 "Function: set battery voltage,   e.g. battdischargefloat"},
	{"bitnot", "bit_not",	 "Function: set battery voltage,   e.g. battdischargeconnect"},
	{"bitxor",	     "bit_xor",		         "Function: set battery voltage,   e.g. battpoweroff"},
	{"bit_and",	         "bit_and",		             "Function: set battery voltage,   e.g. battpoweron"},
	{"bitnor",	 "bit_nor",	 "Function: set battery voltage,   e.g. battdischargefloat"},
}


function M.listFunction()
	local  str = ''
	for i=1, #__CMD_LIST do
		for j=1,3 do
			str = str..__CMD_LIST[i][j]..";"
		end
	end
	return str;
end

function get_bit(data,bit)
	if(bit == 0) then
		return math.mod(data,2)
	else
		return math.mod(math.floor((data/math.pow(2,bit))),2)
	end
end

local pathTmp = "/Users/ivangan/Desktop/"
if(tc and tc.AppDir()) then
	pathTmp = tc.AppDir()
    package.path = package.path..";"..tostring(tc.AppDir()).."Driver/?.lua"
else
    package.path = package.path..";".."./?.lua"
end

PRINT_LOG = 1
function _Print_Log_(par,...)
	if(PRINT_LOG) then
		local t = {...}
		if(t[1]) then
			print(string.format(par,...))
		else
			print(par)
		end
	end
end

TemplateFilePath = pathTmp.. "/match/"
TemplateVariantTable = {}
TemplatePatternTable = {}
Variant_Table = {}--key has no {{}} --global variant  = result table
_TOLERANCE_ = 0.5

_PDCA_KEY_MATCH_ = "{{(.-)}}"

function _Add_Global_Variant(var, val)
	if(var ~= nil) then
		Variant_Table[var] = val
		if(PdcaLogOut) then
			PdcaLogOut(tostring(var) .. " = " .. tostring(val));
		end
	end
end

function delay(par)
	Delay(tonumber(par))
	return 0;
end

function ghstation(par) --par={'par1','par2'}
	local ret = nil
	if(tc) then ret = tostring(tc.StationName()) end
	if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end

function channel(par)
	local ret = nil
	if(ID) then ret = tostring(ID) end
	if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end

function getUnitSN(par)
	local ret = nil
	if(tc) then ret = tostring(tc.mlbSN()) end
	if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end

function getPanelSN(par)
	local ret = nil
	if(tc) then ret = tostring(tc.PanelSN()) end
	if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end

function getBuildEvent(par)
	local ret = nil
	if(tc) then ret = tostring(tc.BuildEvent()) end
	if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end

function getSBUILD(par)
	local ret = nil
	if(tc) then ret = tostring(tc.SBuild()) end
	if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end

function reference()
return nil, "TBD"
end

function station(par)
	local ret = nil
 	local tmp = tc.StationName()
    if(tmp == "PREFCT" or tmp == "PREFCT2" or tmp == "FCT") then
        ret = "PRESMT2"
    else
-- if(tmp == nil or tmp=="SMT-QT0" or tmp == "COMBINE-FCT") then
        ret = "POSTSMT2"
    end
    if(par and par[2]) then
		local gVariant = string.match(par[2], _PDCA_KEY_MATCH_)
		_Add_Global_Variant(gVariant,ret)
	end
	return ret;
end