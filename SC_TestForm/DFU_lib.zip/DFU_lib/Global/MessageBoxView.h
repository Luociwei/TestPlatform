//
//  MessageBoxView.h
//  Global
//
//  Created by mac on 16/9/15.
//  Copyright © 2016年 ___sc Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

@interface MessageBoxView : NSObject
{
    
}

-(int)ShowMessageBox:(NSString  *)msg;

@end
