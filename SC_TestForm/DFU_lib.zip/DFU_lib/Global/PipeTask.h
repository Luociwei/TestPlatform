//
//  PipeTask.h
//  Global
//
//  Created by mac on 2017/1/17.
//  Copyright © 2017年 ___sc Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PipeTask : NSObject
{
    NSPipe * m_pipein;
    NSPipe * m_pipeout;
    NSTask * m_task;
    NSFileHandle * m_fread;
    NSFileHandle * m_fwrite;
    bool alive;
    NSMutableString *outBuffer;
    NSThread *threadLoop;
}

-(void *)pStart:(const char *)cmd;
-(char *)pRead;
-(char *)pReadBuf;
-(int)pWrite:(char *)cmd;
-(int)pClose;
-(bool)isAlive;
-(int)waitdetect:(char *)str timeout:(int)timeout;


@end
