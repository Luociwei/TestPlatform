//
//  PipeTask.m
//  Global
//
//  Created by mac on 2017/1/17.
//  Copyright © 2017年 ___sc Automation___. All rights reserved.
//

#import "PipeTask.h"

@implementation PipeTask

-(id)init
{
    m_pipein = [NSPipe new];
    m_pipeout = [NSPipe new];
    m_task = [[NSTask alloc]init];
    m_fread = [[NSFileHandle alloc]initWithFileDescriptor:[[m_pipeout fileHandleForReading]fileDescriptor]];
    m_fwrite = [[NSFileHandle alloc] initWithFileDescriptor:[[m_pipein fileHandleForWriting]fileDescriptor]];
    outBuffer = [[NSMutableString alloc]init];
    alive = YES;
    NSLog(@"start");
    return self;
}

-(void *)pStart:(const char *)cmd
{
    NSArray * arg = [[NSString stringWithUTF8String:cmd] componentsSeparatedByString:@" "];
    NSArray * arguments=nil;
    if ([arg count]>1)
    {
        arguments = [arg subarrayWithRange:NSMakeRange(1, [arg count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    
    [m_task setLaunchPath:[arg objectAtIndex:0]];
    [m_task setArguments:arguments];
    [m_task setStandardOutput:m_pipeout];
    [m_task setStandardError:m_pipeout];
    [m_task setStandardInput:m_pipein];
    [m_task launch];

    
    threadLoop = [[NSThread alloc] initWithTarget:self selector:@selector(performReadBackgroundThread) object:nil];
    [threadLoop start];
 

    return 0;
}



-(int)performReadBackgroundThread
{
    while (true)
    {
        NSLog(@"--performReadBackgroundThread--");
        if ([[NSThread currentThread] isCancelled])
        {
            NSLog(@"Thread cancelled!");
            return -2;  //cancel
        }
        
        
        @try {
            // NSData *outData = [m_fread readDataOfLength:100];
            NSData *outData = [m_fread availableData];
            NSLog(@"=========::::Background:%s",[outData bytes]);
            if ([outData length]>0)
            {
                NSLog(@"outData length]>0");
                NSString *str = [[NSString alloc] initWithData:outData encoding:NSASCIIStringEncoding];
                if (str!=nil)
                {
                    @synchronized(outBuffer)
                    {
                        [outBuffer appendString:str];
                      //NSLog(@"=========::::outBuff:%@",outBuffer);
                    }
                    [str release];
                }
            }
        }
        @catch (NSException *exception)
        {
            NSLog(@"NSException read end of available data");
        }
        if(![m_task isRunning]) break;
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
}

-(char *)pRead
{
//    NSLog(@"pRead:%s",[outBuffer UTF8String]);
    char *rdata;
    @synchronized(outBuffer)
    {
       rdata = (char *)[outBuffer UTF8String];
        [outBuffer setString:@""];
    }
    return rdata;
}


-(char *)pReadBuf
{
//    NSLog(@"pReadBuf:%s",[outBuffer UTF8String]);
    return (char *)[outBuffer UTF8String];
}


-(int)waitdetect:(char *)str timeout:(int)timeout
{
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            return -2;      //timeout
        }
        
        @synchronized (outBuffer)
        {
            if ([outBuffer length] > 0)
            {
                NSRange range  = [outBuffer rangeOfString:[NSString stringWithUTF8String:str]];
                
                if (range.location != NSNotFound)
                {
                    return 0;
                }
            }
        }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
    return 0;
}


-(int)pWrite:(char *)cmd
{
    if (![m_task isRunning]) {
        return -1;
    }
    [m_fwrite writeData:[NSData dataWithBytes:cmd length:strlen(cmd)]];
    return 0;
}

-(int)pClose
{
    kill(m_task.processIdentifier, SIGKILL);
    [[m_pipein fileHandleForWriting] closeFile];
    [[m_pipeout fileHandleForReading]closeFile];
    [m_pipein release];
    [m_pipeout release];
    [m_task release];
    [m_fread release];
    [m_fwrite release];
    [threadLoop cancel];
    [threadLoop release];
    return 0;
}

-(bool)isAlive
{
    return [m_task isRunning];
}


-(void)dealloc
{
    [self pClose];
    [super dealloc];
}

@end
