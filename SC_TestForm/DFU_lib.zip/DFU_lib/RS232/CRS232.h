//
//  CRS232.h
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//

#ifndef CRS232_h
#define CRS232_h

#import <Foundation/Foundation.h>
#include <stdio.h>
#include "SerialPort.h"
#include <string>

#import <pthread.h>

#include "Publisher.hpp"
#include "Replier.hpp"

class CRS232 : CPubliser, CReplier, CSerialPort
{
public:
    CRS232();
    ~CRS232();
public:
    int CreateIPC(const char * reply, const char * publish);
    int Open(const char * dev, const char * opt);//opt:"9600,8,n,1"
    int Close();
    
    int WriteString(const char * buffer);
    int WriteString2(char * szText);
    int WriteBytes(unsigned char * ucData, int len);
    int WriteBytes2(unsigned char* ucData, int len);
    int WriteStringBytes(const char * szData);//"0xFF,0xFE,..."
    
    int WriteSerial(const char * str);
    const char * ReadSerial();
    
    int PubMsg(const char * msg);
    int PublishLog(const char * msg);
    const char * StringMatch(const char * matchVal);
    
    const char * ReadString();
    const char * ReadBytes();
    const char * ReadStringBytes();
    const char * getSerialPorts();
    const char * ReadPowerString();             //Read data without '\0'
	
    void ClearBuffer();
    void ClearPubMsg();
    
    int SetDetectString(const char * det);
    int WaitDetect(int timeout);//msec
    int WaitDetect2(int timeout,int null_timeout); 
    
    const char * WriteReadString(const char * buffer,int timeout);
    
    
    int SetMutableArr();
    int ClearMutableArr();
    const char * ArrayMatch(const char * matchVal,int index);  // index from  0,1,2,3
    const char * ArrayFind(const char * val,int index); // index from  0,1,2,3
    
    int SetRepOpt(int needReply, int timeout=3000);//set bNeedReplay
    int SetPubOpt(int needPub);//it will publish command which is from function writeXXX
    int SetPrompt(const char *prompt);
    
    int WritePassControlBit(int stationid,char * szCmd);

    const char * CheckPreviousCB(int stationID, int uutID);
    const char * CheckAllowedFailCount(int stationID, int uutID);
    int InitialProcessControl(int stationID, int auditMode, int uutID);
    int FinalProcessControl(int stationID, int uutID, const char * serialNumber, const char * swversion, int testresult);
    BOOL SetStationIncomplete(int stationID, int uID);
    // new add function, calculate pass key
    BOOL MakePassKey(unsigned char * passKey, int uutID);
    const char * CalHash(const char * buffer,int stationID);
    void SaveData(NSString *str);
    const char* QuerySfcParams(char* szHttp);
protected:
    virtual void * OnRequest(void * pdata, long len);
    virtual void * didReceiveData(void * data, long len);

private:
    pthread_mutex_t m_mutex;
    pthread_mutex_t m_lockOperate;
    
    NSMutableString * m_strBuffer;
    NSMutableData * m_DataBuffer;
    NSMutableString * m_strDetect;
    NSMutableString * strReturn;
    NSLock* m_lockBuffer;
    NSMutableArray * m_arrBuffer;
    
    bool bNeedZmq;  //YES: will pub data from COM
                    //this will initial in "CreatIPC".
    
    bool bNeedReply; // YES: will reply data from data, or it will return "OK" or "Fail"
    int iTimeout;//msec
    bool bNeedPub;
    NSString * m_dev;
    NSString * m_opt;
    NSString * m_prompt;
    
    NSString * m_reply;
    NSString * m_publish;
    
    
    bool bFilterUnreadable;
    bool bFilterColorCode;
    
    NSMutableString * m_strPubBuffer;
    int pub_frequence;
    int is_iboot;
    //NSTimeInterval i_pubstarttime;
    //NSTimeInterval i_pubnow;
};

#endif /* CRS232_hpp */
