//
//  CRS232.cpp
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//

#include "CRS232.h"
#include "AMSerialPort.h"
#include "AMSerialPortList.h"
#include "zmq.h"

#include <iostream>
#include <sstream>

#include <unistd.h>
//#include "../Common/lib/get_hash.h"
#import "get_hash.h"
#import "CBAuth_API.h"
#import "InstantPudding_API.h"
#import "RegexKitLite.h"


NSLock * g_LockCB = [[NSLock alloc]init];

CRS232::CRS232()
{
    NSLog(@"CRS232 created");
    pthread_mutex_init(&m_mutex,nil);
    pthread_mutex_init(&m_lockOperate, nil);
    m_strBuffer = [[NSMutableString alloc]init];
    m_DataBuffer = [[NSMutableData alloc]init];
    m_strDetect = [[NSMutableString alloc]init];
    strReturn = [[NSMutableString alloc] init];
    m_dev = [[NSString alloc]init];
    m_opt = [[NSString alloc]init];
    
    m_reply = [[NSString alloc]init];
    m_publish = [[NSString alloc]init];
    
    m_strPubBuffer = [[NSMutableString alloc] init];
    
    m_lockBuffer = [[NSLock alloc]init];
    m_prompt=[[NSString alloc]init];
    m_prompt=@"";
    bNeedZmq = false;
    bNeedReply = false;
    bNeedPub = false;
    iTimeout = 3000;
    bFilterUnreadable = false;
    bFilterColorCode = true;
    
    //i_pubstarttime = [[NSDate date]timeIntervalSince1970];
    //i_pubnow = [[NSDate date]timeIntervalSince1970];
    pub_frequence = 0;
    is_iboot = 0;
    m_arrBuffer = [[NSMutableArray alloc] init];

}

CRS232::~CRS232()
{
    CPubliser::close();
    CReplier::close();
    Close();
    NSLog(@"CRS232 closed---");
    std::cout<<"CRS232 close()"<<std::endl;
    pthread_mutex_destroy(&m_mutex);
    pthread_mutex_destroy(&m_lockOperate);
    [m_strDetect release];
    [m_strBuffer release];
    [m_DataBuffer release];
    [m_dev release];
    [m_opt release];
    [m_reply release];
    [m_publish release];
    [m_prompt release];
    [m_lockBuffer release];
    [m_strPubBuffer release];
    [strReturn release];
    [m_arrBuffer release];
}

int CRS232::CreateIPC(const char * reply, const char * publish)
{
    CPubliser::close();
    CReplier::close();
    NSLog(@"closing RS232 binding");
    
    CPubliser::bind(publish);
    CReplier::bind(reply);
    bNeedZmq = true;
    
    m_reply = [NSString stringWithUTF8String:reply];
    m_publish = [NSString stringWithUTF8String:publish];
    return 0;
}
void CRS232::ClearPubMsg()
{
    [m_strPubBuffer setString:@""];
    
}

void * CRS232::didReceiveData(void * data, long len)
{
   /* if(len < 0)
    {
        return nullptr;
    }
    //pthread_mutex_lock(&m_mutex);
    //[m_lockBuffer lock];
    //[m_DataBuffer appendBytes:(Byte*)data length:len];
    //[m_lockBuffer unlock];
    
//    if(bNeedZmq)
//    {
//        Pulish(data, len);
//    }
    char * p = (char *)data;
    for(long i=0;i<len;i++)
    {
       if(p[i]=='\0')
           p[i] ='.';
    }
    NSMutableString *str = [[NSMutableString alloc] initWithBytes:data length:len encoding:NSUTF8StringEncoding];
    if (!str)
    {
        str = [NSMutableString stringWithFormat:@"%s",data];
    }
    if (str)
    {
        [m_lockBuffer lock];
        [m_strBuffer appendString:str];
        [m_strPubBuffer appendString:str];
        [m_lockBuffer unlock];
        
        if (CPubliser::m_socket && [m_strPubBuffer containsString:@":-)"])
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
            
        }
        else if ( CPubliser::m_socket && [m_strPubBuffer containsString:@"\n"])
        {
           
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
        }
    }
    [str release];
    pthread_mutex_unlock(&m_mutex);
    return nullptr;*/
    
    
    if (len<=0)
    {
        return nullptr;
    }
    char * p = (char *)data;
    for(long i=0;i<len;i++)
    {
       if(p[i]=='\0')
           p[i] ='.';
    }
    NSMutableString *str = [[NSMutableString alloc] initWithBytes:data length:len encoding:NSUTF8StringEncoding];
    if (!str)
    {
        str = [NSMutableString stringWithFormat:@"%s",data];
    }
    if (str)
    {
        /*NSString * timeLog;
        if ([str containsString:@"\n"])
        {
            timeLog = [NSString stringWithFormat:@"%@/n",str];
            if (CPubliser::m_socket)
            {
                Pulish((void *)[timeLog UTF8String], [timeLog length]);
            }
        }
         else if ([str containsString:@"\\>"] || [str containsString:@":-)"])
         {
             timeLog = [NSString stringWithFormat:@"%@\n",str];
             if (CPubliser::m_socket) {
                 Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
             }
         }
         else
         {
            timeLog = [NSString stringWithFormat:@"%@\n",str];
         }
        */
        
        [m_strPubBuffer appendFormat:@"%@",str];
        if (CPubliser::m_socket && ([m_strPubBuffer containsString:@":-)"] || [m_strPubBuffer containsString:@"\\>"]))
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
            
        }
        else if ( CPubliser::m_socket && [m_strPubBuffer containsString:@"\n"])
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
        }

        pthread_mutex_lock(&m_mutex);
        [m_strBuffer appendFormat:@"%@",str];
        if ([m_strBuffer length] > 10*1000000)  //如果缓存buff 超过10M，则处理
        {
            [m_strBuffer deleteCharactersInRange:NSMakeRange(0, 9*1000000)]; //删除9M
        }
        pthread_mutex_unlock(&m_mutex);
        
    }
    if (str)
    {
         [str release];
    }
    return nullptr;

}

int CRS232::SetRepOpt(int needReply, int timeout)
{
    bNeedReply = (needReply>0) ? YES : NO;
    iTimeout = timeout;
    return 0;
}

int CRS232::SetPubOpt(int needPub)
{
    bNeedPub = (needPub>0) ? YES : NO;
    return 0;
}

int CRS232::SetPrompt(const char *prompt)
{
    m_prompt=[NSString stringWithUTF8String:prompt];
    return 0;
}

void * CRS232::OnRequest(void * pData, long len)
{
    pthread_mutex_lock(&m_lockOperate);
//    if(bNeedPub)
//    {
//        Pulish(pData,len);
//    }
     NSString * str = [[NSString alloc] initWithBytes:pData length:len encoding:NSUTF8StringEncoding];
    
    if ([str isEqualToString:@"reconnect"])
    {
        if (m_dev && [m_dev length] > 0)
        {
            CSerialPort::close();
            Open([m_dev UTF8String],[m_opt UTF8String]);
        }
        
        NSLog(@"recv reconnect command");
    }
    [str release];
    
    int err = CSerialPort::write(pData, len);
    if(bNeedReply == NO)
        CReplier::SendStrig((err>=0)?"OK":"Fail");
    else
    {
        if([m_strDetect length]>0)
            WaitDetect(iTimeout);
        CReplier::SendStrig(ReadString());
    }
    pthread_mutex_unlock(&m_lockOperate);
    return nullptr;
}

int CRS232::Open(const char * dev, const char * opt)//opt:"9600,8,n,1"
{
    //int set_opt(int nSpeed, int nBits, char nEvent, int nStop);
    NSString * str = [NSString stringWithUTF8String:opt];
    NSLog(@"%@",str);
    NSArray * arr = [str componentsSeparatedByString:@","];
    int nSpeed = 9600;
    int nBits = 8;
    char nEvent = 'n';
    int nStop = 1;
    if([arr count]==4)
    {
        nSpeed = [[arr objectAtIndex:0]intValue];
        nBits = [[arr objectAtIndex:1]intValue];
        const char * tmp = [[arr objectAtIndex:2]UTF8String];
        nEvent = tmp[0];
        nStop = [[arr objectAtIndex:3]intValue];
    }
    
    int ret = CSerialPort::connect(dev);
    if (ret<0)
    {
        return ret;
    }
    m_dev = [NSString stringWithUTF8String:dev];
    m_opt = [NSString stringWithUTF8String:opt];
    ret = CSerialPort::set_opt(nSpeed, nBits, nEvent, nStop);
    return ret;
}

int CRS232::PubMsg(const char * msg)
{
    NSString *str=[NSString stringWithUTF8String:msg];
    if ([str length]>0)
    {
        PulishString([[NSString stringWithFormat:@"%@",str] UTF8String]);
        return 0;
    }
    
    return -1;
}

int CRS232::PublishLog(const char * msg)
{
    NSString *str=[NSString stringWithUTF8String:msg];
    if ([str length]>0)
    {
        PulishString([[NSString stringWithFormat:@"%@",str] UTF8String]);
        return 0;
    }
    
    return -1;
}


int CRS232::WriteString(const char * buffer)
{
    
    //NSString * str = [NSString stringWithFormat:@"%s", buffer];
    NSString *str=[NSString stringWithUTF8String:buffer];
    if(bNeedZmq && bNeedPub)
    {
        NSString *strPub=[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        strPub=[strPub stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strPub = [strPub stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        if ([strPub length]>0)
        {
            PulishString([[NSString stringWithFormat:@"%@%@",m_prompt,str] UTF8String]);
        }
        
    }
    
    int ret=CSerialPort::write((void*)buffer, [str length]);
    if (ret<0)
    {
        //Close();
        CSerialPort::close();
        Open([m_dev UTF8String],[m_opt UTF8String]);
        //CreateIPC([m_reply UTF8String], [m_publish UTF8String]);
        sleep(1);
        ret=CSerialPort::write((void*)buffer, [str length]);
        NSLog(@"######try second time send #####");
        
    }
    return ret;
}

int CRS232::WriteString2(char * szText)
{
    NSString * string = [NSString stringWithUTF8String:szText];
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    const char *dataBytes = (const char*)[data bytes];
    NSUInteger dataLen = [data length];
    
    return CSerialPort::write2(dataBytes, dataLen);
 
}

int CRS232::WriteBytes(unsigned char * ucData, int len)
{   
    if(bNeedZmq && bNeedPub)
    {
        Pulish((void*)ucData, len);
    }
    return CSerialPort::write((void*)ucData, len);
}

int CRS232::WriteBytes2(unsigned char* ucData, int len)
{
    NSData *data = [NSData dataWithBytes:ucData length:len];
    const char *dataBytes = (const char*)[data bytes];
    NSUInteger dataLen = [data length];
    return CSerialPort::write2(dataBytes, dataLen);
}


int CRS232::WriteStringBytes(const char * szData)//"0xFF,0xFE,..."
{
    
    if(szData == NULL) return -1;
    if(strlen(szData)<=0) return -2;
    NSArray * arr = [[NSString stringWithUTF8String:szData] componentsSeparatedByString:@","];
    if([arr count]< 1) return -3;
    int size = (int)[arr count];
    unsigned char * ucData = new unsigned char [size];
    for(int i=0; i<size; i++)
    {
        NSScanner * scanner = [NSScanner scannerWithString:[arr objectAtIndex:i]];
        unsigned int tmp;
        [scanner scanHexInt:&tmp];
        ucData[i] = tmp;
    }
    if(bNeedZmq && bNeedPub)
    {
        NSString *szStr=[NSString stringWithUTF8String:szData];
       // Pulish((void*)ucData, size);
        NSString *strPub=[szStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        strPub=[strPub stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strPub = [strPub stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        if ([strPub length]>0)
        {
            PulishString([[NSString stringWithFormat:@"%@%@",m_prompt,szStr] UTF8String]);
        }

        
    }
    CSerialPort::write((void*)ucData, size);
    return 0;
}

void CRS232::ClearBuffer()
{
    [m_strBuffer setString:@""];
    [m_DataBuffer setLength:0];
}




/*
 ============================================ANSI控制码的说明
 [0m 关闭所有属性
 [1m 设置高亮度
 [4m 下划线
 [5m 闪烁
 [7m 反显
 [8m 消隐
 [30m -- [37m 设置前景色
 [40m -- [47m 设置背景色
 [nA 光标上移n行
 [nB 光标下移n行
 [nC 光标右移n行
 [nD 光标左移n行
 [y;xH设置光标位置
 [2J 清屏
 [K 清除从光标到行尾的内容
 [s 保存光标位置
 [u 恢复光标位置
 [?25l 隐藏光标   //[25;01H "
 [?25h 显示光标
 */
const char * CRS232::ReadString()
{
    pthread_mutex_lock(&m_mutex);
    if (m_strBuffer) {

        [strReturn setString:m_strBuffer];
        [m_strBuffer setString:@""];
    }
    else
    {
        [strReturn setString:@""];
    }
    
    pthread_mutex_unlock(&m_mutex);
    return [strReturn UTF8String];
}

int CRS232::WriteSerial(const char * str)
{
    NSString * cmd = [NSString stringWithFormat:@"%s", str];
    return CSerialPort::write((void*)[cmd UTF8String], [cmd length]);
}

const char * CRS232::ReadSerial()
{
    char buff[200] = {'\0'};
    CSerialPort::read(buff,200);
    NSString * str = [NSString stringWithFormat:@"%s", buff];
    return [str UTF8String];
}

const char * CRS232::ReadBytes()
{
    if([m_DataBuffer length]>0)
    {
        [m_lockBuffer lock];
        NSData * data = [NSData dataWithData:m_DataBuffer];
        [m_DataBuffer setLength:0];
        [m_strBuffer setString:@""];
        [m_lockBuffer unlock];
        return (const char*)[data bytes];
    }
    else
        return NULL;
    
}

const char * CRS232::ReadStringBytes()
{
    NSUInteger len = [m_DataBuffer length];
    if(len>0)
    {
        Byte * pByte = (Byte*)[m_DataBuffer bytes];
        [strReturn setString:@""];
        for(int i= 0; i<[m_DataBuffer length]-1; i++)
        {
            [strReturn appendFormat:@"0x%02X,",pByte[i]];
        }
        [strReturn appendFormat:@"0x%02X,",pByte[len -1]] ;
        [m_DataBuffer setLength:0];
        [m_strBuffer setString:@""];
        return [strReturn UTF8String];
    }
    else
        return NULL;
}

const char * CRS232::ReadPowerString()
{
    NSUInteger len = [m_DataBuffer length];
    NSMutableData *mutdata = [[NSMutableData alloc] init] ;
    
    char *ptr = (char*)m_DataBuffer.bytes;
    for (int i=0; i<len; i++)
    {
        if (*(ptr+i)!='\0')
        [mutdata appendBytes:(ptr+i) length:1] ;
        else
         [mutdata appendBytes:" " length:1] ;
    }
    
    NSString * strBuf = [[NSString alloc] initWithBytes:mutdata.bytes length:mutdata.length encoding:NSASCIIStringEncoding] ;
    [m_lockBuffer lock];
    [m_DataBuffer setLength:0];
    [m_strBuffer setString:@""];
    [m_lockBuffer unlock];
    if (!strBuf)
    {
        [strBuf release];
        [mutdata release];
        return NULL;
    }
    
    NSString * str = [NSString stringWithString:strBuf];
    [strBuf release];
    [mutdata release];
    return [str UTF8String];
}

int CRS232::WaitDetect(int timeout)
{
    int r = -1;
    //    NSLog(@" * * * * * \ndylib Detect :%@ * * * * * \n",m_strStringToDetect);
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSLog(@"starting to wait : %@",m_strDetect);
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            r = -2;
            break;
        }
        
        pthread_testcancel();       //if is cancel,exist current loop.
        
        //if([m_strBuffer containsString:m_MutableDetect])
        pthread_mutex_lock(&m_mutex);
        NSRange range  = [m_strBuffer rangeOfString:m_strDetect];
        pthread_mutex_unlock(&m_mutex);
        
        if (range.location != NSNotFound)
        {
            r = 0;
            break;
        }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
    
    NSLog(@"waiting finished : %d",r);
    return r;  //cancel
}

int CRS232::WaitDetect2(int timeout,int null_timeout)
{
    int r = -1;
    //    NSLog(@" * * * * * \ndylib Detect :%@ * * * * * \n",m_strStringToDetect);
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    //NSLog(@"starting to wait : %@",m_strDetect);
    NSTimeInterval starttime_empty = [[NSDate date]timeIntervalSince1970];
    double tm_empty = (double)null_timeout/1000.0;
    NSUInteger str_length = 0;
    
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            r = -2;
            break;
        }
        
        pthread_testcancel();       //if is cancel,exist current loop.
        
        //if([m_strBuffer containsString:m_MutableDetect])
        pthread_mutex_lock(&m_mutex);
        NSRange range  = [m_strBuffer rangeOfString:m_strDetect];
        pthread_mutex_unlock(&m_mutex);
        
        if (range.location != NSNotFound)
        {
            r = 0;
            break;
        }
        if ((now-starttime_empty)>=tm_empty)
        {
           starttime_empty = [[NSDate date]timeIntervalSince1970];
           if (m_strBuffer.length > str_length)
           {
               str_length = m_strBuffer.length;
           }
           else
           {
               r = -5;
               NSLog(@"time out for waiting...");
               break;
           }
         }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.001];
    }
    
    NSLog(@"waiting finished : %d",r);
    return r;  //cancel
}

int CRS232::SetDetectString(const char * det)
{
    [m_strDetect setString:[NSString stringWithUTF8String:det]];
    return 0;
}

const char * CRS232::WriteReadString(const char * buffer,int timeout)
{
    pthread_mutex_lock(&m_lockOperate);
    WriteString(buffer);
    WaitDetect(timeout);
    NSString * str = [NSString stringWithUTF8String:ReadString()];
    pthread_mutex_unlock(&m_lockOperate);
    return [str UTF8String];
}

int CRS232::Close()
{
    std::cout<<"RS232 publisher close()"<<std::endl;
    //CPubliser::close();
    //CReplier::close();
    CSerialPort::close();
    return 0;
}



#pragma mark Write Pass ControlBit
//static int __GetHash(Byte ucpNonce[20],Byte hash[20],int stationid)
//{
//    int status=0;
////    [g_LockCB lock];
////    switch (stationid) {
////        case 0x00:  //DFU
////            status = get_dfu_hash(ucpNonce, hash);
////            break;
////        case 0x01:  //FCT
////            status = get_fct_hash(ucpNonce, hash);
////            break;
////        case 0x02:  //SOC
////            status = get_soc_hash(ucpNonce, hash);
////            break;
////        default:    //Other
////            status = get_station_hash(stationid, ucpNonce, hash);
////            break;
////    }
////    //int status = get_fct_hash(ucpNonce, hash);
////    [g_LockCB unlock];
//    return status;
//}

static int __GetHash(Byte ucpNonce[20],Byte hash[20],int stationid)
{
    
    int status=0;
    [g_LockCB lock];
    switch (stationid) {
        case 0x00:  //DFU
            status = get_dfu_hash(ucpNonce, hash);
            break;
        case 0x01:  //FCT
            status = get_fct_hash(ucpNonce, hash);
            break;
        case 0x02:  //SOC
           // status = get_soc_hash(ucpNonce, hash);
            break;
        case 0x06:  // g-1
            status = get_G_1_hash(ucpNonce, hash);
            break;
        default:    //Other
            status = get_station_hash(stationid, ucpNonce, hash);
            break;
    }
    [g_LockCB unlock];
    return status;
}

int CRS232::WritePassControlBit(int stationid,char * szCmd)
{

    ClearBuffer();
    SetDetectString((char*)":-)");
    WriteString2((char*)"getnonce\n");
    PubMsg("getnonce\n");
    WaitDetect(10000);
    NSData* dataResult =m_DataBuffer ;
    int iCnt1 = 0;
    while ((dataResult==nil || [dataResult length] != 55) && (iCnt1 < 3))
    {
        ClearBuffer();
        SetDetectString((char*)":-)");
        WriteString2((char*)"getnonce\n");
        WaitDetect(10000);
        dataResult = m_DataBuffer;
        iCnt1++;
    }
    
    if (dataResult == nil || [dataResult length] != 55) return -1;//failed to get nonce
    Byte *byte = (Byte *)[dataResult bytes] ;
    if (byte == NULL) return -101;
    for(int i=0 ;i<[dataResult length] ;i++)
    {
        NSLog(@"\n %d",*(byte+i)) ;
    }
    //Get the password
    unsigned char ucpNonce[20];
    unsigned char hash[20];
    memset(ucpNonce, 0, sizeof(ucpNonce));
    memset(hash, 0, sizeof(hash));
    memcpy(ucpNonce, byte+10, 20);
    NSLog(@"\n start getnonce 20 bytes") ;
    for(int i=0 ;i<20 ;i++)
    {
        NSLog(@"\n %d",ucpNonce[i]) ;
    }
    int status  = 0;
    status = __GetHash(ucpNonce, hash,stationid);
    if(status != 0) return -2;//failed to get hash
    ClearBuffer();
    SetDetectString(const_cast<char *>(">"));
    WriteString2(szCmd);
    WaitDetect(5000);
    usleep(100000);
    
    if (ReadString() == NULL) return -3;//failed to send cbwrite
    usleep(100000);
    
    SetDetectString((char*)":-)");
    //CTcpClient::send(hash, sizeof(hash));
    WriteBytes2(hash, sizeof(hash));
    WaitDetect(5000);
    usleep(100*1000);
    const char* szRtn = ReadString();
    if (strstr(szRtn, "Passed") != NULL) return 0;
    return -5;
    
}

//add by Phily 2017.2.16
const char * CRS232::getSerialPorts()
{
    NSEnumerator *enumerator = [AMSerialPortList portEnumerator];
    AMSerialPort *aPort = nil;
    NSString *retPorts = @"";
    while (aPort = [enumerator nextObject]) {
        // print port name
        retPorts = [retPorts stringByAppendingString:[aPort bsdPath]];
        retPorts = [retPorts stringByAppendingString:@";"];
    }
    return [retPorts UTF8String];
}

const char * CRS232::CheckPreviousCB(int stationID, int uutID)
{
    NSString *str = @"0,ok";
    
    //NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    BOOL reply = NO;
    const int StationNameMaxLength = 256;
    size_t stationCount = 0;
    char ** stationNames = NULL;
    int * stationIDs = NULL;
    
    do
    {
        if (stationID > 2)
        {
            NSLog(@"[CheckPreviousCB] Station ID %d is not acceptable.", stationID);
            str = @"-1,Check previous CB fail.";
            break;
        }
        
        //Find out the number of control bits we need to check
        [g_LockCB lock];
        reply = ControlBitsToCheck(NULL,&stationCount,NULL);
        [g_LockCB unlock];
        
        if (!reply)
        {
            NSLog(@"[CheckPreviousCB] ControlBitsToCheck return false. Assuming nothing to check. StationCount = %lu.", stationCount);
            stationCount = 0;
        }
        
        if (stationCount == 0)
        {
            NSLog(@"[CheckPreviousCB] ControlBitsToCheck return 0 size.");
            str = @"0,ok";
            break;
        }
        
        // Get the actual names and station id
        stationNames = (char**) malloc(sizeof(char*) * stationCount);
        for (int i = 0; i < stationCount; i++)
        {
            stationNames[i] = (char*) malloc(sizeof(char) * StationNameMaxLength);
            memset(stationNames[i], 0, sizeof(char) * StationNameMaxLength);
        }
        stationIDs = (int*) malloc(sizeof(int) * stationCount);
        memset(stationIDs, 0, stationCount);
        
        [g_LockCB lock];
        reply = ControlBitsToCheck(stationIDs, &stationCount, stationNames);
        [g_LockCB unlock];
        
        if (!reply)
        {
            NSLog(@"[CheckPreviousCB] Failed to get station names and results.");
            str = @"-1,Check previous CB fail.";
            break;
        }
        
        for (int s = 0; s < stationCount; s++)
        {
            // Check the bits on the DUT
            BOOL thisStationResult = NO;
            
            // Modify by Herry, 2016.08.24
            // Write command to serial port and check the return stirng, if wait timeout, try again. Maximam 3 times.
            NSInteger nLoopTime = 0;
            
            while(1)
            {
                // Modify by Herry, 2016.08.22
                // Set detect string and clear buffer
                SetDetectString(">");
                NSLog(@"[CheckPreviousCB] (CBREAD) Set detect string and clear buffer %ld time.", nLoopTime);
                
                // Make command and write to serial port
                NSString * cmd = [NSString stringWithFormat:@"[CBREAD-%d]\r", stationIDs[s]];
                [NSThread sleepForTimeInterval:0.1];
                WriteString([cmd UTF8String]);
                NSLog(@"[CheckPreviousCB] (CBREAD) Write string %ld time = %@.", nLoopTime, cmd);
                
                // Modify by Herry, 2016.08.22
                // Wait detect, timeout 3s
                int nRet = WaitDetect(3000);
                
                if(nRet == 1)
                {
                    // Read string from serial port
                    NSString * response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[CheckPreviousCB] (CBREAD) Read string %ld time = %@.", nLoopTime, response);
                    
                    // Correct return string format: "[CBREAD-S] <cbread-S:T-V-AEC-AFC-RFC-R>"
                    // "S": stationID, number
                    // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                    // "V": overlay version, string
                    // "AEC": absolute erase count, number
                    // "AFC": absolute fail count, number
                    // "RFC": relative fail count, number
                    // "R": one of U(untested), I(incomplete), F(Failed), P(Passed)
                    
                    // Check string format
                    if(![response containsString:[NSString stringWithFormat:@"%@ <cbread-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationIDs[s]]])
                    {
                        NSLog(@"[CheckPreviousCB] (CBREAD) Read string not correct.");
                        str = @"-1,Check previous CB fail.";
                        thisStationResult = NO;
                        break;
                    }
                    
                    // Check read state
                    thisStationResult = [response containsString:@"-P>"];
                    if(!thisStationResult)
                    {
                        str = [NSString stringWithFormat:@"-1,0x%02x %s not PASS.", stationIDs[s], stationNames[s]];
                    }
                    
                    break;
                    
                }
                else if(nRet == -1)
                {
                    // Read from serial port
                    NSString * response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[CheckPreviousCB] (CBREAD) WaitDetect: Timeout %ld time. String = %@.", nLoopTime, response);
                    
                    if(nLoopTime < 2)   // Less than 3 times
                    {
                        // Send [SR] (System Reset)
                        NSInteger nInside = 0;
                        while(nInside < 2)
                        {
                            SetDetectString("FATP");
                            [NSThread sleepForTimeInterval:0.1];
                            WriteString("[SR]\r");
                            if(WaitDetect(10000) != 1)
                            {
                                nInside ++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        nLoopTime ++;
                    }
                    else    // Reach 3 times
                    {
                        NSLog(@"[CheckPreviousCB] (CBREAD) WaitDetect: Timeout 3 times.");
                        str = @"-1,Check previous CB fail.";
                        thisStationResult = NO;
                        break;
                    }
                }
                else if(nRet == -2)
                {
                    NSLog(@"[CheckPreviousCB] (CBREAD) WaitDetect: Thread is cancelled.");
                    str = @"-1,Check previous CB fail.";
                    thisStationResult = NO;
                    break;
                }
                else
                {
                    NSLog(@"[CheckPreviousCB] (CBREAD) WaitDetect: Unknown error.");
                    str = @"-1,Check previous CB fail.";
                    thisStationResult = NO;
                    break;
                }
            }
            
            if (!thisStationResult)
            {
                NSLog(@"[CheckPreviousCB] DUT failed at %s (0x%02x)", stationNames[s], stationIDs[s]);
                break;
            }
        }
    }
    while (0);
    
    // Cleanup
    if (stationNames)
    {
        for (int i = 0; i < stationCount; i++)
        {
            if (stationNames[i])
            {
                free(stationNames[i]);
            }
        }
        free(stationNames);
    }
    if (stationIDs)
    {
        free(stationIDs);
    }
    
    //[pool release];
    
    return [str UTF8String];
}

const char * CRS232::CheckAllowedFailCount(int stationID, int uutID)
{
    NSString *str = @"0,ok";
    
    //NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    int failAllowed = -1;
    
    // Get Fail allowed
    [g_LockCB lock];
    failAllowed = StationFailCountAllowed();
    [g_LockCB unlock];
    
    if(failAllowed < 0)
    {
        NSLog(@"[CheckAllowedFailCount] Don't need to compare fail count.");
        str = @"0,ok";
        return [str UTF8String];
    }
    
    // Write command to serial port and check the return string, if wait timeout, try again. Maximam 3 times.
    NSInteger nLoopTime = 0;
    while(1)
    {
        // Modify by Herry, 2016.08.22
        // Set detect string and clear buffer
        SetDetectString(">");
        
        // Make command and write to serial port
        NSString * cmd = [NSString stringWithFormat:@"[CBREAD-%d]\r", stationID];
        [NSThread sleepForTimeInterval:0.1];
        WriteString([cmd UTF8String]);
        NSLog(@"[CheckAllowedFailCount] (CBREAD) Write string %ld time = %@.", nLoopTime, cmd);
        
        // Modify by Herry, 2016.08.22
        // Wait detect, timeout 3s
        int nRet = WaitDetect(3000);
        
        if(nRet == 1)
        {
            // Read string from serial port
            NSString * response = [NSString stringWithUTF8String:ReadString()];
            NSLog(@"[CheckAllowedFailCount] (CBREAD) Read string %ld time = %@.", nLoopTime, response);
            
            // Correct return string format: "[CBREAD-S] <cbread-S:T-V-AEC-AFC-RFC-R>"
            // "S": stationID, number
            // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
            // "V": overlay version, string
            // "AEC": absolute erase count, number
            // "AFC": absolute fail count, number
            // "RFC": relative fail count, number
            // "R": one of U(untested), I(incomplete), F(Failed), P(Passed)
            
            // Check string format
            NSArray * responseValues = [response componentsSeparatedByString:@"-"];
            // String should be separated to 8 parts by "-".
            if((![response containsString:[NSString stringWithFormat:@"%@ <cbread-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]]) || ([responseValues count] != 8))
            {
                NSLog(@"[CheckAllowedFailCount] (CBREAD) Read string not correct.");
                str = @"-1,Check allowed fail count fail.";
                return [str UTF8String];
            }
            
            // Compare actual fail count with allowed fail count
            int numberOfFailures = [[responseValues objectAtIndex:6] intValue];
            if(numberOfFailures > failAllowed)
            {
                NSLog(@"[CheckAllowedFailCount] Fail count (%d) > allowed (%d).", numberOfFailures, failAllowed);
                str = [NSString stringWithFormat:@"-1,Relative Fail Count: %d %d.", numberOfFailures, failAllowed];
                return [str UTF8String];
            }
            
            str = @"0,ok";
            return [str UTF8String];
        }
        else if(nRet == -1)
        {
            // Read string from serial port
            NSString * response = [NSString stringWithUTF8String:ReadString()];
            NSLog(@"[CheckAllowedFailCount] (CBREAD) WaitDetect: Timeout %ld time. String = %@.", nLoopTime, response);
            
            if(nLoopTime < 2)   // Less than 3 times
            {
                // Send [SR] (System Reset)
                NSInteger nInside = 0;
                while(nInside < 2)
                {
                    SetDetectString("FATP");
                    [NSThread sleepForTimeInterval:0.1];
                    WriteString("[SR]\r");
                    if(WaitDetect(10000) != 1)
                    {
                        nInside ++;
                    }
                    else
                    {
                        break;
                    }
                }
                nLoopTime ++;
            }
            else    // Reach 3 times
            {
                NSLog(@"[CheckAllowedFailCount] (CBREAD) WaitDetect: Timeout 3 times.");
                str = @"-1,Check allowed fail count fail.";
                return [str UTF8String];
            }
        }
        else if(nRet == -2)
        {
            NSLog(@"[CheckAllowedFailCount] (CBREAD) WaitDetect: Thread is cancelled.");
            str = @"-1,Check allowed fail count fail.";
            return [str UTF8String];
        }
        else
        {
            NSLog(@"[CheckAllowedFailCount] (CBREAD) WaitDetect: Unknown error.");
            str = @"-1,Check allowed fail count fail.";
            return [str UTF8String];
        }
    }
    
    //[pool release];
}

int CRS232::InitialProcessControl(int stationID, int auditMode, int uutID)
{
    if(auditMode == 0)  // When not audit mode, set CB to I
    {
        return SetStationIncomplete(stationID, uutID) ? 0 : -1;
    }
    else    // When audit mode, always set CB to F, write to AFC+1 times.
    {
        // Get fail allowed count
        int failAllowed = 0;
        [g_LockCB lock];
        failAllowed = StationFailCountAllowed();
        [g_LockCB unlock];
        
        if(failAllowed > 0)
        {
            // Write command to serial port and check the return stirng, if wait timeout, try again. Maximam 3 times.
            NSInteger nLoopTime = 0;
            while(1)
            {
                // Modify by Herry, 2016.08.22
                // Set detect string and clear buffer
                SetDetectString(">");
                NSLog(@"[InitialProcessControl] (CBREAD) Set detect string and clear buffer %ld time.", nLoopTime);
                
                // Make command and write to serial port
                NSString * cmd = [NSString stringWithFormat:@"[CBREAD-%d]\r", stationID];
                [NSThread sleepForTimeInterval:0.1];
                WriteString([cmd UTF8String]);
                NSLog(@"[InitialProcessControl] (CBREAD) Write string = %@.", cmd);
                
                // Modify by Herry, 2016.08.22
                // Wait detect, timeout 3s
                int nRet = WaitDetect(3000);
                
                if(nRet == 1)
                {
                    // Read string from serial port
                    NSString * response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[InitialProcessControl] (CBREAD) Read string %ld time = %@.", nLoopTime, response);
                    
                    // Correct return string format: "[CBREAD-S] <cbread-S:T-V-AEC-AFC-RFC-R>"
                    // "S": stationID, number
                    // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                    // "V": overlay version, string
                    // "AEC": absolute erase count, number
                    // "AFC": absolute fail count, number
                    // "RFC": relative fail count, number
                    // "R": one of U(untested), I(incomplete), F(Failed), P(Passed)
                    
                    // Check string format
                    NSArray * responseValues = [response componentsSeparatedByString:@"-"];
                    if((![response containsString:[NSString stringWithFormat:@"%@ <cbread-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]]) || ([responseValues count] != 8))
                    {
                        NSLog(@"[InitialProcessControl] (CBREAD) Read string not correct.");
                        return -1;
                    }
                    
                    // Calculate the difference between actual fail count and allowed fail count
                    int num = failAllowed - [[responseValues objectAtIndex:6] intValue] + 1;
                    
                    if(num > 0)
                    {
                        // Set CB to "F", num times
                        for(int i = 0; i < num; i ++)
                        {
                            // Modify by Herry, 2016.08.22
                            // Set detect string and clear buffer
                            SetDetectString(">");
                            NSLog(@"[InitialProcessControl] (CBWRITE) Set detect stirng and clear buffer.");
                            
                            // Get timestamp
                            NSDate *date = [NSDate new];
                            long time = [date timeIntervalSince1970];
                            
                            // Make pass key
                            unsigned char passKey[41];
                            memset(passKey, '0', sizeof(passKey));
                            passKey[40]='\0';
                            
                            // Make command and write to serial port
                            cmd = [NSString stringWithFormat:@"[CBWRITE-%d-%s-%ld-0-F]\r", stationID, passKey, time];
                            [NSThread sleepForTimeInterval:0.1];
                            WriteString([cmd UTF8String]);
                            NSLog(@"[InitialProcessControl] (CBWRITE) Write string = %@.", cmd);
                            
                            // Modify by Herry, 2016.08.22
                            // Wait detect, timeout 3s
                            nRet = WaitDetect(3000);
                            
                            if(nRet == 1)
                            {
                                // Read string from serial port
                                response = [NSString stringWithUTF8String: ReadString()];
                                NSLog(@"[InitialProcessControl] (CBWRITE) Read string = %@.",response);
                                
                                // Correct return string format: "[CBWRITE-S-K-T-V-R1] <cbwrite-S:R2>"
                                // "S": stationID, number
                                // "K": pass key, 20-byte number in ASCII Hex format
                                // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                                // "V": overlay version, string
                                // "R1": one of F(Failed), P(Passed)
                                // "R2": one of ok, fail
                                
                                // Check string format
                                if(![response containsString:[NSString stringWithFormat:@"%@ <cbwrite-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]])
                                {
                                    NSLog(@"[InitialProcessControl] (CBWRITE) Read string not correct.");
                                    return -1;
                                }
                                
                                // Check write result
                                if(![response containsString:@"ok"])
                                {
                                    NSLog(@"[InitialProcessControl] (CBWRITE) Set CB to F fail.");
                                    return -1;
                                }
                            }
                            else if(nRet == -1)
                            {
                                NSLog(@"[InitialProcessControl] (CBWRITE) WaitDetect: Timeout.");
                                return -1;
                            }
                            else if(nRet == -2)
                            {
                                NSLog(@"[InitialProcessControl] (CBWRITE) WaitDetect: Thread is cancelled.");
                                return -1;
                            }
                            else
                            {
                                NSLog(@"[InitialProcessControl] (CBWRITE) WaitDetect: Unknown error.");
                                return -1;
                            }
                        }
                    }
                    
                    return 0;
                }
                else if(nRet == -1)
                {
                    // Read string from serial port
                    NSString * response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect: Timeout %ld time. String = %@.", nLoopTime, response);
                    
                    if(nLoopTime < 2)   // Less than 3 times
                    {
                        // Send [SR] (System Reset)
                        NSInteger nInside = 0;
                        while(nInside < 2)
                        {
                            SetDetectString("FATP");
                            [NSThread sleepForTimeInterval:0.1];
                            WriteString("[SR]\r");
                            if(WaitDetect(10000) != 1)
                            {
                                nInside ++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        nLoopTime ++;
                    }
                    else    // Reach 3 times
                    {
                        NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect timeout 3 times.");
                        return -1;
                    }
                }
                else if(nRet == -2)
                {
                    NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect: Thread is cancelled.");
                    return -1;
                }
                else
                {
                    NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect: Unknown error.");
                    return -1;
                }
            }
        }
        else if(failAllowed == -1)
        {
            // Write command to serial port and check the return stirng, if wait timeout, try again. Maximam 3 times.
            NSInteger nLoopTime = 0;
            while(1)
            {
                // ----- Add by Herry, 2016.08.23 Start -----
                // Change CB write logic, when in audit mode, if CONTROL_BIT_TO_CHECK is OFF, read CB first
                // if state is "F", skip
                // if state is "P", write Fail one time
                
                // Set detect string and clear buffer
                SetDetectString(">");
                NSLog(@"[InitialProcessControl] (CBREAD) Set detect string and clear buffer %ld time.", nLoopTime);
                
                // Make command and write to serial port
                NSString * cmd = [NSString stringWithFormat:@"[CBREAD-%d]\r", stationID];
                [NSThread sleepForTimeInterval:0.1];
                WriteString([cmd UTF8String]);
                NSLog(@"[InitialProcessControl] (CBREAD) Write string %ld time = %@.", nLoopTime, cmd);
                
                // Wait detect, timeout 3s
                int nRet = WaitDetect(3000);
                
                if(nRet == 1)
                {
                    // Read string from serial port
                    NSString * response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[InitialProcessControl] (CBREAD) Read string %ld time = %@.", nLoopTime, response);
                    
                    // Correct return string format: "[CBREAD-S] <cbread-S:T-V-AEC-AFC-RFC-R>"
                    // "S": stationID, number
                    // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                    // "V": overlay version, string
                    // "AEC": absolute erase count, number
                    // "AFC": absolute fail count, number
                    // "RFC": relative fail count, number
                    // "R": one of U(untested), I(incomplete), F(Failed), P(Passed)
                    
                    // Check string format
                    if(![response containsString:[NSString stringWithFormat:@"%@ <cbread-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]])
                    {
                        NSLog(@"[InitialProcessControl] (CBREAD) Read string not correct.");
                        return -1;
                    }
                    
                    // ----- Add by Herry, 2016.08.23 End -----
                    
                    // Check read state
                    if([response containsString:@"-F>"])
                    {
                        NSLog(@"[InitialProcessControl] (CBREAD) Already fail, skip.");
                        return 0;
                    }
                    
                    // Modify by Herry, 2016.08.22
                    // Set detect string and clear buffer
                    SetDetectString(">");
                    NSLog(@"[InitialProcessControl] (CBWRITE) Set detect string and clear buffer.");
                    
                    // Get timestamp
                    NSDate *date = [NSDate new];
                    long time = [date timeIntervalSince1970];
                    
                    // Make pass key
                    unsigned char passKey[41];
                    memset(passKey, '0', sizeof(passKey));
                    passKey[40]='\0';
                    
                    // Make command and write to serial port
                    cmd = [NSString stringWithFormat:@"[CBWRITE-%d-%s-%ld-0-F]\r", stationID, passKey, time];
                    [NSThread sleepForTimeInterval:0.1];
                    WriteString([cmd UTF8String]);
                    NSLog(@"[InitialProcessControl] (CBWRITE) Write string = %@.",cmd);
                    
                    // Modify by Herry, 2016.08.22
                    // Wait detect, timeout 3s
                    nRet = WaitDetect(3000);
                    
                    if(nRet == 1)
                    {
                        // Read string from serial port
                        response = [NSString stringWithUTF8String: ReadString()];
                        NSLog(@"[InitialProcessControl] (CBWRITE) Read string = %@.",response);
                        
                        // Correct return string format: "[CBWRITE-S-K-T-V-R1] <cbwrite-S:R2>"
                        // "S": stationID, number
                        // "K": pass key, 20-byte number in ASCII Hex format
                        // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                        // "V": overlay version, string
                        // "R1": one of F(Failed), P(Passed)
                        // "R2": one of ok, fail
                        
                        // Check string format
                        if(![response containsString:[NSString stringWithFormat:@"%@ <cbwrite-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]])
                        {
                            NSLog(@"[InitialProcessControl] (CBWRITE) Read string not correct.");
                            return -1;
                        }
                        
                        // Check write result
                        if(![response containsString:@"ok"])
                        {
                            NSLog(@"[InitialProcessControl] (CBWRITE) Set CB to F fail.");
                            return -1;
                        }
                        
                        return 0;
                    }
                    else if(nRet == -1)
                    {
                        NSLog(@"[InitialProcessControl] (CBWRITE) WaitDetect: Timeout.");
                        return -1;
                    }
                    else if(nRet == -2)
                    {
                        NSLog(@"[InitialProcessControl] (CBWRITE) WaitDetect: Thread is cancelled.");
                        return -1;
                    }
                    else
                    {
                        NSLog(@"[InitialProcessControl] (CBWRITE) WaitDetect: Unknown error.");
                        return -1;
                    }
                }
                else if(nRet == -1)
                {
                    // Read string from serial port
                    NSString * response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect: Timeout %ld time. String = %@.", nLoopTime, response);
                    
                    if(nLoopTime < 2)   // Less than 3 times
                    {
                        // Send [SR] (System Reset)
                        NSInteger nInside = 0;
                        while(nInside < 2)
                        {
                            SetDetectString("FATP");
                            [NSThread sleepForTimeInterval:0.1];
                            WriteString("[SR]\r");
                            if(WaitDetect(10000) != 1)
                            {
                                nInside ++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        nLoopTime ++;
                    }
                    else    // Reach 3 times
                    {
                        NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect timeout 3 times.");
                        return -1;
                    }
                }
                else if(nRet == -2)
                {
                    NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect: Thread is cancelled.");
                    return -1;
                }
                else
                {
                    NSLog(@"[InitialProcessControl] (CBREAD) WaitDetect: Unknown error.");
                    return -1;
                }
            }
        }
        else
        {
            return 0;
        }
    }
}

int CRS232::FinalProcessControl(int stationID, int uutID, const char * serialNumber, const char * swversion, int testresult)
{
    BOOL isOkay = NO;
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    // Currently, __test_state (testresult) is being updated by Engine after all test items are finished.
    // As this is being called inline in the seqeucne, we ever get to the point __test_state gets updated.
    // For the time being, force testresult as pass.
    //testresult = 1;
    
    
    NSLog(@"--> FinalProcessControl start stationID(%d), serialNumber(%s), testresult(%d)", stationID, serialNumber, testresult);
    
    size_t stationCount = 0;
    BOOL reply;
    BOOL clearStatus = YES;
    int * stationsToBeReset = NULL;
    
    NSString * resultString = nil;
    NSString * readBackString = nil;
    
    bool (*ControlBitsToClearOnX)(int*,size_t*) = NULL;
    switch (testresult) {
        case 1:
            resultString = @"P";
            readBackString = @"P";
            ControlBitsToClearOnX = ControlBitsToClearOnPass;
            break;
        case 0:
            resultString = @"F";
            readBackString = @"F";
            ControlBitsToClearOnX = ControlBitsToClearOnFail;
            break;
        default:
            resultString = @"I";
            readBackString = @"I";
            ControlBitsToClearOnX = ControlBitsToClearOnFail;
            break;
    }
    
    do
    {
        //        if (!VerifyVersionAndSerialNumber(serialNumber, swversion))
        //        {
        //            NSLog(@"VerifyVersionAndSerialNumber reported NOT okay.");
        //            break;
        //        }
        
        // Clear bits
        reply = YES;
        [g_LockCB lock];
        reply = ControlBitsToClearOnX(NULL, &stationCount);
        [g_LockCB	unlock];
        
        if(!reply)
        {
            NSLog(@"[FinalProcessControl] Can't get ControlBitToClear on %@. Assuming nothing to clear.", resultString);
            stationCount = 0;
        }
        
        if (stationCount)
        {
            stationsToBeReset = (int*)malloc(sizeof(int) * stationCount);
            memset(stationsToBeReset, -1, stationCount);
            
            [g_LockCB lock];
            reply = ControlBitsToClearOnX(stationsToBeReset, &stationCount);
            [g_LockCB	unlock];
            
            // Clear all the stations as instructed.
            for (int i = 0; i < stationCount; i++)
            {
                // Somethings wrong?  ControlBitsToClearOnX didn't set the station ID...
                if (stationsToBeReset[i] < 0) continue;
                
                BOOL stationClearStatus = SetStationIncomplete(stationsToBeReset[i], uutID);
                if (!stationClearStatus)
                {
                    NSLog(@"[FinalProcessControl] Failed to clear station %d control-bit.", stationsToBeReset[i]);
                    // should we break?
                    clearStatus = NO;
                }
            }
        }
        
        if (!clearStatus)
        {
            NSLog(@"[FinalProcessControl] Failed to clear station control-bit. Stopping bit set.");
            break;
        }
        
        BOOL setCB;
        [g_LockCB lock];
        setCB = StationSetControlBit();
        [g_LockCB unlock];
        
        if (setCB)
        {
            // Modify by Herry, 2016.08.22
            // Set detect string and clear buffer
            SetDetectString(">");
            NSLog(@"[FinalProcessControl] (CBWRITE) Set detect string and clear buffer.");
            
            // Get timestamp
            NSDate *date = [NSDate new];
            long time = [date timeIntervalSince1970];
            
            // Make pass key
            unsigned char passKey[41];
            memset(passKey, '0', sizeof(passKey));
            passKey[40]='\0';
            if(testresult == 1)
            {
                if(!MakePassKey(passKey, uutID))
                {
                    break;
                }
            }
            
            // Make command and write to serial port
            NSString * cmd = [NSString stringWithFormat:@"[CBWRITE-%d-%s-%ld-0-%@]\r", stationID, passKey, time, resultString];
            [NSThread sleepForTimeInterval:0.1];
            WriteString([cmd UTF8String]);
            NSLog(@"[FinalProcessControl] (CBWRITE) Write string = %@.", cmd);
            
            // Modify by Herry, 2016.08.22
            // Wait detect, timeout 3s
            int nRet = WaitDetect(3000);
            
            if(nRet == 1)
            {
                // Read string form serial port
                NSString * response = [NSString stringWithUTF8String: ReadString()];
                NSLog(@"[FinalProcessControl] (CBWRITE) Read string = %@.",response);
                
                // Correct return string format: "[CBWRITE-S-K-T-V-R1] <cbwrite-S:R2>"
                // "S": stationID, number
                // "K": pass key, 20-byte number in ASCII Hex format
                // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                // "V": overlay version, string
                // "R1": one of F(Failed), P(Passed)
                // "R2": one of ok, fail
                
                // Check string format
                if(![response containsString:[NSString stringWithFormat:@"%@ <cbwrite-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]])
                {
                    NSLog(@"[FinalProcessControl] (CBWRITE) Read string not correct.");
                    isOkay = NO;
                    break;
                }
                
                // Check write result
                if(![response containsString:@"ok"])
                {
                    NSLog(@"[FinalProcessControl] (CBWRITE) Write result to CB fail.");
                    isOkay = NO;
                    break;
                }
                
                // Verify read state match write state or not
                
                // Set detect string and clear buffer
                SetDetectString(">");
                NSLog(@"[FinalProcessControl] (CBREAD) Set detect string and clear buffer.");
                
                // Make command and write to serial port
                cmd = [NSString stringWithFormat:@"[CBREAD-%d]\r", stationID];
                [NSThread sleepForTimeInterval:0.1];
                WriteString([cmd UTF8String]);
                NSLog(@"[FinalProcessControl] (CBREAD) Write string = %@.",cmd);
                
                // Wait detect, timeout 3s
                nRet = WaitDetect(3000);
                
                if(nRet == 1)
                {
                    // Read string from serial port
                    response = [NSString stringWithUTF8String: ReadString()];
                    NSLog(@"[FinalProcessControl] (CBREAD) Read string = %@.", response);
                    
                    // Correct return string format: "[CBWRITE-S-K-T-V-R1] <cbwrite-S:R2>"
                    // "S": stationID, number
                    // "K": pass key, 20-byte number in ASCII Hex format
                    // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
                    // "V": overlay version, string
                    // "R1": one of F(Failed), P(Passed)
                    // "R2": one of ok, fail
                    
                    // Check string format
                    if(![response containsString:[NSString stringWithFormat:@"%@ <cbread-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]])
                    {
                        NSLog(@"[FinalProcessControl] (CBREAD) Read string not correct.");
                        isOkay = NO;
                        break;
                    }
                    
                    // Compare read state with write state
                    if(![response containsString:readBackString])
                    {
                        NSLog(@"[FinalProcessControl] (CBREAD) Read cannot match write.");
                        isOkay = NO;
                        break;
                    }
                    
                    isOkay = YES;
                    break;
                }
                else if(nRet == -1)
                {
                    NSLog(@"[FinalProcessControl] (CBREAD) WaitDetect: Timeout.");
                    isOkay = NO;
                    break;
                }
                else if(nRet == -2)
                {
                    NSLog(@"[FinalProcessControl] (CBREAD) WaitDetect: Thread is cancelled.");
                    isOkay = NO;
                    break;
                }
                else
                {
                    NSLog(@"[FinalProcessControl] (CBREAD) WaitDetect: Unknown error.");
                    isOkay = NO;
                    break;
                }
            }
            else if(nRet == -1)
            {
                NSLog(@"[FinalProcessControl] (CBWRITE) WaitDetect: Timeout.");
                isOkay = NO;
                break;
            }
            else if(nRet == -2)
            {
                NSLog(@"[FinalProcessControl] (CBWRITE) WaitDetect: Thread is cancelled.");
                isOkay = NO;
                break;
            }
            else
            {
                NSLog(@"[FinalProcessControl] (CBWRITE) WaitDetect: Unknown error.");
                isOkay = NO;
                break;
            }
        }
        
        isOkay = YES;
        
    } while (0);
    
    if(stationsToBeReset)
    {
        free(stationsToBeReset);
    }
    
    [pool release];
    
    return isOkay ? 0 : -1;
}

BOOL CRS232::SetStationIncomplete(int stationID, int uutID)
{
    // Modify by Herry, 2016.08.23
    // Write command to serial port and check the return stirng, if wait timeout, try again. Maximam 3 times.
    NSInteger nLoopTime = 0;
    while(1)
    {
        // Modify by Herry, 2016.08.22
        // Set detect string and clear buffer
        SetDetectString(">");
        NSLog(@"[SetStationIncomplete] (CBWRITE) Set detect string and clear buffer %ld time.", nLoopTime);
        
        // Get timestamp
        NSDate *date = [NSDate new];
        long time = [date timeIntervalSince1970];
        
        // Make pass key
        // 20-byte ASCII Hex format
        unsigned char passKey[41];
        memset(passKey, '0', sizeof(passKey));
        passKey[40]='\0';
        
        // Make command and write to serial port
        NSString * cmd = [NSString stringWithFormat:@"[CBWRITE-%d-%s-%ld-0-I]\r", stationID, passKey, time];
        [NSThread sleepForTimeInterval:0.1];
        WriteString([cmd UTF8String]);
        NSLog(@"[SetStationIncomplete] (CBWRITE) Write string %ld time = %@.", nLoopTime, cmd);
        
        // Modify by Herry, 2016.08.22
        // Wait detect, timeout 3s
        int nRet = WaitDetect(3000);
        
        if(nRet == 1)
        {
            // Read string from serial port
            NSString * response = [NSString stringWithUTF8String: ReadString()];
            NSLog(@"[SetStationIncomplete] (CBWRITE) Read string %ld time = %@.", nLoopTime, response);
            
            // Correct return string format: "[CBWRITE-S-K-T-V-R1] <cbwrite-S:R2>"
            // "S": stationID, number
            // "K": pass key, 20-byte number in ASCII Hex format
            // "T": timestamp, number of seconds since 1970-01-01 00:00 GMT
            // "V": overlay version, string
            // "R1": one of F(Failed), P(Passed), I(imcomplete)
            // "R2": one of ok, fail
            
            // Check string format
            if(![response containsString:[NSString stringWithFormat:@"%@ <cbwrite-%d:", [cmd stringByReplacingOccurrencesOfString:@"\r" withString:@""], stationID]])
            {
                NSLog(@"[SetStationIncomplete] (CBWRITE) Read string not correct.");
                return NO;
            }
            
            // Check write result
            if(![response containsString:@"ok"])
            {
                NSLog(@"[SetStationIncomplete] (CBWRITE) Set CB to I fail.");
                return NO;
            }
            
            return YES;
        }
        else if(nRet == -1)
        {
            // Read string from serial port
            NSString * response = [NSString stringWithUTF8String: ReadString()];
            NSLog(@"[SetStationIncomplete] (CBWRITE) WaitDetect: Timeout %ld time. String = %@.", nLoopTime, response);
            
            if(nLoopTime < 2)   // Less than 3 times
            {
                // Send [SR] (System Reset)
                NSInteger nInside = 0;
                while(nInside < 2)
                {
                    SetDetectString("FATP");
                    [NSThread sleepForTimeInterval:0.1];
                    WriteString("[SR]\r");
                    if(WaitDetect(10000) != 1)
                    {
                        nInside ++;
                    }
                    else
                    {
                        break;
                    }
                }
                nLoopTime ++;
            }
            else    // Reach 3 times
            {
                NSLog(@"[SetStationIncomplete] (CBWRITE) WaitDetect: Timeout 3 times.");
                return NO;
            }
        }
        else if(nRet == -2)
        {
            NSLog(@"[SetStationIncomplete] (CBWRITE) WaitDetect: Thread is cancelled.");
            return NO;
        }
        else
        {
            NSLog(@"[SetStationIncomplete] (CBWRITE) WaitDetect: Unknown error.");
            return NO;
        }
    }
}

BOOL CRS232::MakePassKey(unsigned char * passKey, int uutID)
{
    // Modify bu Herry, 2016.08.22
    // Set detect string and clear buffer
    SetDetectString(">");
    NSLog(@"[MakePassKey] (CBNONCE) Set detect string and clear buffer.");
    
    // Make command and write to serial port
    NSString * cmd = @"[CBNONCE]\r";
    [NSThread sleepForTimeInterval:0.1];
    WriteString([cmd UTF8String]);
    NSLog(@"[MakePassKey] (CBNONCE) Write string = [CBNONCE].");
    
    // Modify by Herry, 2016.08.22
    // Wait detect, timeout 3s
    int nRet = WaitDetect(3000);
    
    if(nRet == 1)
    {
        // Read string from serial port
        NSString * response = [NSString stringWithUTF8String: ReadString()];
        NSLog(@"[MakePassKey] (CBNONCE) Read string = %@.",response);
        
        // Correct return string format: "[CBNONCE] <cbnonce:****************************************>"
        // "*": a-z,0-9
        
        // Check string format
        if(![response containsString:@"[CBNONCE] <cbnonce:"])
        {
            NSLog(@"[MakePassKey] (CBNONCE) Read string not correct.");
            return NO;
        }
        
        // Get 20-byte data in ASCII Hex format
        if([response length] < 60)
        {
            NSLog(@"[MakePassKey] (CBNONCE) Read string length not correct. Length = %lu.", (unsigned long)[response length]);
            return NO;
        }
        
        NSRange range = {19,40};
        NSString * nonce = [response substringWithRange:range];
        
        // Convert from ASCII Hex format to unsigned char [20]
        unsigned char szNonce[20];
        memset(szNonce, 0, sizeof(szNonce));
        for(int i = 0; i < 20; i ++)
        {
            unsigned char l = [nonce characterAtIndex:(2*i)];
            if(l >= '0' && l <= '9'){
                l = l - '0';
            }else if( l >= 'a' && l <= 'f'){
                l = l - 'a' + 10;
            }else{
                NSLog(@"[MakePassKey] (CBNONCE) Read wrong character: %c.", l);
                return NO;
            }
            
            unsigned char r = [nonce characterAtIndex:(2*i+1)];
            if(r >= '0' && r <= '9'){
                r = r - '0';
            }else if( r >= 'a' && r <= 'f'){
                r = r - 'a' + 10;
            }else{
                NSLog(@"[MakePassKey] (CBNONCE) Read wrong character: %c.", r);
                return NO;
            }
            
            szNonce[i] = ((l << 4) + r);
        }
        
        // Station key
        unsigned char stationKey[20] = {0x99,0xdd,0x55,0xfa,0xc2,0xf8,0x71,0x10,0xa9,0x6a,0xe4,0x00,0xb5,0x1e,0xa8,0xc1,0x90,0x96,0xd7,0x32};
        
        // Pass key
        unsigned char * key = NULL;
        
        // Computes a 20-byte pass key using the 20-byte station key and the nonce
        [g_LockCB lock];
        key = CreateSHA1(stationKey, szNonce);
        [g_LockCB unlock];
        
        // Compute pass key failed
        if(!key)
        {
            NSLog(@"[MakePassKey] Compute pass key failed.");
            return NO;
        }
        
        // Copy pass key
        unsigned char hash[20];
        memset(hash, 0, sizeof(hash));
        memcpy(hash, key, 20);
        
        // Free memory
        [g_LockCB lock];
        FreeSHA1Buffer(key);
        [g_LockCB unlock];
        
        // Convert from unsigned char [20] to ASCII Hex format
        for(int i = 0; i < 20; i ++)
        {
            unsigned char l = (hash[i] >> 4);
            if(l <= 9){
                l = l + '0';
            }else{
                l = l - 10 + 'a';
            }
            passKey[2*i] = l;
            
            unsigned char r = (hash[i] & 0xf);
            if(r <= 9){
                r = r + '0';
            }else{
                r = r - 10 + 'a';
            }
            passKey[2*i+1] = r;
        }
        
        NSLog(@"[MakePassKey] Make pass key ok.");
        return YES;
    }
    else if(nRet == -1)
    {
        NSLog(@"[MakePassKey] (CBNONCE) WaitDetect: Timeout.");
        return NO;
    }
    else if(nRet == -2)
    {
        NSLog(@"[MakePassKey] (CBNONCE) WaitDetect: Thread is cancelled.");
        return NO;
    }
    else
    {
        NSLog(@"[MakePassKey] (CBNONCE) WaitDetect: Unknown error.");
        return NO;
    }
}

const char * CRS232::CalHash(const char * buffer,int stationID)
{
    NSString *response = [NSString stringWithUTF8String:buffer];
    if(![response containsString:@"<cbnonce:"])
    {
        NSLog(@"(CBNONCE) Read string not correct.");
        return "error";
    }
    
    // Get 20-byte data in ASCII Hex format
    if([response length] < 50)
    {
        NSLog(@"(CBNONCE) Read string length not correct. Length = %lu.", (unsigned long)[response length]);
        return "error";
    }
    
    NSRange range = {9,40};
    NSString * nonce = [response substringWithRange:range];
    NSLog(@"this is %@",nonce);
    // Convert from ASCII Hex format to unsigned char [20]
    unsigned char szNonce[20];
    memset(szNonce, 0, sizeof(szNonce));
    for(int i = 0; i < 20; i ++)
    {
        unsigned char l = [nonce characterAtIndex:(2*i)];
        if(l >= '0' && l <= '9'){
            l = l - '0';
        }else if( l >= 'a' && l <= 'f'){
            l = l - 'a' + 10;
        }else{
            NSLog(@"(CBNONCE) Read wrong character: %c.", l);
            return "error";
        }
        
        unsigned char r = [nonce characterAtIndex:(2*i+1)];
        if(r >= '0' && r <= '9'){
            r = r - '0';
        }else if( r >= 'a' && r <= 'f'){
            r = r - 'a' + 10;
        }else{
            NSLog(@"(CBNONCE) Read wrong character: %c.", r);
            return "error";
        }
        
        szNonce[i] = ((l << 4) + r);
    }
    NSLog(@"SZnonce is %s",szNonce);
    
    //    unsigned char stationKey[20] = {0x99,0xdd,0x55,0xfa,0xc2,0xf8,0x71,0x10,0xa9,0x6a,0xe4,0x00,0xb5,0x1e,0xa8,0xc1,0x90,0x96,0xd7,0x32};
    
    unsigned char hash[20];
    memset(hash, 0, sizeof(hash));
    int status=0;
    [g_LockCB lock];
    status = get_station_hash(stationID, szNonce, hash);
    [g_LockCB unlock];
    if(status != 0)
        NSLog(@"status is %d",status);
    NSMutableString * str = [NSMutableString string];
    for(int i=0 ;i<20 ;i++)
    {
        [str appendFormat:@"%02x",hash[i]] ;
    }
    NSDate *date = [NSDate new];
    long time = [date timeIntervalSince1970];
    [str appendFormat:@"-%ld",time];
    return  [str UTF8String];

}

void CRS232::SaveData(NSString *str)
{
    NSMutableString *stringData = [NSMutableString string];
    //    std::cout << "hex dateData:";
    //    for (int i=0; i<[dateData length]; i++) {
    //        printf("%02X ",dByte[i]);
    //    }
    //    std::cout << std::endl;
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"\nyyyy/MM/dd HH:mm:ss.SSS : "];
    NSString * timestr = [dateFormatter1 stringFromDate:[NSDate date]];
    [stringData appendFormat:@"%@\t%@",timestr,str];
    [dateFormatter1 release];
    
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
    [dateFormatter2 setDateFormat:@"yyyy-MM-dd-HH"];
    NSDate* stopTime = [NSDate date];
    NSString * strStopTime=[dateFormatter2 stringFromDate:stopTime];
    [dateFormatter2 release];
    
    
    NSString *fileName = [NSString stringWithFormat:@"/vault/Suncode_log/%@_RS232Date.txt",strStopTime];
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:fileName]) {
        [fm createFileAtPath:fileName contents:nil attributes:nil];
    }
    NSFileHandle * fh = [NSFileHandle fileHandleForWritingAtPath:fileName];
    if(!fh) return;
    [fh seekToEndOfFile];
    [fh writeData:[stringData dataUsingEncoding:NSASCIIStringEncoding]];
    [fh closeFile];
}

const char* CRS232::QuerySfcParams(char* szHttp)
{
    //liang, remove string "/mlbt39"
    NSString* strHttp = [NSString stringWithUTF8String:szHttp];
    NSURL *SFC=[NSURL URLWithString:strHttp];
    NSString *strUsbCurrentCal=[NSString stringWithContentsOfURL:SFC encoding: NSASCIIStringEncoding error:NULL ];
    int count = 10;
    while(strUsbCurrentCal==nil && count >0)
    {
        usleep(400000);
        strUsbCurrentCal=[NSString stringWithContentsOfURL:SFC encoding: NSASCIIStringEncoding error:NULL];
        count--;
    }
    
    if (strUsbCurrentCal==nil)
    {
        return NULL;
    }else{
        return [strUsbCurrentCal UTF8String];
    }
    
    /*
     if(([strUsbCurrentCal rangeOfString:@"SFC_OK"].length>0) || ([strUsbCurrentCal rangeOfString:@"SFC OK"].length>0))
     {
     return [strUsbCurrentCal UTF8String];
     }
     return NULL;
     */
}


const char *CRS232::StringMatch(const char * matchVal)
{
    if ([m_strBuffer length]>0)
    {
        NSString *matchStr = [NSString stringWithUTF8String:matchVal];
        NSString * result = [m_strBuffer stringByMatching:matchStr capture:1];
        if ([result length]>0)
        {
            return [result UTF8String];
        }
        else
        {
            return "";
        }
    }
    return "";
}



int CRS232::SetMutableArr()
{
    NSString *ret = [NSString stringWithUTF8String:ReadString()];
    [m_arrBuffer addObject:ret];
    return 0;
}
int CRS232::ClearMutableArr()
{
    [m_arrBuffer removeAllObjects];
    return 0;
}

const char * CRS232::ArrayMatch(const char * matchVal,int index)
{
    if (index<0)
    {
        return "--FAIL--index less than 0";
    }
    if ([m_arrBuffer count]<=index)
    {
        return "--FAIL--index out of range";
    }
    NSString *matchStr = [NSString stringWithUTF8String:matchVal];
    NSString * result = [m_arrBuffer[index] stringByMatching:matchStr capture:1];
    if ([result length]>0)
    {
        return [result UTF8String];
    }
    else
    {
        return "";
    }
    
}

const char * CRS232::ArrayFind(const char * val,int index)
{
    if (index<0)
    {
        return "--FAIL--index less than 0";
    }
    if ([m_arrBuffer count]<=index)
    {
        return "--FAIL--index out of range";
    }
    NSString *valStr = [NSString stringWithUTF8String:val];
    BOOL ret = [m_arrBuffer[index] containsString:valStr];
    if (ret)
    {
        return "YES";
    }
    else
    {
        return "NO";
    }
}
