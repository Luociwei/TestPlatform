//
//  Interface.mm
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//
#import <Foundation/Foundation.h>
#include "Interface.h"
#include "tolua++.h"

TOLUA_API int tolua_RS232_open (lua_State* tolua_S);

extern "C" int luaopen_libRS232(lua_State * state)
{
    NSLog(@"Load RS232(SerialPort) Dylib --20210323 dimension dfu\r\n");
    tolua_RS232_open(state);
    
    return 0;
}
