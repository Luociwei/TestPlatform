

tolua=/usr/local/bin/tolua++

$tolua -o rs232_lua.mm RS232.pkg