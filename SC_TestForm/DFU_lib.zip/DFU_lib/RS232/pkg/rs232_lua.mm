/*
** Lua binding: RS232
** Generated automatically by tolua++-1.0.92 on Sat Apr 10 10:56:34 2021.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_RS232_open (lua_State* tolua_S);

#include "CRS232.h"

/* function to release collected object via destructor */
#ifdef __cplusplus

static int tolua_collect_CRS232 (lua_State* tolua_S)
{
 CRS232* self = (CRS232*) tolua_tousertype(tolua_S,1,0);
	Mtolua_delete(self);
	return 0;
}
#endif


/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"CRS232");
 tolua_usertype(tolua_S,"NSString");
}

/* method: new of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_new00
static int tolua_RS232_CRS232_new00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CRS232* tolua_ret = (CRS232*)  Mtolua_new((CRS232)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CRS232");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: new_local of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_new00_local
static int tolua_RS232_CRS232_new00_local(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CRS232* tolua_ret = (CRS232*)  Mtolua_new((CRS232)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CRS232");
    tolua_register_gc(tolua_S,lua_gettop(tolua_S));
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: delete of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_delete00
static int tolua_RS232_CRS232_delete00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'delete'", NULL);
#endif
  Mtolua_delete(self);
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'delete'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: CreateIPC of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_CreateIPC00
static int tolua_RS232_CRS232_CreateIPC00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* reply = ((const char*)  tolua_tostring(tolua_S,2,0));
  const char* publish = ((const char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'CreateIPC'", NULL);
#endif
  {
   int tolua_ret = (int)  self->CreateIPC(reply,publish);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'CreateIPC'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: Open of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_Open00
static int tolua_RS232_CRS232_Open00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* dev = ((const char*)  tolua_tostring(tolua_S,2,0));
  const char* opt = ((const char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'Open'", NULL);
#endif
  {
   int tolua_ret = (int)  self->Open(dev,opt);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'Open'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: Close of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_Close00
static int tolua_RS232_CRS232_Close00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'Close'", NULL);
#endif
  {
   int tolua_ret = (int)  self->Close();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'Close'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteString of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WriteString00
static int tolua_RS232_CRS232_WriteString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* buffer = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteString'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteString(buffer);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteBytes of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WriteBytes00
static int tolua_RS232_CRS232_WriteBytes00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  unsigned char* ucData = ((unsigned char*)  tolua_tostring(tolua_S,2,0));
  int len = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteBytes'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteBytes(ucData,len);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteBytes'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteStringBytes of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WriteStringBytes00
static int tolua_RS232_CRS232_WriteStringBytes00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* szData = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteStringBytes'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteStringBytes(szData);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteStringBytes'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteSerial of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WriteSerial00
static int tolua_RS232_CRS232_WriteSerial00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* str = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteSerial'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteSerial(str);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteSerial'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadSerial of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ReadSerial00
static int tolua_RS232_CRS232_ReadSerial00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadSerial'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadSerial();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadSerial'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: PubMsg of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_PubMsg00
static int tolua_RS232_CRS232_PubMsg00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* msg = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'PubMsg'", NULL);
#endif
  {
   int tolua_ret = (int)  self->PubMsg(msg);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'PubMsg'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: PublishLog of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_PublishLog00
static int tolua_RS232_CRS232_PublishLog00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* msg = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'PublishLog'", NULL);
#endif
  {
   int tolua_ret = (int)  self->PublishLog(msg);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'PublishLog'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadString of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ReadString00
static int tolua_RS232_CRS232_ReadString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadString'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadString();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadBytes of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ReadBytes00
static int tolua_RS232_CRS232_ReadBytes00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadBytes'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadBytes();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadBytes'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadStringBytes of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ReadStringBytes00
static int tolua_RS232_CRS232_ReadStringBytes00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadStringBytes'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadStringBytes();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadStringBytes'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: getSerialPorts of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_getSerialPorts00
static int tolua_RS232_CRS232_getSerialPorts00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'getSerialPorts'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->getSerialPorts();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'getSerialPorts'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadPowerString of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ReadPowerString00
static int tolua_RS232_CRS232_ReadPowerString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadPowerString'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadPowerString();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadPowerString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: StringMatch of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_StringMatch00
static int tolua_RS232_CRS232_StringMatch00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* matchVal = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'StringMatch'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->StringMatch(matchVal);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'StringMatch'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearBuffer of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ClearBuffer00
static int tolua_RS232_CRS232_ClearBuffer00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearBuffer'", NULL);
#endif
  {
   self->ClearBuffer();
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearBuffer'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearPubMsg of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ClearPubMsg00
static int tolua_RS232_CRS232_ClearPubMsg00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearPubMsg'", NULL);
#endif
  {
   self->ClearPubMsg();
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearPubMsg'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetDetectString of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_SetDetectString00
static int tolua_RS232_CRS232_SetDetectString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* det = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetDetectString'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetDetectString(det);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetDetectString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WaitDetect of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WaitDetect00
static int tolua_RS232_CRS232_WaitDetect00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int timeout = ((int)  tolua_tonumber(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WaitDetect'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WaitDetect(timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WaitDetect'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WaitDetect2 of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WaitDetect200
static int tolua_RS232_CRS232_WaitDetect200(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int timeout = ((int)  tolua_tonumber(tolua_S,2,0));
  int null_timeout = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WaitDetect2'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WaitDetect2(timeout,null_timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WaitDetect2'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteReadString of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WriteReadString00
static int tolua_RS232_CRS232_WriteReadString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* buffer = ((const char*)  tolua_tostring(tolua_S,2,0));
  int timeout = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteReadString'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->WriteReadString(buffer,timeout);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteReadString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetMutableArr of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_SetMutableArr00
static int tolua_RS232_CRS232_SetMutableArr00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetMutableArr'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetMutableArr();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetMutableArr'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearMutableArr of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ClearMutableArr00
static int tolua_RS232_CRS232_ClearMutableArr00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearMutableArr'", NULL);
#endif
  {
   int tolua_ret = (int)  self->ClearMutableArr();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearMutableArr'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ArrayMatch of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ArrayMatch00
static int tolua_RS232_CRS232_ArrayMatch00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* matchVal = ((const char*)  tolua_tostring(tolua_S,2,0));
  int index = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ArrayMatch'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ArrayMatch(matchVal,index);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ArrayMatch'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ArrayFind of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_ArrayFind00
static int tolua_RS232_CRS232_ArrayFind00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* val = ((const char*)  tolua_tostring(tolua_S,2,0));
  int index = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ArrayFind'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ArrayFind(val,index);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ArrayFind'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetRepOpt of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_SetRepOpt00
static int tolua_RS232_CRS232_SetRepOpt00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,1,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int needReply = ((int)  tolua_tonumber(tolua_S,2,0));
  int timeout = ((int)  tolua_tonumber(tolua_S,3,3000));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetRepOpt'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetRepOpt(needReply,timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetRepOpt'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetPubOpt of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_SetPubOpt00
static int tolua_RS232_CRS232_SetPubOpt00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int needPub = ((int)  tolua_tonumber(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetPubOpt'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetPubOpt(needPub);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetPubOpt'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetPrompt of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_SetPrompt00
static int tolua_RS232_CRS232_SetPrompt00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* prompt = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetPrompt'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetPrompt(prompt);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetPrompt'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WritePassControlBit of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_WritePassControlBit00
static int tolua_RS232_CRS232_WritePassControlBit00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int stationid = ((int)  tolua_tonumber(tolua_S,2,0));
  char* szCmd = ((char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WritePassControlBit'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WritePassControlBit(stationid,szCmd);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WritePassControlBit'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: CheckPreviousCB of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_CheckPreviousCB00
static int tolua_RS232_CRS232_CheckPreviousCB00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int stationID = ((int)  tolua_tonumber(tolua_S,2,0));
  int uutID = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'CheckPreviousCB'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->CheckPreviousCB(stationID,uutID);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'CheckPreviousCB'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: CheckAllowedFailCount of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_CheckAllowedFailCount00
static int tolua_RS232_CRS232_CheckAllowedFailCount00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int stationID = ((int)  tolua_tonumber(tolua_S,2,0));
  int uutID = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'CheckAllowedFailCount'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->CheckAllowedFailCount(stationID,uutID);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'CheckAllowedFailCount'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: InitialProcessControl of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_InitialProcessControl00
static int tolua_RS232_CRS232_InitialProcessControl00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,4,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,5,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int stationID = ((int)  tolua_tonumber(tolua_S,2,0));
  int auditMode = ((int)  tolua_tonumber(tolua_S,3,0));
  int uutID = ((int)  tolua_tonumber(tolua_S,4,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'InitialProcessControl'", NULL);
#endif
  {
   int tolua_ret = (int)  self->InitialProcessControl(stationID,auditMode,uutID);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'InitialProcessControl'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: FinalProcessControl of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_FinalProcessControl00
static int tolua_RS232_CRS232_FinalProcessControl00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isstring(tolua_S,4,0,&tolua_err) ||
     !tolua_isstring(tolua_S,5,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,6,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,7,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  int stationID = ((int)  tolua_tonumber(tolua_S,2,0));
  int uutID = ((int)  tolua_tonumber(tolua_S,3,0));
  const char* serialNumber = ((const char*)  tolua_tostring(tolua_S,4,0));
  const char* swversion = ((const char*)  tolua_tostring(tolua_S,5,0));
  int testresult = ((int)  tolua_tonumber(tolua_S,6,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'FinalProcessControl'", NULL);
#endif
  {
   int tolua_ret = (int)  self->FinalProcessControl(stationID,uutID,serialNumber,swversion,testresult);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'FinalProcessControl'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: CalHash of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_CalHash00
static int tolua_RS232_CRS232_CalHash00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  const char* buffer = ((const char*)  tolua_tostring(tolua_S,2,0));
  int stationID = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'CalHash'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->CalHash(buffer,stationID);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'CalHash'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SaveData of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_SaveData00
static int tolua_RS232_CRS232_SaveData00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"NSString",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  NSString* str = ((NSString*)  tolua_tousertype(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SaveData'", NULL);
#endif
  {
   self->SaveData(str);
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SaveData'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: QuerySfcParams of class  CRS232 */
#ifndef TOLUA_DISABLE_tolua_RS232_CRS232_QuerySfcParams00
static int tolua_RS232_CRS232_QuerySfcParams00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CRS232",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CRS232* self = (CRS232*)  tolua_tousertype(tolua_S,1,0);
  char* szHttp = ((char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'QuerySfcParams'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->QuerySfcParams(szHttp);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'QuerySfcParams'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_RS232_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  #ifdef __cplusplus
  tolua_cclass(tolua_S,"CRS232","CRS232","",tolua_collect_CRS232);
  #else
  tolua_cclass(tolua_S,"CRS232","CRS232","",NULL);
  #endif
  tolua_beginmodule(tolua_S,"CRS232");
   tolua_function(tolua_S,"new",tolua_RS232_CRS232_new00);
   tolua_function(tolua_S,"new_local",tolua_RS232_CRS232_new00_local);
   tolua_function(tolua_S,".call",tolua_RS232_CRS232_new00_local);
   tolua_function(tolua_S,"delete",tolua_RS232_CRS232_delete00);
   tolua_function(tolua_S,"CreateIPC",tolua_RS232_CRS232_CreateIPC00);
   tolua_function(tolua_S,"Open",tolua_RS232_CRS232_Open00);
   tolua_function(tolua_S,"Close",tolua_RS232_CRS232_Close00);
   tolua_function(tolua_S,"WriteString",tolua_RS232_CRS232_WriteString00);
   tolua_function(tolua_S,"WriteBytes",tolua_RS232_CRS232_WriteBytes00);
   tolua_function(tolua_S,"WriteStringBytes",tolua_RS232_CRS232_WriteStringBytes00);
   tolua_function(tolua_S,"WriteSerial",tolua_RS232_CRS232_WriteSerial00);
   tolua_function(tolua_S,"ReadSerial",tolua_RS232_CRS232_ReadSerial00);
   tolua_function(tolua_S,"PubMsg",tolua_RS232_CRS232_PubMsg00);
   tolua_function(tolua_S,"PublishLog",tolua_RS232_CRS232_PublishLog00);
   tolua_function(tolua_S,"ReadString",tolua_RS232_CRS232_ReadString00);
   tolua_function(tolua_S,"ReadBytes",tolua_RS232_CRS232_ReadBytes00);
   tolua_function(tolua_S,"ReadStringBytes",tolua_RS232_CRS232_ReadStringBytes00);
   tolua_function(tolua_S,"getSerialPorts",tolua_RS232_CRS232_getSerialPorts00);
   tolua_function(tolua_S,"ReadPowerString",tolua_RS232_CRS232_ReadPowerString00);
   tolua_function(tolua_S,"StringMatch",tolua_RS232_CRS232_StringMatch00);
   tolua_function(tolua_S,"ClearBuffer",tolua_RS232_CRS232_ClearBuffer00);
   tolua_function(tolua_S,"ClearPubMsg",tolua_RS232_CRS232_ClearPubMsg00);
   tolua_function(tolua_S,"SetDetectString",tolua_RS232_CRS232_SetDetectString00);
   tolua_function(tolua_S,"WaitDetect",tolua_RS232_CRS232_WaitDetect00);
   tolua_function(tolua_S,"WaitDetect2",tolua_RS232_CRS232_WaitDetect200);
   tolua_function(tolua_S,"WriteReadString",tolua_RS232_CRS232_WriteReadString00);
   tolua_function(tolua_S,"SetMutableArr",tolua_RS232_CRS232_SetMutableArr00);
   tolua_function(tolua_S,"ClearMutableArr",tolua_RS232_CRS232_ClearMutableArr00);
   tolua_function(tolua_S,"ArrayMatch",tolua_RS232_CRS232_ArrayMatch00);
   tolua_function(tolua_S,"ArrayFind",tolua_RS232_CRS232_ArrayFind00);
   tolua_function(tolua_S,"SetRepOpt",tolua_RS232_CRS232_SetRepOpt00);
   tolua_function(tolua_S,"SetPubOpt",tolua_RS232_CRS232_SetPubOpt00);
   tolua_function(tolua_S,"SetPrompt",tolua_RS232_CRS232_SetPrompt00);
   tolua_function(tolua_S,"WritePassControlBit",tolua_RS232_CRS232_WritePassControlBit00);
   tolua_function(tolua_S,"CheckPreviousCB",tolua_RS232_CRS232_CheckPreviousCB00);
   tolua_function(tolua_S,"CheckAllowedFailCount",tolua_RS232_CRS232_CheckAllowedFailCount00);
   tolua_function(tolua_S,"InitialProcessControl",tolua_RS232_CRS232_InitialProcessControl00);
   tolua_function(tolua_S,"FinalProcessControl",tolua_RS232_CRS232_FinalProcessControl00);
   tolua_function(tolua_S,"CalHash",tolua_RS232_CRS232_CalHash00);
   tolua_function(tolua_S,"SaveData",tolua_RS232_CRS232_SaveData00);
   tolua_function(tolua_S,"QuerySfcParams",tolua_RS232_CRS232_QuerySfcParams00);
  tolua_endmodule(tolua_S);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_RS232 (lua_State* tolua_S) {
 return tolua_RS232_open(tolua_S);
};
#endif

