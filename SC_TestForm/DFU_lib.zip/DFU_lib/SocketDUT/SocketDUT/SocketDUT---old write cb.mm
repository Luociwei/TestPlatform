//
//  SocketDevice.c
//  SocketDev
//
//  Created by Ryan on 11/4/15.
//  Copyright © 2015  Automation___. All rights reserved.
//

#include "SocketDUT.h"
#include "zmq.h"

#include <iostream>
#include <sstream>

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <regex>


#define CLI_CR_RED          "\033[31m"
#define CLI_CR_YELLOW       "\033[33m"
#define CLI_CR_CLOSE        "\033[0m"

#define OUT
#define IN

NSLock * g_LockCB = [[NSLock alloc]init];
const std::string  arrColorCode[] = {
                          "[0m",
                          "[1m",
                          "[4m",
                          "[5m",
                          "[7m",
                          "[8m",
                          "[30m",
                          "[31m",
                          "[32m",
                          "[33m",
                          "[34m",
                          "[35m",
                          "[36m",
                          "[37m",
                          "[40m",
                          "[41m",
                          "[42m",
                          "[43m",
                          "[44m",
                          "[45m",
                          "[46m",
                          "[47m",
                          "[nA ",
                          "[nB ",
                          "[nC ",
                          "[nD ",
                          "[25;01H ",
                          "[2J ",
                          "[K ",
                          "[s ",
                          "[u ",
                          "[?25l ",
                          "[?25h ",
                          " ............ .E.. ..... .......... ; ;. ..zl ",
                          " ............ .E.. ..... .......... ; ;. ..zj ",
                          " ............ .E.. ..... .......... ; ;. ..zk ",
                          "[25;",
                          "01H",
                          "02H",
                          "03H",
                          "04H",
                          "05H",
                          "06H",
                          "07H",
                          "08H",
                          "09H",
                          "10H",
                          "11H",
                          "12H",
                          "13H",
                          "14H",
                          "15H",
                          "16H",
                          "17H",
                          "18H",
                          "19H",
                          "20H",
                          "21H",
                          "22H",
                          "23H",
                          "24H",
                          "25H",
                          "26H",
                          "27H",
                          "28H",
                          "29H",
                          "30H",
                          "31H",
                          "32H",
                          "33H",
                          "34H",
                          "35H",
                          "36H",
                          "37H",
                          "38H",
                          "39H",
                          "40H",
                          "41H",
                          "42H",
                          "43H",
                          "44H",
                          "45H",
                          "46H",
                          "47H",
                          "48H",
                          "49H",
                          "50H",
                          "51H",
                          "52H",
                          "53H",
                          "54H",
                          "55H",
                          "56H",
                          "57H",
                          "58H",
                          "59H",
                          "60H",
                          "61H",
                          "62H",
                          "63H",
                          "64H",
                          "65H",
                          "66H",
                          "67H",
                          "68H",
                          "69H",
                          "70H",
                          "71H",
                          "72H",
                          "73H",
                          "74H",
                          "75H",
                          "76H",
                          "77H",
                          "78H",
                          "79H",
                          "80H",
                          "++",
                          "+",
};

void SpliteSring(IN const std::string& src, IN const std::string& split, OUT std::vector<std::string>& results)
{
    std::string tSrc = src;
    while (tSrc.length() > 0)
    {
        int pos = tSrc.find(split.c_str());
        if (pos != std::string::npos)
        {
            std::string str = tSrc.substr(0, pos);
            results.push_back(str);
            
            tSrc = tSrc.substr(pos + split.size(), tSrc.length() - pos - split.size());
        }
        else
        {
            if (!tSrc.empty())
                results.push_back(tSrc);
            break;
        }
    }
}


CSocketDUT::CSocketDUT()
{
//    m_pSocket = [[CTcpSocket alloc]initWithIPPort:@"SocketZMQ" :[NSString stringWithUTF8String:name] :port ];
    pthread_mutex_init(&m_mutex, nil);
    pthread_mutex_init(&m_mutexForSend,nil);
    m_strBuffer = [[NSMutableString alloc] init];
    m_strPubBuffer = [[NSMutableString alloc] init];
    m_MutableDetect = [[NSMutableString alloc]init];
    strReturn = [[NSMutableString alloc] init];
    m_name = [[NSString alloc]init];
    write_str = [[NSString alloc]init];
    m_port = 0;
    m_hexmode = false;
    bFilterColorCode = true;
    showFlag = @"";
    pub_frequence = 0;
    i_pubstarttime = [[NSDate date]timeIntervalSince1970];
    i_pubnow = [[NSDate date]timeIntervalSince1970];
    
    m_lockBuffer = [[NSLock alloc]init];
}

CSocketDUT::~CSocketDUT()
{
//    [m_pSocket release];
    std::cout<<"CSocketDevice close()"<<std::endl;
    
    CPubliser::close();
    CReplier::close();
    CTcpClient::close();
    pthread_mutex_destroy(&m_mutex);
    pthread_mutex_destroy(&m_mutexForSend);
    [m_strBuffer release];
    [m_strPubBuffer release];
    [m_MutableDetect release];
    [m_name release];
    [strReturn release];
    [write_str release];
    [m_lockBuffer release];
}

int CSocketDUT::CreateIPC(const char *reply, const char *publisher)
{
    //Create Socket
    CPubliser::close();
    CReplier::close();
    
    NSLog(@"closing binding");
    CPubliser::bind(publisher);
    CReplier::bind(reply);
    return 0;
}

int CSocketDUT::PublishLog(char *data)
{
    if (CPubliser::m_socket) {
        Pulish(data, strlen(data));
    }
    return 0;
}


void CSocketDUT::SetHexmode(bool mode)
{
    NSLog(@"SexHexmode:%d",mode);
    m_hexmode = mode;
}

void CSocketDUT::SetFilterColorCode(bool mode)
{
    bFilterColorCode = mode;
}

void CSocketDUT::ClearPubMsg()
{
    [m_strPubBuffer setString:@""];
    pub_frequence = 0;
}

//Sokcet callback
void * CSocketDUT::OnSocketData(void *data, long len)
{
    if (len<=0) {
        return nullptr;
    }
    pthread_mutex_lock(&m_mutex);
    [m_lockBuffer lock];
    [m_DataBuffer appendBytes:(Byte*)data length:len];
    [m_lockBuffer unlock];
    char * p = (char *)data;
    for(long i=0;i<len;i++)
    {
        if(p[i]=='\0')
            p[i] ='.';
    }
    
    NSMutableString *str = [[NSMutableString alloc] initWithBytes:data length:len encoding:NSUTF8StringEncoding];
    if (str) {

        [m_lockBuffer lock];
        [m_strBuffer appendString:str];
        [m_strPubBuffer appendString:str];
        [m_lockBuffer unlock];
        if (CPubliser::m_socket && [m_strPubBuffer containsString:@":-)"])
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
            pub_frequence = 0;
            
        }
        else if ( CPubliser::m_socket && [m_strPubBuffer containsString:@"\n"])
        {
             pub_frequence++;
             if (pub_frequence == 150)
             {
                 PulishString([m_strPubBuffer UTF8String]);
                 [m_strPubBuffer setString:@""];
                 pub_frequence = 0;
                 
            }
            
        }
        
    }
    /*
    if (str) {
        
        [m_lockBuffer lock];
        [m_strBuffer appendString:str];
        [m_lockBuffer unlock];
        [m_strPubBuffer appendString:str];
        
        i_pubnow = [[NSDate date]timeIntervalSince1970];
        if (CPubliser::m_socket && [m_strPubBuffer containsString:@":-)"])
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
            i_pubstarttime = [[NSDate date]timeIntervalSince1970];
            
        }
        else if ( CPubliser::m_socket && [m_strPubBuffer containsString:@"\n"] )
        {
            if (fabs(i_pubnow - i_pubstarttime) >5.0)
            {
                PulishString([m_strPubBuffer UTF8String]);
                [m_strPubBuffer setString:@""];
                i_pubstarttime = [[NSDate date]timeIntervalSince1970];
            }
        }
    }
    */
    [str release];
    pthread_mutex_unlock(&m_mutex);
    return nullptr;
  
    
   /*
    //NSMutableString * str = nil;
    std::string str;
    if (len<=0) {
        return nullptr;
    }
    
    if (m_hexmode)
    {
        NSLog(@"Receive hex mode len:%ld",len);
//        str = [[NSMutableString alloc]init];
        if(len>0)
        {
            char * pByte = (char *)data;
            for(int i= 0; i<len-1; i++)
            {
                NSLog(@"[%d]%x ",pByte[i],pByte[i]);
                char bytes[10] = {0};
                sprintf(bytes, "0x%02X ", pByte[i]);
                str.append(bytes);
                //[str appendFormat:@"0x%02X ",pByte[i]];
            }
            char endByte[10] = {0};
            sprintf(endByte, "0x%02X ", pByte[len-1]);
            str.append(endByte);
            //[str appendFormat:@"0x%02X",pByte[len-1]];
        }
    }
    else
    {
        if (bFilterColorCode)
        {
            
            unsigned char * p = (unsigned char *)data;
            for (int i=0; i<len; i++) {
                if (p[i] == '\0') {
                    p[i] = '+';
                }
                
                if (p[i] < 32 || p[i] >= 127) {   //skip unvisible character
                    if (p[i] != 10 && p[i] != 13) {
                        p[i] = '+';
                    }
                }
                
            }
//            NSArray * arrColorCode = [NSArray arrayWithObjects:
//                                      @"[0m",
//                                      @"[1m",
//                                      @"[4m",
//                                      @"[5m",
//                                      @"[7m",
//                                      @"[8m",
//                                      @"[30m",
//                                      @"[31m",
//                                      @"[32m",
//                                      @"[33m",
//                                      @"[34m",
//                                      @"[35m",
//                                      @"[36m",
//                                      @"[37m",
//                                      @"[40m",
//                                      @"[41m",
//                                      @"[42m",
//                                      @"[43m",
//                                      @"[44m",
//                                      @"[45m",
//                                      @"[46m",
//                                      @"[47m",
//                                      @"[nA ",
//                                      @"[nB ",
//                                      @"[nC ",
//                                      @"[nD ",
//                                      @"[25;01H ",
//                                      @"[2J ",
//                                      @"[K ",
//                                      @"[s ",
//                                      @"[u ",
//                                      @"[?25l ",
//                                      @"[?25h ",
//                                      @" ............ .E.. ..... .......... ; ;. ..zl ",
//                                      @" ............ .E.. ..... .......... ; ;. ..zj ",
//                                      @" ............ .E.. ..... .......... ; ;. ..zk ",
//                                      @"[25;",
//                                      @"01H",
//                                      @"02H",
//                                      @"03H",
//                                      @"04H",
//                                      @"05H",
//                                      @"06H",
//                                      @"07H",
//                                      @"08H",
//                                      @"09H",
//                                      @"10H",
//                                      @"11H",
//                                      @"12H",
//                                      @"13H",
//                                      @"14H",
//                                      @"15H",
//                                      @"16H",
//                                      @"17H",
//                                      @"18H",
//                                      @"19H",
//                                      @"20H",
//                                      @"21H",
//                                      @"22H",
//                                      @"23H",
//                                      @"24H",
//                                      @"25H",
//                                      @"26H",
//                                      @"27H",
//                                      @"28H",
//                                      @"29H",
//                                      @"30H",
//                                      @"31H",
//                                      @"32H",
//                                      @"33H",
//                                      @"34H",
//                                      @"35H",
//                                      @"36H",
//                                      @"37H",
//                                      @"38H",
//                                      @"39H",
//                                      @"40H",
//                                      @"41H",
//                                      @"42H",
//                                      @"43H",
//                                      @"44H",
//                                      @"45H",
//                                      @"46H",
//                                      @"47H",
//                                      @"48H",
//                                      @"49H",
//                                      @"50H",
//                                      @"51H",
//                                      @"52H",
//                                      @"53H",
//                                      @"54H",
//                                      @"55H",
//                                      @"56H",
//                                      @"57H",
//                                      @"58H",
//                                      @"59H",
//                                      @"60H",
//                                      @"61H",
//                                      @"62H",
//                                      @"63H",
//                                      @"64H",
//                                      @"65H",
//                                      @"66H",
//                                      @"67H",
//                                      @"68H",
//                                      @"69H",
//                                      @"70H",
//                                      @"71H",
//                                      @"72H",
//                                      @"73H",
//                                      @"74H",
//                                      @"75H",
//                                      @"76H",
//                                      @"77H",
//                                      @"78H",
//                                      @"79H",
//                                      @"80H",
//                                      @"++",
//                                      @"+",
//                                      nil];
            //str = [[NSMutableString alloc] initWithBytes:data length:len encoding:NSUTF8StringEncoding];
            str.assign((char *)data, len);
            for (const std::string &elem : arrColorCode)
            {
                if (str.find(elem) != std::string::npos)
                {
                    std::vector<std::string> strVec;
                    SpliteSring(str, elem, strVec);
                    str.clear();
                    for (const std::string &cont : strVec)
                    {
                        str.append(cont);
                    }
                }
            }
//            for (NSString *line in arrColorCode) {
//                NSRange range = [str rangeOfString:line];
//                if (range.location!=NSNotFound) {
//                    NSArray * Array = [str componentsSeparatedByString:line];
//                    [str setString:@""];
//                    for (NSString *cont in Array) {
//                        [str appendString:cont];
//                    }
//                }
//            }
        }
    }
    
    if (str.size() > 0) {
        NSDate * date = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm:ss.SSS : "];
        NSString * rep = [dateFormatter stringFromDate:date];
        NSString * timeLog;
        
        if (str.find("\n") != std::string::npos)
        {
            if ([showFlag containsString:[NSString stringWithUTF8String:str.c_str()]]) {
                showFlag = @"";
            }
            else{
                timeLog = [NSString stringWithFormat:@"%@ %@\n",rep,[NSString stringWithUTF8String:str.c_str()]];
                if (CPubliser::m_socket) {
                    Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
                }
            }
        }
        else if (str.find("\\>") != std::string::npos)
        {
            timeLog = [NSString stringWithFormat:@"%@ %@\n",rep,[NSString stringWithUTF8String:str.c_str()]];
            if (CPubliser::m_socket) {
                Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
            }
        }
        else
        {
            timeLog = [NSString stringWithFormat:@"%@ %@\n",rep,[NSString stringWithUTF8String:str.c_str()]];
        }
        [dateFormatter release];
        
//        Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
        pthread_mutex_lock(&m_mutex);
        [m_strBuffer appendFormat:@"%@",[NSString stringWithUTF8String:str.c_str()]];
        NSLog(@"m_strBuffer size:%f M",[m_strBuffer length]/1000000.0); //当前buff的大小
        if ([m_strBuffer length] > 10*1000000)  //如果缓存buff 超过10M，则处理
        {
            NSLog(@"buff is too high:%f M",[m_strBuffer length]/1000000.0);
            [m_strBuffer deleteCharactersInRange:NSMakeRange(0, [m_strBuffer length] - 2*1000000)]; //预留2M的buff
            NSLog(@"after clear buff:%f M",[m_strBuffer length]/1000000.0);
        }
        pthread_mutex_unlock(&m_mutex);
    }
    
//    if (str) {
//        [str release];
//    }
    return nullptr;
    */
}




//Request CallBack
void * CSocketDUT::OnRequest(void *pdata, long len)
{
    pthread_mutex_lock(&m_mutexForSend);

    NSString * rData = [[NSString alloc] initWithBytes:pdata length:len encoding:NSUTF8StringEncoding];

    //NSLog(@"CSocketDevice::OnRequest data:%@",rData);

    if ([rData isEqualToString:@"reconnect"])
    {
         CReplier::SendStrig("Failed,Write to dut failed.please check connection");    //feed back to requester.

        if (m_name && [m_name length] > 0 && m_port != 0)
        {
            usleep(1000* 200);
            CTcpClient::close();
            Open([m_name UTF8String],m_port);
        }
        [rData release];
        pthread_mutex_unlock(&m_mutexForSend);
        return nullptr;
    }

    int err;
    if (m_hexmode)
    {
        char *str1 = ConvertStrToHexChar(rData);
        err = CSocketDUT::send(str1, ConvertStrToHexCharLen(rData));
        delete str1;
    }
    else
    {
         err = CSocketDUT::send(pdata, len);  //send the request string to DUT with tcp socket.
    }

    CReplier::SendStrig((err>=0)?"OK":"Failed,Write to dut failed.please check connection");    //feed back to requester.

    if (err >= 0 )
    {
       /* NSDate * date = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm:ss.SSS : "];
        NSString * rep = [dateFormatter stringFromDate:date];
        NSData * nsData = [NSData dataWithBytes:pdata length:len];
        NSString *str = [[NSString alloc] initWithData:nsData encoding:NSUTF8StringEncoding];
        NSString * timeLog;

        if ([str containsString:@"\n"])
        {
            timeLog = [NSString stringWithFormat:@"%@ %@",rep,str];
        }
        else
        {
            timeLog = [NSString stringWithFormat:@"%@ %@\n",rep,str];
        }
        */

        NSData * nsData = [NSData dataWithBytes:pdata length:len];
        NSString *str = [[NSString alloc] initWithData:nsData encoding:NSUTF8StringEncoding];
        if(CPubliser::m_socket)
        {
            Pulish((void *)[str UTF8String], [str length]);  //Publish out scoket data to suberscriber.
        }
       // [dateFormatter release];
        [str release];
    }

    [rData release];
    pthread_mutex_unlock(&m_mutexForSend);
    return nullptr;
}

int CSocketDUT::Open(const char *name, int port)
{
    m_name = [NSString stringWithUTF8String:name];
    m_port = port;
    CTcpClient::setremoteaddress((char *)name, port);
    return CTcpClient::connect();
}

int CSocketDUT::reOpen(const char *name, int port)
{
    CTcpClient::close();
    CTcpClient::reconnect();
    m_name = [NSString stringWithUTF8String:name];
    m_port = port;
    CTcpClient::setremoteaddress((char *)name, port);
    return CTcpClient::connect();
}


int CSocketDUT::WriteString(const char *buffer,bool mutilflag)
{    
    NSString * str = [NSString stringWithFormat:@"%s",buffer];
    int ret;
    if (m_hexmode)
    {
        char * charString;
        charString = ConvertStrToHexChar(str);
        ret = CTcpClient::send((void*)charString, ConvertStrToHexCharLen(str));
        NSLog(@"Write Hex mode len:%d",ConvertStrToHexCharLen(str));
        delete charString;
    }
    else
    {
        str = [NSString stringWithFormat:@"%s",buffer];
        ret = CTcpClient::send((void*)[str UTF8String], [str length]);
    }
    return ret;
   /*
    NSDate * date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm:ss.SSS : "];
    NSString * rep = [dateFormatter stringFromDate:date];
    
    NSString * timeLog;
    if (!mutilflag) {
        if ([str containsString:@"\n"])
        {
            timeLog = [NSString stringWithFormat:@"%@ [sendcmd]:%@",rep,str];
        }
        else
        {
            timeLog = [NSString stringWithFormat:@"%@ [sendcmd]:%@\n",rep,str];
        }
        if (CPubliser::m_socket) {
            Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
        }
    }
    else
    {
        write_str = [write_str stringByAppendingString:str];
        if ([write_str containsString:@"\n"]) {
            showFlag = write_str;
            timeLog = [NSString stringWithFormat:@"%@ [sendcmd]:%@\n",rep,write_str];
           // NSLog(@"write_str: %@  %ld",write_str,write_str.length);
            if (CPubliser::m_socket) {
                Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
            }
            write_str = @"";
        }
    }
    [dateFormatter release];
    
    return 0;*/
}


void CSocketDUT::ClearBuffer()
{
    NSLog(@"Clear all Buffer()");
    [m_lockBuffer lock];
    [m_strBuffer setString:@""];
    [m_DataBuffer setLength:0];
    [strReturn setString:@""];
    [m_lockBuffer unlock];
}


const char * CSocketDUT::ReadString()
{
    pthread_mutex_lock(&m_mutex);
    if (m_strBuffer) {
        [m_lockBuffer lock];
        [strReturn setString:m_strBuffer];
        [m_strBuffer setString:@""];
        [m_DataBuffer setLength:0];
        [m_lockBuffer unlock];
    }
    else
    {
        [strReturn setString:@""];
    }
    
    pthread_mutex_unlock(&m_mutex);
    return [strReturn UTF8String];
}
const char * CSocketDUT::ReadStringHex()
{
    [NSThread sleepForTimeInterval:0.01];
    pthread_mutex_lock(&m_mutex);
    
    if (m_DataBuffer) {
        [m_lockBuffer lock];
        [strReturn setString:@""];
        Byte * tmp = (Byte*)[m_DataBuffer bytes];
        for (int i=0; i<[m_DataBuffer length]; i++) {
            [strReturn appendFormat:@"0x%02X ",tmp[i] ];
        }
        [m_strBuffer setString:@""];
        [m_DataBuffer setLength:0];
        [m_lockBuffer unlock];
        
    }
    else
    {
        [strReturn setString:@""];
    }
    
    pthread_mutex_unlock(&m_mutex);
    return [strReturn UTF8String];
}

int CSocketDUT::WaitDetect(int timeout)
{
    int r = -1;
    //    NSLog(@" * * * * * \ndylib Detect :%@ * * * * * \n",m_strStringToDetect);
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    //NSLog(@"starting to wait : %s",m_strDetect.c_str());
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            r = -2;
            break;
        }
        
        pthread_testcancel();       //if is cancel,exist current loop.
        
        //if([m_strBuffer containsString:m_MutableDetect])
        pthread_mutex_lock(&m_mutex);
        NSRange range  = [m_strBuffer rangeOfString:m_MutableDetect];
        pthread_mutex_unlock(&m_mutex);
        
        if (range.location != NSNotFound)
        {
            r = 0;
            break;
        }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
    
    //NSLog(@"waiting finished : %d",r);
    return r;  //cancel
}

int CSocketDUT::SetDetectString(const char *det)
{
    //return [m_pSocket SetDetectString:det];
    m_strDetect = det;
    [m_MutableDetect setString:[NSString stringWithUTF8String:det]];
    //CDataQueue::ClearBuffer();
    return 0;
}

int CSocketDUT::Close()
{
    //[m_pSocket disconnect];
    CTcpClient::close();
    CPubliser::close();
    CReplier::close();
    return 0;
}

int CSocketDUT::ConvertStrToHexCharLen(NSString * str)
{
    NSArray * arr = [str componentsSeparatedByString:@" "];
    int len = (int)[arr count];
    return len;
}

char * CSocketDUT::ConvertStrToHexChar(NSString * str)
{
    if ([str length] <= 0) return nil;
    NSArray * arr = [str componentsSeparatedByString:@" "];
    if([arr count]< 1) return nil;
    int size = (int)[arr count];
    unsigned char * ucData = new unsigned char [size];
    for(int i=0; i<size; i++)
    {
        NSScanner * scanner = [NSScanner scannerWithString:[arr objectAtIndex:i]];
        unsigned int tmp;
        [scanner scanHexInt:&tmp];
        ucData[i] = tmp;
    }
    ucData[size]='\0';
//    
//    NSString * str1 = [NSString stringWithUTF8String:(char *)ucData];
//    delete[] ucData;
    
    NSLog(@"convert str to hex:");
    for (int i = 0; i < size; i++)
    {
        printf("0x%x",ucData[i]);
    }
//    NSLog(@" convert str:%@ to hexstr:%@",str,str1);
    return (char *)ucData;
}

//NSLock* g_LockCB = nil;
#pragma mark Write Pass ControlBit
static int __GetHash(Byte ucpNonce[20],Byte hash[20],int stationid)
{
    int status=0;
    [g_LockCB lock];
    status = get_station_hash(stationid, ucpNonce, hash);
//    switch (stationid) {
//        case 0x00:  //DFU
//            status = get_dfu_hash(ucpNonce, hash);
//            break;
//        case 0x01:  //FCT
//            status = get_fct_hash(ucpNonce, hash);
//            break;
//        case 0x02:  //SOC
//            status = get_soc_hash(ucpNonce, hash);
//            break;
//        default:    //Other
//            status = get_station_hash(stationid, ucpNonce, hash);
//            break;
  //  }
    [g_LockCB unlock];
    return status;
}

int CSocketDUT::control_bit(int stationid, char *szCmd)
{
    WriteString((char*)"\r\n");
    [NSThread sleepForTimeInterval:0.5];
    ClearBuffer();
    SetDetectString((char*)":-)");
    WriteString((char*)"getnonce\r\n");
    PulishString("getnonce\r\n");
    //WaitDetect(5000);
    [NSThread sleepForTimeInterval:1.0];
    NSData* dataResult =m_DataBuffer ;
    int iCnt1 = 0;
    NSLog(@"[dataResult length] : %zd",[dataResult length]);
    //while ((dataResult==nil || [dataResult length] != 81) && (iCnt1 < 3))
    while ((dataResult==nil) && (iCnt1 < 3))
    {
        ClearBuffer();
        SetDetectString((char*)":-)");
        WriteString((char*)"getnonce\r\n");
        PulishString("getnonce\r\n");
        //WaitDetect(10000);
        [NSThread sleepForTimeInterval:1.0];
        dataResult = m_DataBuffer;
        iCnt1++;
    }
    
    if (dataResult == nil) return -1;//failed to get nonce
    //if (dataResult == nil) return -1;//failed to get nonce
    Byte *byte = (Byte *)[dataResult bytes] ;
    if (byte == NULL) return -101;
    for(int i=0 ;i<[dataResult length] ;i++)
    {
        NSLog(@"\n %d",*(byte+i)) ;
    }
    //Get the password
    unsigned char ucpNonce[20];
    unsigned char hash[20];
    memset(ucpNonce, 0, sizeof(ucpNonce));
    memset(hash, 0, sizeof(hash));
    memcpy(ucpNonce, byte+10, 20);
    NSLog(@"\n start getnonce 20 bytes") ;
    for(int i=0 ;i<20 ;i++)
    {
        NSLog(@"====> \n %d",ucpNonce[i]) ;
    }
    int status  = 0;
    NSLog(@"====stationid: %d",stationid);
    status = __GetHash(ucpNonce, hash,stationid);
    NSLog(@"status: %d",status);
    if(status != 0) return -2;//failed to get hash
    ClearBuffer();
    SetDetectString(const_cast<char *>(">"));
    WriteString(szCmd);
    WaitDetect(5000);
    usleep(100000);
    if (ReadString() == NULL) return -3;//failed to send cbwrite
    usleep(100000);
    
    SetDetectString((char*)":-)");
    CTcpClient::send(hash, sizeof(hash));
    this->WaitDetect(5000);
    usleep(500*1000);
    const char* szRtn = ReadString();
    if (strstr(szRtn, "Passed") != NULL) return 0;
    return -5;
}



int CSocketDUT::WritePassControlBit(int stationid, char *szCmd)
{
    int ret = -99;
    for (int i=0; i<3; i++) {
        ret= control_bit(stationid,szCmd);
        if (ret == 0) {
            return ret;
        }
    }
    
    return ret;
}




