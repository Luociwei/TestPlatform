/*
** Lua binding: SocketDUT
** Generated automatically by tolua++-1.0.92 on Sat Apr 10 10:55:20 2021.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_SocketDUT_open (lua_State* tolua_S);

#include "SocketDUT.h"

/* function to release collected object via destructor */
#ifdef __cplusplus

static int tolua_collect_CSocketDUT (lua_State* tolua_S)
{
 CSocketDUT* self = (CSocketDUT*) tolua_tousertype(tolua_S,1,0);
	Mtolua_delete(self);
	return 0;
}
#endif


/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"CSocketDUT");
 tolua_usertype(tolua_S,"NSString");
}

/* method: new of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_new00
static int tolua_SocketDUT_CSocketDUT_new00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CSocketDUT* tolua_ret = (CSocketDUT*)  Mtolua_new((CSocketDUT)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CSocketDUT");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: new_local of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_new00_local
static int tolua_SocketDUT_CSocketDUT_new00_local(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CSocketDUT* tolua_ret = (CSocketDUT*)  Mtolua_new((CSocketDUT)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CSocketDUT");
    tolua_register_gc(tolua_S,lua_gettop(tolua_S));
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: delete of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_delete00
static int tolua_SocketDUT_CSocketDUT_delete00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'delete'", NULL);
#endif
  Mtolua_delete(self);
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'delete'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: CreateIPC of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_CreateIPC00
static int tolua_SocketDUT_CSocketDUT_CreateIPC00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* reply = ((const char*)  tolua_tostring(tolua_S,2,0));
  const char* publiser = ((const char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'CreateIPC'", NULL);
#endif
  {
   int tolua_ret = (int)  self->CreateIPC(reply,publiser);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'CreateIPC'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: PublishLog of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_PublishLog00
static int tolua_SocketDUT_CSocketDUT_PublishLog00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  char* data = ((char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'PublishLog'", NULL);
#endif
  {
   int tolua_ret = (int)  self->PublishLog(data);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'PublishLog'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: Open of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_Open00
static int tolua_SocketDUT_CSocketDUT_Open00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* name = ((const char*)  tolua_tostring(tolua_S,2,0));
  int port = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'Open'", NULL);
#endif
  {
   int tolua_ret = (int)  self->Open(name,port);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'Open'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: reOpen of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_reOpen00
static int tolua_SocketDUT_CSocketDUT_reOpen00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* name = ((const char*)  tolua_tostring(tolua_S,2,0));
  int port = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'reOpen'", NULL);
#endif
  {
   int tolua_ret = (int)  self->reOpen(name,port);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'reOpen'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: Close of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_Close00
static int tolua_SocketDUT_CSocketDUT_Close00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'Close'", NULL);
#endif
  {
   int tolua_ret = (int)  self->Close();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'Close'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteString of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_WriteString00
static int tolua_SocketDUT_CSocketDUT_WriteString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isboolean(tolua_S,3,1,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* buffer = ((const char*)  tolua_tostring(tolua_S,2,0));
  bool mutilflag = ((bool)  tolua_toboolean(tolua_S,3,false));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteString'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteString(buffer,mutilflag);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteString2 of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_WriteString200
static int tolua_SocketDUT_CSocketDUT_WriteString200(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,1,&tolua_err) ||
     !tolua_isboolean(tolua_S,4,1,&tolua_err) ||
     !tolua_isnoobj(tolua_S,5,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* buffer = ((const char*)  tolua_tostring(tolua_S,2,0));
  int us_time = ((int)  tolua_tonumber(tolua_S,3,10000));
  bool mutilflag = ((bool)  tolua_toboolean(tolua_S,4,false));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteString2'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteString2(buffer,us_time,mutilflag);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteString2'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadString of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ReadString00
static int tolua_SocketDUT_CSocketDUT_ReadString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadString'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadString();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadStringHex of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ReadStringHex00
static int tolua_SocketDUT_CSocketDUT_ReadStringHex00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadStringHex'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ReadStringHex();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadStringHex'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearBuffer of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ClearBuffer00
static int tolua_SocketDUT_CSocketDUT_ClearBuffer00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearBuffer'", NULL);
#endif
  {
   self->ClearBuffer();
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearBuffer'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearPubMsg of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ClearPubMsg00
static int tolua_SocketDUT_CSocketDUT_ClearPubMsg00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearPubMsg'", NULL);
#endif
  {
   self->ClearPubMsg();
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearPubMsg'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: StringMatch of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_StringMatch00
static int tolua_SocketDUT_CSocketDUT_StringMatch00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* matchVal = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'StringMatch'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->StringMatch(matchVal);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'StringMatch'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetDetectString of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_SetDetectString00
static int tolua_SocketDUT_CSocketDUT_SetDetectString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* det = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetDetectString'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetDetectString(det);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetDetectString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WaitDetect of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_WaitDetect00
static int tolua_SocketDUT_CSocketDUT_WaitDetect00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  int timeout = ((int)  tolua_tonumber(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WaitDetect'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WaitDetect(timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WaitDetect'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WaitDetect2 of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_WaitDetect200
static int tolua_SocketDUT_CSocketDUT_WaitDetect200(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  int timeout = ((int)  tolua_tonumber(tolua_S,2,0));
  int null_timeout = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WaitDetect2'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WaitDetect2(timeout,null_timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WaitDetect2'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetMutableArr of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_SetMutableArr00
static int tolua_SocketDUT_CSocketDUT_SetMutableArr00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetMutableArr'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetMutableArr();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetMutableArr'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearMutableArr of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ClearMutableArr00
static int tolua_SocketDUT_CSocketDUT_ClearMutableArr00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearMutableArr'", NULL);
#endif
  {
   int tolua_ret = (int)  self->ClearMutableArr();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearMutableArr'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ArrayMatch of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ArrayMatch00
static int tolua_SocketDUT_CSocketDUT_ArrayMatch00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* matchVal = ((const char*)  tolua_tostring(tolua_S,2,0));
  int index = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ArrayMatch'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ArrayMatch(matchVal,index);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ArrayMatch'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ArrayFind of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ArrayFind00
static int tolua_SocketDUT_CSocketDUT_ArrayFind00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  const char* val = ((const char*)  tolua_tostring(tolua_S,2,0));
  int index = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ArrayFind'", NULL);
#endif
  {
   const char* tolua_ret = (const char*)  self->ArrayFind(val,index);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ArrayFind'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ConvertStrToHexChar of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ConvertStrToHexChar00
static int tolua_SocketDUT_CSocketDUT_ConvertStrToHexChar00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"NSString",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  NSString* str = ((NSString*)  tolua_tousertype(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ConvertStrToHexChar'", NULL);
#endif
  {
   char* tolua_ret = (char*)  self->ConvertStrToHexChar(str);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ConvertStrToHexChar'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ConvertStrToHexCharLen of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_ConvertStrToHexCharLen00
static int tolua_SocketDUT_CSocketDUT_ConvertStrToHexCharLen00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"NSString",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  NSString* str = ((NSString*)  tolua_tousertype(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ConvertStrToHexCharLen'", NULL);
#endif
  {
   int tolua_ret = (int)  self->ConvertStrToHexCharLen(str);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ConvertStrToHexCharLen'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WritePassControlBit of class  CSocketDUT */
#ifndef TOLUA_DISABLE_tolua_SocketDUT_CSocketDUT_WritePassControlBit00
static int tolua_SocketDUT_CSocketDUT_WritePassControlBit00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CSocketDUT",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CSocketDUT* self = (CSocketDUT*)  tolua_tousertype(tolua_S,1,0);
  int stationid = ((int)  tolua_tonumber(tolua_S,2,0));
  char* szCmd = ((char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WritePassControlBit'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WritePassControlBit(stationid,szCmd);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WritePassControlBit'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_SocketDUT_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  #ifdef __cplusplus
  tolua_cclass(tolua_S,"CSocketDUT","CSocketDUT","",tolua_collect_CSocketDUT);
  #else
  tolua_cclass(tolua_S,"CSocketDUT","CSocketDUT","",NULL);
  #endif
  tolua_beginmodule(tolua_S,"CSocketDUT");
   tolua_function(tolua_S,"new",tolua_SocketDUT_CSocketDUT_new00);
   tolua_function(tolua_S,"new_local",tolua_SocketDUT_CSocketDUT_new00_local);
   tolua_function(tolua_S,".call",tolua_SocketDUT_CSocketDUT_new00_local);
   tolua_function(tolua_S,"delete",tolua_SocketDUT_CSocketDUT_delete00);
   tolua_function(tolua_S,"CreateIPC",tolua_SocketDUT_CSocketDUT_CreateIPC00);
   tolua_function(tolua_S,"PublishLog",tolua_SocketDUT_CSocketDUT_PublishLog00);
   tolua_function(tolua_S,"Open",tolua_SocketDUT_CSocketDUT_Open00);
   tolua_function(tolua_S,"reOpen",tolua_SocketDUT_CSocketDUT_reOpen00);
   tolua_function(tolua_S,"Close",tolua_SocketDUT_CSocketDUT_Close00);
   tolua_function(tolua_S,"WriteString",tolua_SocketDUT_CSocketDUT_WriteString00);
   tolua_function(tolua_S,"WriteString2",tolua_SocketDUT_CSocketDUT_WriteString200);
   tolua_function(tolua_S,"ReadString",tolua_SocketDUT_CSocketDUT_ReadString00);
   tolua_function(tolua_S,"ReadStringHex",tolua_SocketDUT_CSocketDUT_ReadStringHex00);
   tolua_function(tolua_S,"ClearBuffer",tolua_SocketDUT_CSocketDUT_ClearBuffer00);
   tolua_function(tolua_S,"ClearPubMsg",tolua_SocketDUT_CSocketDUT_ClearPubMsg00);
   tolua_function(tolua_S,"StringMatch",tolua_SocketDUT_CSocketDUT_StringMatch00);
   tolua_function(tolua_S,"SetDetectString",tolua_SocketDUT_CSocketDUT_SetDetectString00);
   tolua_function(tolua_S,"WaitDetect",tolua_SocketDUT_CSocketDUT_WaitDetect00);
   tolua_function(tolua_S,"WaitDetect2",tolua_SocketDUT_CSocketDUT_WaitDetect200);
   tolua_function(tolua_S,"SetMutableArr",tolua_SocketDUT_CSocketDUT_SetMutableArr00);
   tolua_function(tolua_S,"ClearMutableArr",tolua_SocketDUT_CSocketDUT_ClearMutableArr00);
   tolua_function(tolua_S,"ArrayMatch",tolua_SocketDUT_CSocketDUT_ArrayMatch00);
   tolua_function(tolua_S,"ArrayFind",tolua_SocketDUT_CSocketDUT_ArrayFind00);
   tolua_function(tolua_S,"ConvertStrToHexChar",tolua_SocketDUT_CSocketDUT_ConvertStrToHexChar00);
   tolua_function(tolua_S,"ConvertStrToHexCharLen",tolua_SocketDUT_CSocketDUT_ConvertStrToHexCharLen00);
   tolua_function(tolua_S,"WritePassControlBit",tolua_SocketDUT_CSocketDUT_WritePassControlBit00);
  tolua_endmodule(tolua_S);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_SocketDUT (lua_State* tolua_S) {
 return tolua_SocketDUT_open(tolua_S);
};
#endif

