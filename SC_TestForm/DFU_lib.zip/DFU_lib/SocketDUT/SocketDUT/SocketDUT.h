//
//  SocketDevice.h
//  SocketDev
//
//  Copyright © 2015  Automation___. All rights reserved.
//

#ifndef SocketDevice_h
#define SocketDevice_h

#include <stdio.h>
#include <Foundation/Foundation.h>

//#include "tcpSocket.h"
#include "MessageInterface.h"

#include <string>

#include "Publisher.hpp"
#include "Replier.hpp"

#include "TcpClient.h"

#include "DataQueue.hpp"
#include "get_hash.h"


class CSocketDUT:CPubliser,CReplier,CTcpClient,CDataQueue {
public:
    CSocketDUT();
    ~CSocketDUT();
    
public:
    int CreateIPC(const char *reply,const char *publiser);   //publiser & reply
    int PublishLog(char *data);
    int Open(const char *name, int port);
    int reOpen(const char *name, int port);
    int Close();
    
    int WriteString(const char * buffer,bool mutilflag = false);
    int WriteString2(const char * buffer,int us_time = 10000,bool mutilflag = false); //one by one send command
    const char * ReadString();
    const char * ReadStringHex();
    const char * StringMatch(const char * matchVal);
    void ClearBuffer();
    void ClearPubMsg();
    
    int SetDetectString(const char * det);
    int WaitDetect(int timeout);
    int WaitDetect2(int timeout,int null_timeout); //add 2021-3-03
    
    int SetMutableArr();
    int ClearMutableArr();
    const char * ArrayMatch(const char * matchVal,int index);  // index from  0,1,2,3
    const char * ArrayFind(const char * val,int index);  // index from  0,1,2,3
    
    
    char * ConvertStrToHexChar(NSString * str);
    int ConvertStrToHexCharLen(NSString * str);

    int WritePassControlBit(int stationid,char* szCmd);
    
    void SetFilterColorCode(bool mode);
    void SetHexmode(bool mode);
    bool m_hexmode;
    bool bFilterColorCode;
    //NSString *write_str;
    NSString *showFlag;

    
protected:
    virtual void * OnRequest(void *pdata,long len);
    virtual void * OnSocketData(void * data,long len);
    int control_bit(int stationid, char *szCmd);
    void __ReadString();
    
    NSLock* m_lockBuffer;
    pthread_mutex_t m_mutex;
    pthread_mutex_t m_mutexForSend;
  
    std::string m_strDetect;
    std::string m_InputBuffer;
    std::string m_OutputString; //temp string to return to lua
    
    NSMutableString * m_strBuffer;
    NSMutableString * m_strPubBuffer;
    NSMutableString * m_MutableDetect;
    
    NSMutableString * strReturn;
    NSString *m_name;
    int m_port;
    int pub_frequence;
    int is_iboot;
    NSTimeInterval i_pubstarttime;
    NSTimeInterval i_pubnow;
    
    NSMutableArray * m_arrBuffer;
};

#endif /* SocketDUT_h */
