//
//  SocketDevice.c
//  SocketDev
//
//  Created by Ryan on 11/4/15.
//  Copyright © 2015  Automation___. All rights reserved.
//

#include "SocketDUT.h"
#include "zmq.h"

#include <iostream>
#include <sstream>

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <regex>
#include "RegexKitLite.h"

#define CLI_CR_RED          "\033[31m"
#define CLI_CR_YELLOW       "\033[33m"
#define CLI_CR_CLOSE        "\033[0m"

#define OUT
#define IN

NSLock * g_LockCB = [[NSLock alloc]init];
const std::string  arrColorCode[] = {
                          "[0m",
                          "[1m",
                          "[4m",
                          "[5m",
                          "[7m",
                          "[8m",
                          "[30m",
                          "[31m",
                          "[32m",
                          "[33m",
                          "[34m",
                          "[35m",
                          "[36m",
                          "[37m",
                          "[40m",
                          "[41m",
                          "[42m",
                          "[43m",
                          "[44m",
                          "[45m",
                          "[46m",
                          "[47m",
                          "[nA ",
                          "[nB ",
                          "[nC ",
                          "[nD ",
                          "[25;01H ",
                          "[2J ",
                          "[K ",
                          "[s ",
                          "[u ",
                          "[?25l ",
                          "[?25h ",
                          " ............ .E.. ..... .......... ; ;. ..zl ",
                          " ............ .E.. ..... .......... ; ;. ..zj ",
                          " ............ .E.. ..... .......... ; ;. ..zk ",
                          "[25;",
                          "01H",
                          "02H",
                          "03H",
                          "04H",
                          "05H",
                          "06H",
                          "07H",
                          "08H",
                          "09H",
                          "10H",
                          "11H",
                          "12H",
                          "13H",
                          "14H",
                          "15H",
                          "16H",
                          "17H",
                          "18H",
                          "19H",
                          "20H",
                          "21H",
                          "22H",
                          "23H",
                          "24H",
                          "25H",
                          "26H",
                          "27H",
                          "28H",
                          "29H",
                          "30H",
                          "31H",
                          "32H",
                          "33H",
                          "34H",
                          "35H",
                          "36H",
                          "37H",
                          "38H",
                          "39H",
                          "40H",
                          "41H",
                          "42H",
                          "43H",
                          "44H",
                          "45H",
                          "46H",
                          "47H",
                          "48H",
                          "49H",
                          "50H",
                          "51H",
                          "52H",
                          "53H",
                          "54H",
                          "55H",
                          "56H",
                          "57H",
                          "58H",
                          "59H",
                          "60H",
                          "61H",
                          "62H",
                          "63H",
                          "64H",
                          "65H",
                          "66H",
                          "67H",
                          "68H",
                          "69H",
                          "70H",
                          "71H",
                          "72H",
                          "73H",
                          "74H",
                          "75H",
                          "76H",
                          "77H",
                          "78H",
                          "79H",
                          "80H",
                          "++",
                          "+",
};

void SpliteSring(IN const std::string& src, IN const std::string& split, OUT std::vector<std::string>& results)
{
    std::string tSrc = src;
    while (tSrc.length() > 0)
    {
        int pos = tSrc.find(split.c_str());
        if (pos != std::string::npos)
        {
            std::string str = tSrc.substr(0, pos);
            results.push_back(str);
            
            tSrc = tSrc.substr(pos + split.size(), tSrc.length() - pos - split.size());
        }
        else
        {
            if (!tSrc.empty())
                results.push_back(tSrc);
            break;
        }
    }
}


CSocketDUT::CSocketDUT()
{
//    m_pSocket = [[CTcpSocket alloc]initWithIPPort:@"SocketZMQ" :[NSString stringWithUTF8String:name] :port ];
    pthread_mutex_init(&m_mutex, nil);
    pthread_mutex_init(&m_mutexForSend,nil);
    m_strBuffer = [[NSMutableString alloc] init];
    m_strPubBuffer = [[NSMutableString alloc] init];
    m_MutableDetect = [[NSMutableString alloc]init];
    strReturn = [[NSMutableString alloc] init];
    m_name = [[NSString alloc]init];
    //write_str = [[NSString alloc]init];
    m_port = 0;
    m_hexmode = false;
    bFilterColorCode = false;
    showFlag = @"";
    is_iboot = 0;
    i_pubstarttime = [[NSDate date]timeIntervalSince1970];
    i_pubnow = [[NSDate date]timeIntervalSince1970];
    
    m_lockBuffer = [[NSLock alloc]init];
    
    m_arrBuffer = [[NSMutableArray alloc]init];
}

CSocketDUT::~CSocketDUT()
{
//    [m_pSocket release];
    std::cout<<"CSocketDevice close()"<<std::endl;
    
    CPubliser::close();
    CReplier::close();
    CTcpClient::close();
    pthread_mutex_destroy(&m_mutex);
    pthread_mutex_destroy(&m_mutexForSend);
    [m_strBuffer release];
    [m_MutableDetect release];
    [m_name release];
    [strReturn release];
    [m_strPubBuffer release];
    //[write_str release];
    [m_lockBuffer release];
    [m_arrBuffer release];
}

int CSocketDUT::CreateIPC(const char *reply, const char *publisher)
{
    //Create Socket
    CPubliser::close();
    CReplier::close();
    
    NSLog(@"closing binding");
    CPubliser::bind(publisher);
    CReplier::bind(reply);
    return 0;
}

int CSocketDUT::PublishLog(char *data)
{
    if (CPubliser::m_socket) {
        Pulish(data, strlen(data));
    }
    return 0;
}


void CSocketDUT::SetHexmode(bool mode)
{
    NSLog(@"SexHexmode:%d",mode);
    m_hexmode = mode;
}

void CSocketDUT::SetFilterColorCode(bool mode)
{
    bFilterColorCode = mode;
}

void CSocketDUT::ClearPubMsg()
{
    [m_strPubBuffer setString:@""];
}

//Sokcet callback
void * CSocketDUT::OnSocketData(void *data, long len)
{
    if (len<=0) {
        return nullptr;
    }
    char * p = (char *)data;
    for(long i=0;i<len;i++)
    {
       if(p[i]=='\0')
           p[i] ='.';
    }
    NSMutableString *str = [[NSMutableString alloc] initWithBytes:data length:len encoding:NSUTF8StringEncoding];
    if (!str)
    {
        str = [NSMutableString stringWithFormat:@"%s",data];
    }
    if (str)
    {
        /*NSString * timeLog;
        if ([str containsString:@"\n"])
        {
            timeLog = [NSString stringWithFormat:@"%@/n",str];
            if (CPubliser::m_socket)
            {
                Pulish((void *)[timeLog UTF8String], [timeLog length]);
            }
        }
         else if ([str containsString:@"\\>"] || [str containsString:@":-)"])
         {
             timeLog = [NSString stringWithFormat:@"%@\n",str];
             if (CPubliser::m_socket) {
                 Pulish((void *)[timeLog UTF8String], [timeLog length]);  //Publish out scoket data to suberscriber.
             }
         }
         else
         {
            timeLog = [NSString stringWithFormat:@"%@\n",str];
         }
        */
        
        [m_strPubBuffer appendFormat:@"%@",str];
        if (CPubliser::m_socket && ([m_strPubBuffer containsString:@":-)"] || [m_strPubBuffer containsString:@"\\>"]))
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
            
        }
        else if ( CPubliser::m_socket && [m_strPubBuffer containsString:@"\n"])
        {
            PulishString([m_strPubBuffer UTF8String]);
            [m_strPubBuffer setString:@""];
        }

        pthread_mutex_lock(&m_mutex);
        [m_strBuffer appendFormat:@"%@",str];
        if ([m_strBuffer length] > 10*1000000)  //如果缓存buff 超过10M，则处理
        {
            [m_strBuffer deleteCharactersInRange:NSMakeRange(0, 9*1000000)]; //删除9M
        }
        pthread_mutex_unlock(&m_mutex);
        
    }
    if (str)
    {
         [str release];
    }
    return nullptr;
  
}




//Request CallBack
void * CSocketDUT::OnRequest(void *pdata, long len)
{
    pthread_mutex_lock(&m_mutexForSend);

    NSString * rData = [[NSString alloc] initWithBytes:pdata length:len encoding:NSUTF8StringEncoding];

    //NSLog(@"CSocketDevice::OnRequest data:%@",rData);

    if ([rData isEqualToString:@"reconnect"])
    {
         CReplier::SendStrig("Failed,Write to dut failed.please check connection");    //feed back to requester.

        if (m_name && [m_name length] > 0 && m_port != 0)
        {
            usleep(1000* 200);
            CTcpClient::close();
            Open([m_name UTF8String],m_port);
        }
        [rData release];
        pthread_mutex_unlock(&m_mutexForSend);
        return nullptr;
    }

    int err;
    if (m_hexmode)
    {
        char *str1 = ConvertStrToHexChar(rData);
        err = CSocketDUT::send(str1, ConvertStrToHexCharLen(rData));
        delete str1;
    }
    else
    {
         err = CSocketDUT::send(pdata, len);  //send the request string to DUT with tcp socket.
    }

    CReplier::SendStrig((err>=0)?"OK":"Failed,Write to dut failed.please check connection");    //feed back to requester.

    if (err >= 0 )
    {
        NSData * nsData = [NSData dataWithBytes:pdata length:len];
        NSString *str = [[NSString alloc] initWithData:nsData encoding:NSUTF8StringEncoding];
        if(CPubliser::m_socket)
        {
            Pulish((void *)[str UTF8String], [str length]);  //Publish out scoket data to suberscriber.
        }
        [str release];
    }

    [rData release];
    pthread_mutex_unlock(&m_mutexForSend);
    return nullptr;
}

int CSocketDUT::Open(const char *name, int port)
{
    m_name = [NSString stringWithUTF8String:name];
    m_port = port;
    CTcpClient::setremoteaddress((char *)name, port);
    return CTcpClient::connect();
}

int CSocketDUT::reOpen(const char *name, int port)
{
    CTcpClient::close();
    CTcpClient::reconnect();
    m_name = [NSString stringWithUTF8String:name];
    m_port = port;
    CTcpClient::setremoteaddress((char *)name, port);
    return CTcpClient::connect();
}


int CSocketDUT::WriteString(const char *buffer,bool mutilflag)
{
    PulishString([[NSString stringWithFormat:@"\ncmd-send: %s",buffer] UTF8String]);
    NSString *str = [NSString stringWithFormat:@"%s",buffer];
    int ret = CTcpClient::send((void*)[str UTF8String], [str length]);
    return ret;
    
}


int CSocketDUT::WriteString2(const char *buffer,int us_time, bool mutilflag)
{
    NSString * str = [NSString stringWithFormat:@"%s",buffer];
    PulishString([[NSString stringWithFormat:@"\ncmd-send: %s",buffer] UTF8String]);
    int ret;
    if (m_hexmode)
    {
        char * charString;
        charString = ConvertStrToHexChar(str);
        ret = CTcpClient::send2((void*)charString, ConvertStrToHexCharLen(str),us_time);
        NSLog(@"Write Hex mode len:%d",ConvertStrToHexCharLen(str));
        delete charString;
    }
    else
    {
        str = [NSString stringWithFormat:@"%s",buffer];
        ret = CTcpClient::send2((void*)[str UTF8String], [str length],us_time);
    }
    return ret;
}
void CSocketDUT::ClearBuffer()
{
    //NSLog(@"Clear all Buffer()");
    [m_strBuffer setString:@""];
    //[strReturn setString:@""];
}


const char * CSocketDUT::ReadString()
{
    pthread_mutex_lock(&m_mutex);
    if (m_strBuffer) {
        [strReturn setString:m_strBuffer];
        [m_strBuffer setString:@""];

    }
    else
    {
        [strReturn setString:@""];
    }
    
    pthread_mutex_unlock(&m_mutex);
    return [strReturn UTF8String];
}
const char * CSocketDUT::ReadStringHex()
{
    [NSThread sleepForTimeInterval:0.01];
    pthread_mutex_lock(&m_mutex);
    
    if (m_DataBuffer) {
        [strReturn setString:@""];
        Byte * tmp = (Byte*)[m_DataBuffer bytes];
        for (int i=0; i<[m_DataBuffer length]; i++) {
            [strReturn appendFormat:@"0x%02X ",tmp[i] ];
        }
        [m_strBuffer setString:@""];
        [m_DataBuffer setLength:0];
        
    }
    else
    {
        [strReturn setString:@""];
    }
    
    pthread_mutex_unlock(&m_mutex);
    return [strReturn UTF8String];
}

int CSocketDUT::WaitDetect(int timeout)
{
    int r = -1;
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            r = -2;
            break;
        }
        
        pthread_testcancel();       //if is cancel,exist current loop.
        
        //if([m_strBuffer containsString:m_MutableDetect])
        pthread_mutex_lock(&m_mutex);
        NSRange range  = [m_strBuffer rangeOfString:m_MutableDetect];
        pthread_mutex_unlock(&m_mutex);
        
        if (range.location != NSNotFound)
        {
            r = 0;
            break;
        }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
    
    return r;  //cancel
}

int CSocketDUT::WaitDetect2(int timeout,int null_timeout)
{
    int r = -1;
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    NSTimeInterval starttime_empty = [[NSDate date]timeIntervalSince1970];
    double tm_empty = (double)null_timeout/1000.0;
    NSUInteger str_length = 0;
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            r = -2;
            break;
        }
        
        pthread_testcancel();       //if is cancel,exist current loop.
        
        pthread_mutex_lock(&m_mutex);
        NSRange range  = [m_strBuffer rangeOfString:m_MutableDetect];
        pthread_mutex_unlock(&m_mutex);
        
        if (range.location != NSNotFound)
        {
            r = 0;
            break;
        }
        
        if ((now-starttime_empty)>=tm_empty)
        {
            starttime_empty = [[NSDate date]timeIntervalSince1970];
            if (m_strBuffer.length > str_length)
            {
                str_length = m_strBuffer.length;
            }
            else
            {
                r = -5;
                NSLog(@"time out for waiting...");
                break;
            }
        }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
    
    return r;  //cancel
    
}

int CSocketDUT::SetDetectString(const char *det)
{
    m_strDetect = det;
    //[m_MutableDetect setString:[NSString stringWithUTF8String:det]];
    [m_MutableDetect setString:[NSString stringWithFormat:@"%s",det]];
    return 0;
}

int CSocketDUT::Close()
{
    //[m_pSocket disconnect];
    CTcpClient::close();
    CPubliser::close();
    CReplier::close();
    return 0;
}

int CSocketDUT::ConvertStrToHexCharLen(NSString * str)
{
    NSArray * arr = [str componentsSeparatedByString:@" "];
    int len = (int)[arr count];
    return len;
}

char * CSocketDUT::ConvertStrToHexChar(NSString * str)
{
    if ([str length] <= 0) return nil;
    NSArray * arr = [str componentsSeparatedByString:@" "];
    if([arr count]< 1) return nil;
    int size = (int)[arr count];
    unsigned char * ucData = new unsigned char [size];
    for(int i=0; i<size; i++)
    {
        NSScanner * scanner = [NSScanner scannerWithString:[arr objectAtIndex:i]];
        unsigned int tmp;
        [scanner scanHexInt:&tmp];
        ucData[i] = tmp;
    }
    ucData[size]='\0';
//    
//    NSString * str1 = [NSString stringWithUTF8String:(char *)ucData];
//    delete[] ucData;
    
    NSLog(@"convert str to hex:");
    for (int i = 0; i < size; i++)
    {
        printf("0x%x",ucData[i]);
    }
//    NSLog(@" convert str:%@ to hexstr:%@",str,str1);
    return (char *)ucData;
}

//NSLock* g_LockCB = nil;
#pragma mark Write Pass ControlBit
//static int __GetHash(Byte ucpNonce[20],Byte hash[20],int stationid)
//{
//    int status=0;
//    [g_LockCB lock];
//    status = get_station_hash(stationid, ucpNonce, hash);
////    switch (stationid) {
////        case 0x00:  //DFU
////            status = get_dfu_hash(ucpNonce, hash);
////            break;
////        case 0x01:  //FCT
////            status = get_fct_hash(ucpNonce, hash);
////            break;
////        case 0x02:  //SOC
////            status = get_soc_hash(ucpNonce, hash);
////            break;
////        default:    //Other
////            status = get_station_hash(stationid, ucpNonce, hash);
////            break;
//  //  }
//    [g_LockCB unlock];
//    return status;
//}

static int _get_station_hash(unsigned short station_id, unsigned char* nounce, unsigned char* hash)
{
    int status=0;
    [g_LockCB lock];
    status = get_station_hash(station_id, nounce, hash);
    [g_LockCB unlock];
    return status;
}

int CSocketDUT::control_bit(int stationid, char *szCmd)
{
    unsigned char aucKey[20] ;
    memset(aucKey, 0, sizeof(aucKey));
    @try
    {
        WriteString((char*)"\r\n");
        [NSThread sleepForTimeInterval:0.5];
        ClearBuffer();
        SetDetectString((char*)":-)");
        [m_strBuffer setString:@""];
        WriteString((char*)"getnonce --hex\n");
        //PulishString("getnonce --hex\n");
        [NSThread sleepForTimeInterval:0.5];
        NSRange rang = [m_strBuffer rangeOfString:@"Nonce: "];
        NSString *nonce = @"";
        if (rang.length>0)
        {
            nonce = [m_strBuffer substringFromIndex:rang.location+rang.length];
            nonce = [nonce substringWithRange:NSMakeRange(0, 40)];
            NSLog(@"first get nonce:  %@",nonce);
            int idx = 0;
            for (int j=0; j<[nonce length]; j+=2)
            {
                  NSString *hexStr = [nonce substringWithRange:NSMakeRange(j, 2)];
                  NSScanner *scanner = [NSScanner scannerWithString:hexStr];
                  unsigned long long longValue ;
                  [scanner scanHexLongLong:&longValue];
                  unsigned char c = longValue;
                  aucKey[idx] = c;
                  idx++;
            }

        }
    }
    @catch (NSException *exception)
    {
        NSLog(@"Exception:%@\n",exception.reason);
        
    }
    @finally
    {
        
    }
    [m_strBuffer setString:@""];
    unsigned char hashword[20] ;
    memset(hashword, 0, sizeof(hashword));
    int stationhash = -1000;
    stationhash = _get_station_hash(stationid, aucKey, hashword);
    WriteString(szCmd);
    [NSThread sleepForTimeInterval:0.5];
    if (ReadString() == NULL) return -3;//failed to send cbwrite
    usleep(100000);
    SetDetectString((char*)":-)");
#if 0
    CTcpClient::send(hashword, sizeof(hashword));
#else
    NSString *password = @"";
     for (int m = 0; m < 20; m++) {
         unsigned long c = hashword[m];
         password = [password stringByAppendingFormat:@"%02lx",c];
     }
    WriteString([password UTF8String]);
#endif
    
    this->WaitDetect(5000);
    usleep(500*1000);
    const char* szRtn = ReadString();
    //PulishString(szRtn);
    if (strstr(szRtn, "Passed") != NULL) return 0;
    return -5;
}



int CSocketDUT::WritePassControlBit(int stationid, char *szCmd)
{
    int ret = -99;
    for (int i=0; i<3; i++) {
        ret= control_bit(stationid,szCmd);
        if (ret == 0) {
            return ret;
        }
    }
    
    return ret;
}

const char *CSocketDUT::StringMatch(const char * matchVal)
{
    if ([m_strBuffer length]>0)
    {
        NSString *matchStr = [NSString stringWithUTF8String:matchVal];
        NSString * result = [m_strBuffer stringByMatching:matchStr capture:1];
        if ([result length]>0)
        {
            return [result UTF8String];
        }
        else
        {
            return "";
        }
    }
    return "";
}

int CSocketDUT::SetMutableArr()
{
    NSString *ret = [NSString stringWithUTF8String:ReadString()];
    [m_arrBuffer addObject:ret];
    return 0;
}
int CSocketDUT::ClearMutableArr()
{
    [m_arrBuffer removeAllObjects];
    return 0;
}
const char * CSocketDUT::ArrayMatch(const char * matchVal,int index)
{
    if (index<0)
    {
        return "--FAIL--index less than 0";
    }
    if ([m_arrBuffer count]<=index)
    {
        return "--FAIL--index out of range";
    }
    NSString *matchStr = [NSString stringWithUTF8String:matchVal];
    NSString * result = [m_arrBuffer[index] stringByMatching:matchStr capture:1];
    if ([result length]>0)
    {
        return [result UTF8String];
    }
    else
    {
        return "";
    }
}

const char * CSocketDUT::ArrayFind(const char * val,int index)
{
    if (index<0)
    {
        return "--FAIL--index less than 0";
    }
    if ([m_arrBuffer count]<=index)
    {
        return "--FAIL--index out of range";
    }
    NSString *valStr = [NSString stringWithUTF8String:val];
    BOOL ret = [m_arrBuffer[index] containsString:valStr];
    if (ret)
    {
        return "YES";
    }
    else
    {
        return "NO";
    }
}

