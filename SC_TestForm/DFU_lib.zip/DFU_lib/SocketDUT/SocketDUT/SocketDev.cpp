/*
 *  SocketDev.cpp
 *  SocketDev
 *
 *  Created by Ryan on 11/4/15.
 *  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
 *
 */

#include <iostream>
#include "SocketDev.h"
#include "SocketDevPriv.hpp"

#include "tolua++.h"

#define VERSION_NUM     "2021 04 06 v1"

TOLUA_API int  tolua_SocketDUT_open (lua_State* tolua_S);


int luaopen_libSocketDUT(lua_State * state)
{
    printf("*****************************************\r\n");
    printf("       Load SocketDUT Library,v%s\r\n",VERSION_NUM);
    printf("*****************************************\r\n");
    
    
    tolua_SocketDUT_open(state);
    
    return 0;
}
