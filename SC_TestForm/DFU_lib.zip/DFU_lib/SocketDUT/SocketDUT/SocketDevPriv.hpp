/*
 *  SocketDevPriv.hpp
 *  SocketDev
 *
 *  Created by Ryan on 11/4/15.
 *  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
 *
 */

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

class SocketDevPriv
{
	public:
		void HelloWorldPriv(const char *);
};

#pragma GCC visibility pop
