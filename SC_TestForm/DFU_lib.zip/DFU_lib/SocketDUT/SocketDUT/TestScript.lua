package.cpath = package.cpath..";/Users/Ryan/Documents/python/TestManager-bfletcwjamiodudppgfvgysylltt/Build/Products/Debug/?.dylib"

require  "libSocketDev"
local sk = require "socket"

local dev = CSocketDevice:new();

local ip1="169.254.1.33"
local ip2="127.0.0.1"
print(dev:Open(ip2,7601))

print(dev:CreateIPC("tcp://*:7000","tcp://*:6800"))
--print(dev:WriteString("[1234567890123456]version(0)\r\n"));

dev:SetDetectString(":-)")
print("detect : ",dev:WaitDetect(1000*10))
print("ReadOut 00000000:",dev:ReadString())



print("Done.....")

do return end;



while true do
local cmd = io.read("*line")
if (cmd == "quite") then
    break;
end
    print("Enter is : ",cmd)
    dev:WriteString(cmd.."\r\n")
--break;
end
