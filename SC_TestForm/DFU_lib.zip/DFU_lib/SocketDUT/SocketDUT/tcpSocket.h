//
//  tcpSocket.h
//  SocketDev
//
//  Created by IvanGan on 15/11/18.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GCDAsyncSocket.h"
//#include "MessageInterface.h"
#import "zmq.h"

@interface CTcpSocket : NSObject
{
@protected
    GCDAsyncSocket* m_ClientSock;
    NSMutableString* m_strServerIp;
    short m_port;
    BOOL m_ConnState;
    NSMutableData* m_dataRecv;
    NSMutableString * m_strZmqSend;
    pthread_mutex_t _mutex;
    NSRange m_rng;
    NSMutableString * m_strStringToDetect;
    NSMutableString * m_strReadBuffer;
    
//    CMessageHost * m_pHost;
    void * m_ContextPublisher;
    void * m_ContextReply;
    void * m_SocketPubliser;
    void * m_SocketReply;
    
    pthread_t m_thread;
}

- (id)initWithIPPort:(NSString*)hwName :(NSString*)ip :(short)port;
- (BOOL)getConnectState;
- (NSString*)readData;
- (int)send:(NSString*)str;
- (int)SetDetectString:(const char * )det;
- (int)WaitDetect:(int )timeout;
- (void)clearStubData;
- (NSData*)getStubData;

- (int)disconnect;
static void * ZMQentry(void * arg);
-(int) CreateIPC:(const char *)reply : (const char *)publisher;
@end

