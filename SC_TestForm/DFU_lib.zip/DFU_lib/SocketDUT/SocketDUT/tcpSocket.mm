//
//  tcpSocket.m
//  SocketDev
//
//  Created by IvanGan on 15/11/18.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "tcpSocket.h"
#include <iostream>
#include <sstream>

@implementation CTcpSocket
-(id)init
{
    self = [super init];
    return self;
}

- (id)initWithIPPort:(NSString*)hwName :(NSString*)ip :(short)port
{
    self = [super init];
    if (self)
    {
        m_dataRecv = [[NSMutableData alloc] init];
        pthread_mutex_init(&_mutex, NULL);
        m_strZmqSend = [[NSMutableString alloc]init];
        
        m_strServerIp = [[NSMutableString alloc ]initWithString:ip];
        m_port = port;
        
        m_ClientSock = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_queue_create([[NSString stringWithFormat:@"%@-%d",hwName,m_port] UTF8String], DISPATCH_QUEUE_CONCURRENT)];
        
        m_ClientSock.delegate = self;
        if(![self connect])
        {
            [NSThread sleepForTimeInterval:0.5];
        }
        m_rng.length=0;
        m_rng.location=0;
        m_strStringToDetect=[[NSMutableString alloc] initWithString:@"\n"];
        m_strReadBuffer = [[NSMutableString alloc]init];
    }
    return self;
}

-(void)dealloc
{
    [m_dataRecv release];
    [m_strStringToDetect release];
    [m_strReadBuffer release];
    pthread_mutex_destroy(&_mutex);
    [m_strZmqSend release];
    pthread_join(m_thread, nullptr);
    if(m_ClientSock)
    {
        [m_ClientSock disconnect];
        [m_ClientSock release];
    }
    if(m_ContextPublisher)
        zmq_ctx_destroy(m_ContextPublisher);
    if(m_ContextReply)
        zmq_ctx_destroy(m_ContextReply);
    [super dealloc];
}

- (int)connect
{
    NSError *err = nil;
    m_ConnState=[m_ClientSock connectToHost:m_strServerIp onPort:m_port error:&err];
    if(m_ConnState == NO)//fail
    {
        NSLog(@"Failed to connect server：%@\n",m_strServerIp);
        return -1;
        
    }else
    {
        NSLog(@"<Connect To Server> %@:%d\n",m_strServerIp,m_port);
    }
    return 0;
}

- (int)disconnect
{
    if(m_ClientSock)
        [m_ClientSock disconnect];
    if(m_ContextPublisher)
        zmq_ctx_destroy(m_ContextPublisher);
    if(m_ContextReply)
        zmq_ctx_destroy(m_ContextReply);
    pthread_join(m_thread, nullptr);
    return 0;
}

-(void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port
{
    NSLog(@"%@", [NSString stringWithFormat:@"socket delegate connected server:%@ . Success.\n",host]);
    [m_ClientSock readDataWithTimeout:-1 tag:0];
}

- (void)socketDidDisconnect:(GCDAsyncSocket *)sock withError:(NSError *)err
{
    m_ConnState = NO;
    NSLog(@"socket disconnected:%@\n",err);
}


-(void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
//    pthread_mutex_lock(&_mutex);
    
    NSMutableData* dataTmp = [[NSMutableData alloc] initWithData:data];
    char* p = NULL;
    if ([dataTmp length] > 0) {
        p = (char*)[dataTmp mutableBytes];
        for (int i=0; i<[dataTmp length]; i++) {
            if (p[i] == '\x0') {
                p[i] = '.';
            }
        }
    }
    
    [m_dataRecv appendData:dataTmp];

    [m_strZmqSend appendFormat:@"%s",[dataTmp bytes]];
    if([m_strZmqSend rangeOfString:@"\r"].location!=NSNotFound || [m_strZmqSend rangeOfString:@":-)"].location!=NSNotFound)
    {
        zmq_send(m_SocketPubliser, [m_strZmqSend UTF8String], [m_strZmqSend length], 0);
        [m_strZmqSend setString:@""];
    }
    [dataTmp release];
//    pthread_mutex_unlock(&_mutex);
    [m_ClientSock readDataWithTimeout:-1 tag:0];
}

- (BOOL)getConnectState
{
    return m_ConnState;
}

- (NSString*)readData
{
    pthread_mutex_lock(&_mutex);
    
    [m_strReadBuffer setString:@""];
    
    if ([m_dataRecv length] > 0) {
        unsigned long max_len = [m_dataRecv length];
        if (max_len > m_rng.location) {
            m_rng.length = max_len - m_rng.location;
            NSData* data = [m_dataRecv subdataWithRange:m_rng];
            if (data && [data length]>0) {
                [m_strReadBuffer setString:[NSString stringWithCString:(const char*)[data bytes] encoding:NSASCIIStringEncoding]];
                m_rng.location = m_rng.location + m_rng.length;
            }
        }
    }
    pthread_mutex_unlock(&_mutex);
    //    NSLog(@"< TCP Read NSString> %@",m_strReadBuffer);
    return m_strReadBuffer;
}

-(int)send:(NSString*)str
{
    if ((m_ConnState && str) == false) return -1;
    
    const char* szData = [str UTF8String];
    NSData* dataToSend = [NSData dataWithBytes:szData length:[str length]];
    [m_ClientSock writeData:dataToSend withTimeout:-1 tag:0];
    [m_ClientSock readDataWithTimeout:-1 tag:0];
    return 0;
}

-(int)SetDetectString:(const char *)det
{
    [m_strStringToDetect setString:[NSString stringWithUTF8String:det]];
    return 0;
}

- (NSData*)getStubData;
{
    return m_dataRecv;
}

- (void)clearStubData //make sure all data reading operation finish before use this function
{
    pthread_mutex_lock(&_mutex);
    //    NSLog(@"stubSize:%lu",(unsigned long)[m_dataRecvBuffer length]);
    [m_dataRecv setLength:0];
    m_rng.length = 0;
    m_rng.location = 0;
    pthread_mutex_unlock(&_mutex);
}

-(int)WaitDetect:(int)timeout
{
    if (m_ConnState == NO) {
        return -1;
    }
    int r = 0;
//    NSLog(@" * * * * * \ndylib Detect :%@ * * * * * \n",m_strStringToDetect);
    NSTimeInterval starttime = [[NSDate date]timeIntervalSince1970];
    double tm = (double)timeout/1000.0;
    while (1)
    {
        NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
        if ((now-starttime)>=tm)
        {
            r = -2;
            break;
        }
        
        if ([[NSThread currentThread] isCancelled])
        {
            r = 1;
            break;
        }
        
        NSRange current_read_rng = m_rng;
        if ([m_dataRecv length] > 0) {
            unsigned long max_len = [m_dataRecv length];
            if (max_len > current_read_rng.location) {
                current_read_rng.length = max_len - current_read_rng.location;
                NSData* data = [m_dataRecv subdataWithRange:current_read_rng];
                if (data && [data length]>0) {
                    //NSString* strTmp = [NSString stringWithUTF8String:(const char*)[data bytes]];
                    NSString* strTmp = [NSString stringWithCString:(const char*)[data bytes] encoding:NSASCIIStringEncoding];
                    if (strTmp && [strTmp length]>0) {
                        NSRange range = [strTmp rangeOfString:m_strStringToDetect];
                        if (range.location!=NSNotFound)
                        {
                            //NSLog(@"decteted string successfully");
                            r = 0;
                            break;
                        }
                    }
                }
            }
        }
        
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        [NSThread sleepForTimeInterval:0.01];
    }
//    NSLog(@"%s\n",[ m_dataRecv bytes]);
    return r;
}



///////////////////   ZMQ
-(int) CreateIPC:(const char *)reply : (const char *)publisher
{
    //Create Socket
    m_ContextPublisher = zmq_ctx_new();
    
    if (!m_ContextPublisher) {
        NSLog(@"[publisher] DeviceHost::failed to create context! with error : %s\n",zmq_strerror(zmq_errno()));
    }
    
    m_ContextReply = zmq_ctx_new();
    
    if (!m_ContextReply) {
        NSLog(@"[reply] DeviceHost::failed to create context! with error : %s\n",zmq_strerror(zmq_errno()));
    }
    
    m_SocketPubliser = zmq_socket(m_ContextPublisher, ZMQ_PUB);
    
    if (!m_SocketPubliser) {
        NSLog(@"[publisher] DeviceHost::failed to create publiser socket! with error  : %s\n",zmq_strerror(zmq_errno()));
    }
    
    m_SocketReply = zmq_socket(m_ContextReply, ZMQ_REP);
    
    if (!m_SocketReply) {
        NSLog(@"[reply] DeviceHost::failed to create reply socket! with error : %s\n",zmq_strerror(zmq_errno()));
    }
    
    usleep(1000*500);   //sleep some time
    
    
    
    int ret = zmq_bind(m_SocketPubliser, publisher);
    if (ret <0) {
        NSLog(@"[publisher] DeviceHost::Publiser socket,failed to bind port number : %s\n",zmq_strerror(zmq_errno()));
    }
    else
    {
        NSLog(@"[publisher] DeviceHost::Create PUBLISER server,bind with address");
    }
    
    ret = zmq_bind(m_SocketReply, reply);
    if (ret <0) {
        NSLog(@"[reply] DeviceHost::Reply socket failed to bind port number : %s\n",zmq_strerror(zmq_errno()));
    }
    else
    {
        NSLog(@"[reply] DeviceHost::Create REPLY server,bind with address :");
    }
    
    
    pthread_create(&m_thread, NULL, ZMQentry, self);
    
    return 0;
}


void * ZMQentry(void * arg)
{
    CTcpSocket * pThis = (CTcpSocket *)arg;
    void * zmq = pThis->m_SocketReply;
    char buf[512];
    while (true)
    {
        int ret = zmq_recv(zmq, buf, 512, 0);
        if (ret>0)
        {
//            NSLog(@"Get Request:%s",buf);
            [pThis send:[NSString stringWithFormat:@"%s",buf]];
            zmq_send(zmq, "OK", 2, 0);
            
        }
    }
    return NULL;
}
@end
