//
//  main.cpp
//  SocketDevConsole
//
//  Created by Ryan on 11/5/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#include <iostream>
#include "SocketDUT.h"
void PipeTest();

static void *threadFunction(void* userdata);
void *mysignal(void * arg);
void sleep_select(int i);
int main(int argc, const char * argv[]) {
    /*PipeTest();
    while (1) {
        ;
    }*/
    // insert code here...
    std::cout << "Hello, World!\n";
    //PipeTest();
    
    CSocketDevice * pDev = new CSocketDevice();
    pDev->CreateIPC("tcp://*:7000", "tcp://*:6800");
    if (pDev->Open("127.0.0.1", 7601)<0)
    {
        printf("Connect device failed!\r\n");
    }
    char buffer[128];
    while (1) {
        pDev->SetDetectString(":-)");
        printf("Please enter command:");
        scanf("%s",buffer);
        strcat(buffer, "\r\n");
        pDev->WriteString(buffer);
        NSLog(@"start to waiting");
        int ret = pDev->WaitDetect(10*1000);
        NSLog(@"waiting finished: %d",ret);
        usleep(500*1000);
        
        printf("read out : %s\r\n",pDev->ReadString());
    }
    return 0;
}


int pip[2] = {-1, -1};
void PipeTest()
{
    pthread_t id;
    
    if (pipe(pip))
    {
        printf("pipe error\n");
        exit(-1);
    }
    printf("p0: %d\n", pip[0]);
    printf("p1: %d\n", pip[1]);
    
    size_t ret = write(pip[1], "12345", 5);
    printf("Write : %ld\r\n",ret);
    ret = write(pip[1], "12345", 6);
    printf("Write : %ld\r\n",ret);
    
    fd_set fds;
    struct timeval timeout;
    
    char data[128] = {0};
    FD_ZERO(&fds);
    FD_SET(pip[0], &fds);
    
    ret = select(pip[0]+1, &fds, NULL, NULL, &timeout);
    if (ret == -1)
    {
        printf("select error\n");
    }
    else if (ret > 0)
    {
        if (FD_ISSET(pip[0], &fds))
        {
            memset(data,0,10);
            read(pip[0], data, 10);
            //printf("read : %s",data);
            printf("[Read]%s Data: %s [%s]\n", __FUNCTION__, data,strerror(errno));
        }
    }
    else
    {
        printf("no fd ready\n");
    }
    timeout.tv_sec = 5;
    timeout.tv_usec = 0;
    
    
    //fcntl(pip[0], F_SETFL, fcntl(pip[0], F_GETFL, 0) | O_NONBLOCK);
    //fcntl(pip[1], F_SETFL, fcntl(pip[1], F_GETFL, 0) | O_NONBLOCK);
    
   // if (pthread_create(&id, NULL, threadFunction, NULL))
    {
     //   printf("create thread error\n");
       // exit(-1);
    }
    printf("pthread id = %lu\n", id);
    pthread_create(&id, NULL, mysignal, NULL);
    //signal(SIGUSR1, mysignal);
    
    
    while (1)
    {
        sleep_select(2);
        //sleep(2);
        //write(pip[1], data, 5);
    }
    
    pthread_join(id, NULL);
}

void sleep_select(int i)
{
    struct timeval timeout;
    timeout.tv_sec = i;
    timeout.tv_usec = 0;
    select(0, NULL, NULL, NULL, &timeout);
}

static void *threadFunction(void* userdata)
{
    char data[6] = {0};
    fd_set fds;
    struct timeval timeout;
    
    int ret;
    
    FD_ZERO(&fds);
    FD_SET(pip[0], &fds);
    
    printf("p0: %d\n", pip[0]);
    printf("p1: %d\n", pip[1]);
    
    int counter = 0;
    
    while (1)
    {
        //sleep(2);
        timeout.tv_sec = 5;
        timeout.tv_usec = 0;
        //FD_ZERO(&fds);
        FD_SET(pip[0], &fds);
        
        ret = select(pip[0]+1, &fds, NULL, NULL, &timeout);
        if (ret == -1)
        {
            printf("select error\n");
            break;
        }
        else if (ret > 0)
        {
            if (FD_ISSET(pip[0], &fds))
            {
                memset(data,0,5);
                read(pip[0], data, 5);
                //printf("read : %s",data);
                printf("[Read]%s: %d, Data: %s [%s]\n", __FUNCTION__, counter++,data,strerror(errno));
            }
        }
        else
        {
            printf("no fd ready\n");
        }
        timeout.tv_sec = 5;
        timeout.tv_usec = 0;
    }
    
    return NULL;
    
}

void *mysignal(void * arg)
{
    printf("signal\n");
    char data[] = "1234";
    int counter = 0;
    while (1)
    {
        //sleep_select(2);
        sleep(1);
        //printf("sowelflsdfsldfsdlfsdl\n");
        write(pip[1], data, 5);
        printf("[Write] time:%lu,%s: %d,with buffer: %s [%s]\n", time(NULL), __FUNCTION__, counter++, data,strerror(errno));
    }
}
