function func ()
 return 5
end
