local _DUT_ = {}
require "pathManager"
package.cpath = package.cpath..";"..deleteLastPathComponent(CurrentDir()).."/lib/?.dylib"
require  "libSocketDUT"

local time_utils = require("utils.time_utils")
local config_utils = require("utils.config_utils")
local uuid = require("utils.uuid")

-- local ip = CONFIG.ARMSOCKET_ADDRESS[CONFIG.ID + 1]--"169.254.1.32"--
local ip = CONFIG.FCT_ADDRESS_BASE--"169.254.1.32"--\
local port = CONFIG.DUTSOCKET_PORT[tonumber(CONFIG.ID) + 1]--7601 \ 7602
local rep = config_utils.get_addr(CONFIG, "UART_PORT", CONFIG.ID)--"tcp://127.0.0.1:7600"
local pub = config_utils.get_addr(CONFIG, "UART_PUB", CONFIG.ID)--"tcp://127.0.0.1:7650"
print("--zynq dut port: "..ip.." port: "..port.." rep: "..rep.." pub: "..pub)
_DUT_.device = nil
function _DUT_._DUT_Socket_Connect_()
	os.execute("ping -c 1 "..ip); 
	if _DUT_.device == nil then
	   _DUT_.device = CSocketDUT:new();
	end

	print("< ".. tostring(CONFIG.ID).." libSocketDev > DUT Port connect to: " .. tostring(ip)..":"..tostring(port))
	local ret = _DUT_.device:Open(ip,port)
	if(ret < 0) then
		error("< ".. tostring(CONFIG.ID).." libSocketDev > ARM Port connect Fail (xxxx)")
	else 
		print("< ".. tostring(CONFIG.ID).." libSocketDev > ARM Port connect successfully")
	end
	print("< ".. tostring(CONFIG.ID).." libSocketDev > ARM REP . SUB: " .. tostring(rep).." . "..tostring(pub))
	print(_DUT_.device:CreateIPC(rep,pub))
	return true
end

function _DUT_._DUT_Send_String_(str)
	return _DUT_.device:WriteString(string.format("%s", str))
end

function _DUT_._DUT_Set_Detect_String_(det)
	if(det) then 
		_DUT_.device:SetDetectString(det)
	end
	return true
end

function _DUT_._DUT_Wait_For_String_(timeout)
	local ret = _DUT_.device:WaitDetect(timeout)
	local errmsg = nil
	if(ret==-1) then
		errmsg = "connection disconnect"
	elseif(ret==-2) then
		errmsg = "Timeout"
	elseif(ret~=0) then
		errmsg = "Unknow Error occur _DUT_Wait_For_String_"
	end
	return ret, errmsg
end



function _DUT_._DUT_Read_String_()
	local tmp = _DUT_.device:ReadString()
	return tmp
end

function _DUT_._DUT_Read_String_Hex_()
	local tmp = _DUT_.device:ReadStringHex()
	return tmp
end

function _DUT_._DUT_Send_Cmd_(cmd,det,timeout)
	if timeout == nil then timeout = 5000 end
	if det == nil then det = "] :-)" end
	--local command = "["..string.sub(uuid(),25,36).."]" .. cmd .. "\r\n"
  	_DUT_._DUT_Set_Detect_String_(det)
  	_DUT_._DUT_Send_String_(cmd.."\r")	
  	return _DUT_._DUT_Wait_For_String_(timeout)
end



function _DUT_._DUT_Clear_Buffer_()
	local tmp = _DUT_.device:ClearBuffer()
	return tmp
end

function _DUT_._DUT_Re_Connect_()
	if _DUT_.device == nil then
	   _DUT_.device = CSocketDUT:new();
	end
	os.execute("ping -c 1 "..ip)
	local ret =_DUT_.device:reOpen(ip,port)
	if(ret < 0) then
		print("< ".. tostring(CONFIG.ID).." libSocketDev > ARM Port connect Fail (xxxx)")
		return false
	else 
		print("< ".. tostring(CONFIG.ID).." libSocketDev > ARM Port connect successfully")
		return true
	end	
end



function _DUT_._DUT_Write_Pass_Control_Bit_(stationId,szCmd)
	local ret = _DUT_.device:WritePassControlBit(stationId,szCmd)
	return ret
end

function _DUT_._DUT_Pub_Msg_(msg)
	local ret = _DUT_.device:PublishLog(msg)
	return ret
end

function _DUT_._Clear_Pub_Msg_()
	 _DUT_.device:ClearPubMsg()
end




function sleep(n)
   os.execute("sleep " .. n)
end

function getIntervalTime()
	local osTime = os.time()
	local strTime = os.date("%H:%M:%S",osTime)
	local h,m,s = string.match(strTime,"(%d+):(%d+):(%d+)")
	local time = h * 3600 + m * 60 + s
	return time
   
end

-- local fristIntervalTime = getIntervalTime()
-- print("fristIntervalTime:"..fristIntervalTime)

-- sleep(10)

-- local sencordIntervalTime = getIntervalTime()
-- print("sencordIntervalTime:"..sencordIntervalTime)


-- print("time:"..sencordIntervalTime - fristIntervalTime)


function WaitDetect2(det,timeout)

	local r = -1
	local startTime = getIntervalTime()
	local tm = timeout/1000.0
	local m_strBuffer = ""
	while(1) do

		local nowTime = getIntervalTime()
		local time = nowTime-startTime
		if(time>=tm) then
			r = -2
			break
		end

		local read = _DUT_._DUT_Read_String_()
		m_strBuffer = m_strBuffer..read
		if string.match(read,det) ~=nil then
			r = 0
			break;
		end
		sleep(0.2)

	end
	

end



function WaitDetect2WithNilTimeout(det,timeout,nil_timeout)

	local r = -1
	local startTime = getIntervalTime()
	local m_strBuffer = ""
	local last_m_strBuffer =""
	local tm = timeout/1000.0
	local index = 1
	local null_starttime = 0
	local null_start_index = 0
    local isfrist = false

	while(1) do

		local nowTime = getIntervalTime()
		local time = nowTime-startTime
		if(time>=tm) then
			r = -2
			break
		end

		local read = _DUT_._DUT_Read_String_()
		m_strBuffer = m_strBuffer..read
		if string.match(read,det) ~=nil then
			r = 0
			break;
		end


		if(index ~= 1 and #m_strBuffer ~= 0) then
			if(#last_m_strBuffer == #m_strBuffer) then 
				if(isfrist == false) then
					null_starttime = getIntervalTime()
					null_start_index = index
					isfrist = true

				else
					if((index - null_start_index) == 1) then
						print("cw_debug--nei xun huan index:"..index)
						local null_now = getIntervalTime()
						local null_tm = null_timeout/1000.0
						if((null_now-null_starttime)>=null_tm) then 
							print("cw_debug--null timeout log---"..last_m_strBuffer.."------end");
							return -3
						end
						null_start_index = index;
					else
						isfrist = true

					end

				end
			end
		end

		last_m_strBuffer =m_strBuffer;

		index = index + 1
		print("cw_debug--wai xun huan index:"..index)
		sleep(0.2)

	end

	return r
	

end


return _DUT_
